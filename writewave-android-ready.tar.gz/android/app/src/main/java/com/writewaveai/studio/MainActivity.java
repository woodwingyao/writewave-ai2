package com.writewaveai.studio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
