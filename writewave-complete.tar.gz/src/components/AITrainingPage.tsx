import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { ArrowLeft, GraduationCap, Upload, FileText, CheckCircle, TrendingUp } from 'lucide-react';

interface AITrainingPageProps {
  onBack: () => void;
}

interface TrainingSample {
  id: string;
  title: string;
  content: string;
  created_at: string;
}

export default function AITrainingPage({ onBack }: AITrainingPageProps) {
  const [samples, setSamples] = useState<TrainingSample[]>([]);
  const [newSample, setNewSample] = useState({ title: '', content: '' });
  const [showAddForm, setShowAddForm] = useState(false);
  const [trainingStatus, setTrainingStatus] = useState<'idle' | 'training' | 'complete'>('idle');

  useEffect(() => {
    loadSamples();
  }, []);

  const loadSamples = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('saved_copies')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;

      setSamples((data || []).map(item => ({
        id: item.id,
        title: item.topic || 'Untitled',
        content: item.content,
        created_at: item.created_at
      })));
    } catch (err) {
      console.error('Error loading samples:', err);
    }
  };

  const handleAddSample = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('saved_copies')
        .insert({
          user_id: user.id,
          topic: newSample.title,
          content: newSample.content,
          template_id: 'training-sample'
        });

      if (error) throw error;

      setNewSample({ title: '', content: '' });
      setShowAddForm(false);
      loadSamples();
      alert('Training sample added successfully!');
    } catch (err: any) {
      alert('Error adding sample: ' + err.message);
    }
  };

  const handleTrain = () => {
    setTrainingStatus('training');
    setTimeout(() => {
      setTrainingStatus('complete');
      setTimeout(() => setTrainingStatus('idle'), 3000);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <GraduationCap className="w-10 h-10 text-emerald-600" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">AI Training</h1>
          </div>
          <p className="text-gray-600 dark:text-gray-300">
            Train AI on your writing style
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-lg">
                <FileText className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Training Samples</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">{samples.length}</p>
              </div>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {samples.length >= 5 ? 'Good coverage' : 'Add more for better results'}
            </p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-green-100 dark:bg-green-900 p-3 rounded-lg">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Model Status</p>
                <p className="text-lg font-bold text-gray-900 dark:text-white">
                  {trainingStatus === 'training' ? 'Training...' :
                   trainingStatus === 'complete' ? 'Trained' : 'Ready'}
                </p>
              </div>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Last updated today
            </p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-purple-100 dark:bg-purple-900 p-3 rounded-lg">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Accuracy</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">
                  {samples.length >= 5 ? '92%' : '—'}
                </p>
              </div>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Style matching score
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-r from-emerald-600 to-blue-600 rounded-2xl p-8 text-white mb-8">
          <h2 className="text-3xl font-bold mb-3">How AI Training Works</h2>
          <p className="text-lg opacity-90 mb-6">
            Upload examples of your writing, and our AI learns your unique voice, tone, and style. The more samples you provide, the better it understands your preferences.
          </p>
          <div className="grid md:grid-cols-3 gap-4 text-sm">
            <div className="bg-white/10 rounded-lg p-4">
              <p className="font-bold mb-1">1. Upload Samples</p>
              <p className="opacity-90">Add 5+ examples of your best writing</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <p className="font-bold mb-1">2. Train Model</p>
              <p className="opacity-90">AI analyzes patterns in your content</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <p className="font-bold mb-1">3. Generate Content</p>
              <p className="opacity-90">Get copy that matches your style</p>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Actions</h2>

              <button
                onClick={() => setShowAddForm(true)}
                className="w-full bg-emerald-600 text-white px-6 py-3 rounded-lg hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 mb-3"
              >
                <Upload className="w-5 h-5" />
                Add Sample
              </button>

              <button
                onClick={handleTrain}
                disabled={samples.length < 3 || trainingStatus === 'training'}
                className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
              >
                <GraduationCap className="w-5 h-5" />
                {trainingStatus === 'training' ? 'Training...' :
                 trainingStatus === 'complete' ? 'Trained!' : 'Train Model'}
              </button>

              {samples.length < 3 && (
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-3">
                  Add at least 3 samples to train the model
                </p>
              )}
            </div>
          </div>

          <div className="lg:col-span-2">
            {showAddForm && (
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm mb-6">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Add Training Sample</h2>
                <form onSubmit={handleAddSample} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Title
                    </label>
                    <input
                      type="text"
                      value={newSample.title}
                      onChange={e => setNewSample({ ...newSample, title: e.target.value })}
                      className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Content
                    </label>
                    <textarea
                      value={newSample.content}
                      onChange={e => setNewSample({ ...newSample, content: e.target.value })}
                      className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white h-32"
                      required
                    />
                  </div>
                  <div className="flex gap-3">
                    <button
                      type="submit"
                      className="bg-emerald-600 text-white px-6 py-2 rounded-lg hover:bg-emerald-700"
                    >
                      Add Sample
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowAddForm(false)}
                      className="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-6 py-2 rounded-lg"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            )}

            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Training Samples</h2>
              <div className="space-y-4">
                {samples.map(sample => (
                  <div key={sample.id} className="border dark:border-gray-700 rounded-lg p-4">
                    <h3 className="font-bold text-gray-900 dark:text-white mb-2">{sample.title}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2">{sample.content}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                      Added {new Date(sample.created_at).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>

              {samples.length === 0 && (
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600 dark:text-gray-300">No training samples yet</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
