import { ArrowLeft } from 'lucide-react';

interface PrivacyPolicyPageProps {
  onBack: () => void;
}

export default function PrivacyPolicyPage({ onBack }: PrivacyPolicyPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <button
          onClick={onBack}
          className="mb-8 flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="bg-white rounded-xl shadow-lg p-8 md:p-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Privacy Policy</h1>
          <p className="text-slate-600 mb-8">Last Updated: November 22, 2025</p>

          <div className="prose prose-slate max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">1. Introduction</h2>
              <p className="text-slate-700 mb-4">
                Welcome to WriteWave AI. We respect your privacy and are committed to protecting your personal data.
                This privacy policy explains how we collect, use, and safeguard your information when you use our app.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">2. Information We Collect</h2>
              <h3 className="text-xl font-semibold text-slate-900 mb-3">2.1 Information You Provide</h3>
              <ul className="list-disc pl-6 text-slate-700 mb-4 space-y-2">
                <li>Email address (for account creation and authentication)</li>
                <li>Content you create using our AI copywriting tools</li>
                <li>Brand voice preferences and settings</li>
                <li>Template favorites and usage preferences</li>
              </ul>

              <h3 className="text-xl font-semibold text-slate-900 mb-3">2.2 Automatically Collected Information</h3>
              <ul className="list-disc pl-6 text-slate-700 mb-4 space-y-2">
                <li>Usage data and analytics (templates used, generation statistics)</li>
                <li>Device information and technical data</li>
                <li>Performance and diagnostic data</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">3. How We Use Your Information</h2>
              <p className="text-slate-700 mb-3">We use your information to:</p>
              <ul className="list-disc pl-6 text-slate-700 mb-4 space-y-2">
                <li>Provide and maintain our AI copywriting services</li>
                <li>Process your content generation requests</li>
                <li>Manage your account and subscription</li>
                <li>Send service-related notifications</li>
                <li>Improve our app and develop new features</li>
                <li>Analyze usage patterns and optimize performance</li>
                <li>Ensure security and prevent fraud</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">4. Data Storage and Security</h2>
              <p className="text-slate-700 mb-4">
                We use industry-standard security measures to protect your data. Your information is stored securely
                using Supabase, a secure and reliable database service. We implement encryption, secure authentication,
                and access controls to safeguard your data.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">5. Data Sharing and Disclosure</h2>
              <p className="text-slate-700 mb-3">
                We do not sell your personal data. We may share your information only in the following circumstances:
              </p>
              <ul className="list-disc pl-6 text-slate-700 mb-4 space-y-2">
                <li>With AI service providers (OpenAI/Anthropic) to generate content based on your prompts</li>
                <li>With payment processors (Stripe) to handle subscription payments</li>
                <li>When required by law or to protect our legal rights</li>
                <li>With your explicit consent</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">6. Your Content</h2>
              <p className="text-slate-700 mb-4">
                Content you generate using WriteWave AI belongs to you. We store your generated content and saved
                copy history to provide you with access to your work across devices. You can delete your content
                at any time through the app.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">7. Your Rights</h2>
              <p className="text-slate-700 mb-3">You have the right to:</p>
              <ul className="list-disc pl-6 text-slate-700 mb-4 space-y-2">
                <li>Access your personal data</li>
                <li>Correct inaccurate data</li>
                <li>Delete your account and data</li>
                <li>Export your content</li>
                <li>Opt-out of non-essential data collection</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">8. Children's Privacy</h2>
              <p className="text-slate-700 mb-4">
                WriteWave AI is not intended for children under 13 years of age. We do not knowingly collect
                personal information from children under 13. If you believe we have collected information from
                a child under 13, please contact us immediately.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">9. Data Retention</h2>
              <p className="text-slate-700 mb-4">
                We retain your data for as long as your account is active or as needed to provide you services.
                You may request deletion of your account and data at any time. Some data may be retained for
                legitimate business purposes or legal requirements.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">10. International Data Transfers</h2>
              <p className="text-slate-700 mb-4">
                Your data may be transferred to and processed in countries other than your own. We ensure
                appropriate safeguards are in place to protect your data in accordance with this privacy policy.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">11. Cookies and Tracking</h2>
              <p className="text-slate-700 mb-4">
                We use essential cookies and local storage to maintain your session and provide core functionality.
                We do not use third-party advertising or tracking cookies.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">12. Changes to This Policy</h2>
              <p className="text-slate-700 mb-4">
                We may update this privacy policy from time to time. We will notify you of any significant changes
                by posting the new policy on this page and updating the "Last Updated" date.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">13. Contact Us</h2>
              <p className="text-slate-700 mb-4">
                If you have questions about this privacy policy or how we handle your data, please contact us at:
              </p>
              <p className="text-slate-700 font-medium">
                Email: privacy@writewaveai.com
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">14. Legal Basis for Processing (GDPR)</h2>
              <p className="text-slate-700 mb-4">
                For users in the European Union, we process your data based on:
              </p>
              <ul className="list-disc pl-6 text-slate-700 mb-4 space-y-2">
                <li>Contractual necessity (to provide our services)</li>
                <li>Legitimate interests (to improve and secure our services)</li>
                <li>Your consent (where applicable)</li>
                <li>Legal obligations</li>
              </ul>
            </section>

            <div className="mt-12 p-6 bg-blue-50 rounded-lg">
              <p className="text-slate-700 text-sm">
                This privacy policy is effective as of the date stated above. By using WriteWave AI,
                you acknowledge that you have read and understood this privacy policy.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
