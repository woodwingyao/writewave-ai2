import * as Icons from 'lucide-react';

interface CancelPageProps {
  onGoBack: () => void;
  onGoHome: () => void;
}

export default function CancelPage({ onGoBack, onGoHome }: CancelPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 flex items-center justify-center px-4">
      <div className="max-w-2xl w-full">
        <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-slate-100 rounded-full mb-6">
            <Icons.XCircle className="w-12 h-12 text-slate-600" />
          </div>

          <h1 className="text-3xl font-bold text-slate-900 mb-4">
            Payment Canceled
          </h1>

          <p className="text-lg text-slate-600 mb-8">
            Your payment was not completed. You can retry anytime.
          </p>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-6 rounded mb-8 text-left">
            <h3 className="font-semibold text-blue-900 mb-2">
              Need help deciding?
            </h3>
            <p className="text-sm text-blue-800">
              Pro gives you unlimited access to all features, advanced templates, and priority support.
              Try it risk-free with our cancel-anytime policy.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={onGoBack}
              className="flex-1 bg-blue-600 text-white py-4 rounded-lg font-semibold hover:bg-blue-700 transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl"
            >
              <Icons.ArrowLeft className="w-5 h-5" />
              Try Again
            </button>
            <button
              onClick={onGoHome}
              className="flex-1 bg-slate-100 text-slate-700 py-4 rounded-lg font-semibold hover:bg-slate-200 transition-all flex items-center justify-center gap-2"
            >
              <Icons.Home className="w-5 h-5" />
              Go Home
            </button>
          </div>

          <p className="mt-6 text-sm text-slate-500">
            Questions? Contact us at support@example.com
          </p>
        </div>
      </div>
    </div>
  );
}
