import { useState, useMemo } from 'react';
import { templates } from '../lib/templates';
import { supabase } from '../lib/supabase';
import * as Icons from 'lucide-react';
import type { GenerateData } from './InputPage';
import { exportToTXT, exportToHTML, exportToMarkdown, exportToPDF, exportToDOCX } from '../lib/exportUtils';
import { analyzeSEO } from '../lib/seoUtils';
import { useTheme } from '../lib/theme';

interface ResultsPageProps {
  data: GenerateData;
  generatedContent: string;
  isLoading: boolean;
  onRegenerate: () => void;
  onBack: () => void;
  onBackToHome: () => void;
}

export default function ResultsPage({
  data,
  generatedContent,
  isLoading,
  onRegenerate,
  onBack,
  onBackToHome
}: ResultsPageProps) {
  const { theme, toggleTheme } = useTheme();
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [copyError, setCopyError] = useState<string | null>(null);
  const [showSEO, setShowSEO] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [isSharing, setIsSharing] = useState(false);
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [showShareModal, setShowShareModal] = useState(false);

  const template = templates.find((t) => t.id === data.templateId);

  const variations = generatedContent
    .split(/---VARIATION---|(?=\d+\.|Version \d+|# Version \d+)/g)
    .filter((v) => v.trim().length > 10)
    .map(v => v.replace(/^---VARIATION---\s*/g, '').trim());

  const seoMetrics = useMemo(() => {
    if (!generatedContent || isLoading) return null;
    return analyzeSEO(generatedContent);
  }, [generatedContent, isLoading]);

  const handleCopy = async (text: string, index: number) => {
    if (!text || text.trim().length === 0) {
      setCopyError('Nothing to copy yet.');
      setTimeout(() => setCopyError(null), 3000);
      return;
    }

    try {
      await navigator.clipboard.writeText(text);
      setCopiedIndex(index);
      setCopyError(null);
      setTimeout(() => setCopiedIndex(null), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
      setCopyError('Unable to copy. Please try manually.');
      setTimeout(() => setCopyError(null), 3000);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveSuccess(false);

    try {
      const { error } = await supabase.from('saved_copies').insert({
        template_type: data.templateId,
        content: generatedContent,
        topic: data.topic,
        audience: data.audience,
        tone: data.tone,
        details: data.details
      });

      if (error) throw error;

      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (error) {
      console.error('Failed to save:', error);
      alert('Failed to save content. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleExport = (format: 'txt' | 'html' | 'md' | 'pdf' | 'docx') => {
    const filename = `${data.topic || template?.name || 'content'}-${Date.now()}`;
    const metadata = {
      topic: data.topic,
      tone: data.tone,
      audience: data.audience
    };

    switch (format) {
      case 'txt':
        exportToTXT(generatedContent, filename);
        break;
      case 'html':
        exportToHTML(generatedContent, filename);
        break;
      case 'md':
        exportToMarkdown(generatedContent, filename);
        break;
      case 'pdf':
        exportToPDF(generatedContent, filename, metadata);
        break;
      case 'docx':
        exportToDOCX(generatedContent, filename, metadata);
        break;
    }

    setShowExportMenu(false);
  };

  const handleShare = async () => {
    setIsSharing(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        alert('Please sign in to share content');
        setIsSharing(false);
        return;
      }

      const { data: sharedContent, error } = await supabase
        .from('shared_content')
        .insert({
          user_id: user.id,
          content: generatedContent,
          template_id: data.templateId,
          topic: data.topic,
          tone: data.tone,
          audience: data.audience,
          details: data.details,
          is_public: true
        })
        .select('share_token')
        .single();

      if (error) throw error;

      const url = `${window.location.origin}/shared/${sharedContent.share_token}`;
      setShareUrl(url);
      setShowShareModal(true);
    } catch (error) {
      console.error('Failed to share:', error);
      alert('Failed to create share link. Please try again.');
    } finally {
      setIsSharing(false);
    }
  };

  const copyShareUrl = async () => {
    if (shareUrl) {
      try {
        await navigator.clipboard.writeText(shareUrl);
        alert('Share link copied to clipboard!');
      } catch (error) {
        console.error('Failed to copy:', error);
      }
    }
  };

  const IconComponent = template
    ? (Icons as Record<string, React.ComponentType<{ className?: string }>>)[template.icon]
    : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 transition-colors">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <button
              onClick={onBack}
              className="inline-flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors group"
            >
              <Icons.ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              Back to Form
            </button>
            <div className="flex items-center gap-3">
              <button
                onClick={toggleTheme}
                className="inline-flex items-center justify-center p-2.5 bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-600 transition-all shadow-sm border-2 border-slate-200 dark:border-slate-600"
                title={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
              >
                {theme === 'light' ? (
                  <Icons.Moon className="w-5 h-5" />
                ) : (
                  <Icons.Sun className="w-5 h-5" />
                )}
              </button>
              <button
                onClick={onBackToHome}
                className="inline-flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors"
              >
                <Icons.Home className="w-5 h-5" />
                Home
              </button>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg p-8 md:p-12">
            <div className="flex items-start gap-4 mb-8">
              <div className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-xl">
                {IconComponent && <IconComponent className="w-8 h-8 text-blue-600" />}
              </div>
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">
                  {template?.name}
                </h1>
                <div className="flex flex-wrap gap-2 text-sm text-slate-600">
                  {data.topic && (
                    <span className="bg-slate-100 dark:bg-slate-700 dark:text-slate-200 px-3 py-1 rounded-full">
                      {data.topic}
                    </span>
                  )}
                  <span className="bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 px-3 py-1 rounded-full">
                    {data.tone}
                  </span>
                  {data.audience && (
                    <span className="bg-slate-100 dark:bg-slate-700 dark:text-slate-200 px-3 py-1 rounded-full">
                      {data.audience}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-16">
                <div className="relative">
                  <div className="w-16 h-16 border-4 border-blue-200 rounded-full"></div>
                  <div className="w-16 h-16 border-4 border-blue-600 rounded-full border-t-transparent animate-spin absolute top-0 left-0"></div>
                </div>
                <p className="mt-6 text-slate-600 dark:text-slate-300 font-medium">Generating your content...</p>
                <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">This may take a few moments</p>
              </div>
            ) : (
              <>
                {copyError && (
                  <div className="mb-4 bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500 p-4 rounded">
                    <p className="text-sm text-red-700 dark:text-red-300 flex items-center gap-2">
                      <Icons.AlertCircle className="w-4 h-4" />
                      {copyError}
                    </p>
                  </div>
                )}

                <div className="space-y-6 mb-8">
                  {variations.length > 1 ? (
                    variations.map((variation, index) => (
                      <div
                        key={index}
                        className="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-6 border-2 border-slate-200 dark:border-slate-600 hover:border-blue-300 dark:hover:border-blue-500 transition-colors"
                      >
                        <div className="flex items-start justify-between gap-4 mb-4">
                          <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                            Option {index + 1}
                          </h3>
                          <button
                            onClick={() => handleCopy(variation.trim(), index)}
                            disabled={!variation.trim()}
                            className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-500 transition-all text-sm font-medium shadow-sm hover:shadow disabled:bg-slate-50 dark:disabled:bg-slate-700 disabled:text-slate-400 disabled:cursor-not-allowed"
                            aria-label={`Copy option ${index + 1} to clipboard`}
                            title={`Copy option ${index + 1} to clipboard`}
                          >
                            {copiedIndex === index ? (
                              <>
                                <Icons.Check className="w-4 h-4 text-green-600" />
                                Copied!
                              </>
                            ) : (
                              <>
                                <Icons.Copy className="w-4 h-4" />
                                Copy
                              </>
                            )}
                          </button>
                        </div>
                        <p className="text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
                          {variation.trim()}
                        </p>
                      </div>
                    ))
                  ) : (
                    <div className="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-6 border-2 border-slate-200 dark:border-slate-600">
                      <div className="flex items-start justify-between gap-4 mb-4">
                        <h3 className="text-sm font-semibold text-slate-700">
                          Generated Content
                        </h3>
                        <button
                          onClick={() => handleCopy(generatedContent, 0)}
                          disabled={!generatedContent || generatedContent.trim().length === 0}
                          className="flex items-center gap-2 px-4 py-2 bg-white text-slate-700 rounded-lg hover:bg-slate-100 transition-all text-sm font-medium shadow-sm hover:shadow disabled:bg-slate-50 disabled:text-slate-400 disabled:cursor-not-allowed"
                          aria-label="Copy generated text to clipboard"
                          title="Copy generated text to clipboard"
                        >
                          {copiedIndex === 0 ? (
                            <>
                              <Icons.Check className="w-4 h-4 text-green-600" />
                              Copied!
                            </>
                          ) : (
                            <>
                              <Icons.Copy className="w-4 h-4" />
                              Copy
                            </>
                          )}
                        </button>
                      </div>
                      <p className="text-slate-800 whitespace-pre-wrap leading-relaxed">
                        {generatedContent}
                      </p>
                    </div>
                  )}
                </div>

                {seoMetrics && (
                  <div className="mb-6">
                    <button
                      onClick={() => setShowSEO(!showSEO)}
                      className="w-full flex items-center justify-between p-4 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <Icons.BarChart3 className="w-5 h-5 text-slate-700" />
                        <span className="font-semibold text-slate-900">SEO Analysis</span>
                      </div>
                      <Icons.ChevronDown className={`w-5 h-5 text-slate-600 transition-transform ${showSEO ? 'rotate-180' : ''}`} />
                    </button>

                    {showSEO && (
                      <div className="mt-4 p-6 bg-slate-50 rounded-lg space-y-4">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div className="text-center p-3 bg-white rounded-lg">
                            <div className="text-2xl font-bold text-blue-600">{seoMetrics.wordCount}</div>
                            <div className="text-xs text-slate-600">Words</div>
                          </div>
                          <div className="text-center p-3 bg-white rounded-lg">
                            <div className="text-2xl font-bold text-blue-600">{seoMetrics.characterCount}</div>
                            <div className="text-xs text-slate-600">Characters</div>
                          </div>
                          <div className="text-center p-3 bg-white rounded-lg">
                            <div className="text-2xl font-bold text-blue-600">{seoMetrics.sentenceCount}</div>
                            <div className="text-xs text-slate-600">Sentences</div>
                          </div>
                          <div className="text-center p-3 bg-white rounded-lg">
                            <div className="text-2xl font-bold text-blue-600">{seoMetrics.readingTime}m</div>
                            <div className="text-xs text-slate-600">Read Time</div>
                          </div>
                        </div>

                        <div className="p-4 bg-white rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-semibold text-slate-900">Readability Score</span>
                            <span className="text-blue-600 font-bold">{seoMetrics.readabilityScore}/100</span>
                          </div>
                          <div className="w-full bg-slate-200 rounded-full h-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full transition-all"
                              style={{ width: `${Math.min(Math.max(seoMetrics.readabilityScore, 0), 100)}%` }}
                            />
                          </div>
                          <div className="text-sm text-slate-600 mt-2">{seoMetrics.readabilityLevel}</div>
                        </div>

                        {seoMetrics.keywordDensity.length > 0 && (
                          <div className="p-4 bg-white rounded-lg">
                            <h4 className="font-semibold text-slate-900 mb-3">Top Keywords</h4>
                            <div className="space-y-2">
                              {seoMetrics.keywordDensity.slice(0, 5).map((kw, idx) => (
                                <div key={idx} className="flex items-center justify-between text-sm">
                                  <span className="text-slate-700">{kw.word}</span>
                                  <div className="flex items-center gap-2">
                                    <span className="text-slate-500">{kw.count}x</span>
                                    <span className="text-blue-600 font-medium">{kw.percentage}%</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}

                <div className="flex flex-wrap gap-4">
                  <button
                    onClick={onRegenerate}
                    disabled={isLoading}
                    className="flex-1 min-w-[200px] flex items-center justify-center gap-2 px-6 py-4 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-all shadow-lg hover:shadow-xl disabled:bg-slate-300 disabled:cursor-not-allowed"
                  >
                    <Icons.RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
                    {isLoading ? 'Regenerating...' : 'Regenerate'}
                  </button>

                  <div className="relative">
                    <button
                      onClick={() => setShowExportMenu(!showExportMenu)}
                      className="flex items-center justify-center gap-2 px-6 py-4 bg-slate-600 text-white rounded-lg font-semibold hover:bg-slate-700 transition-all shadow-lg hover:shadow-xl"
                    >
                      <Icons.Download className="w-5 h-5" />
                      Export
                    </button>

                    {showExportMenu && (
                      <div className="absolute bottom-full mb-2 right-0 bg-white rounded-lg shadow-xl border-2 border-slate-200 py-2 z-10 min-w-[180px]">
                        <button
                          onClick={() => handleExport('pdf')}
                          className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2 text-slate-700 font-medium"
                        >
                          <Icons.FileText className="w-4 h-4 text-red-600" />
                          PDF Document
                        </button>
                        <button
                          onClick={() => handleExport('docx')}
                          className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2 text-slate-700 font-medium"
                        >
                          <Icons.FileText className="w-4 h-4 text-blue-600" />
                          Word Document
                        </button>
                        <div className="border-t border-slate-200 my-1"></div>
                        <button
                          onClick={() => handleExport('txt')}
                          className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2 text-slate-600"
                        >
                          <Icons.FileText className="w-4 h-4" />
                          Text (.txt)
                        </button>
                        <button
                          onClick={() => handleExport('html')}
                          className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2 text-slate-600"
                        >
                          <Icons.Code className="w-4 h-4" />
                          HTML (.html)
                        </button>
                        <button
                          onClick={() => handleExport('md')}
                          className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2 text-slate-600"
                        >
                          <Icons.FileCode className="w-4 h-4" />
                          Markdown (.md)
                        </button>
                      </div>
                    )}
                  </div>

                  <button
                    onClick={handleSave}
                    disabled={isSaving}
                    className="flex-1 min-w-[200px] flex items-center justify-center gap-2 px-6 py-4 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-700 transition-all disabled:bg-slate-300 shadow-lg hover:shadow-xl"
                  >
                    {saveSuccess ? (
                      <>
                        <Icons.Check className="w-5 h-5" />
                        Saved!
                      </>
                    ) : (
                      <>
                        <Icons.Save className="w-5 h-5" />
                        {isSaving ? 'Saving...' : 'Save to History'}
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleShare}
                    disabled={isSharing}
                    className="flex items-center justify-center gap-2 px-6 py-4 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition-all disabled:bg-slate-300 shadow-lg hover:shadow-xl"
                  >
                    <Icons.Share2 className="w-5 h-5" />
                    {isSharing ? 'Creating...' : 'Share'}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {showShareModal && shareUrl && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Share Content</h2>
              <button
                onClick={() => setShowShareModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <Icons.X className="w-6 h-6 text-slate-600" />
              </button>
            </div>

            <div className="mb-6">
              <p className="text-slate-600 mb-4">Your content is now shareable! Anyone with this link can view it.</p>
              <div className="bg-slate-50 rounded-lg p-4 border-2 border-slate-200">
                <p className="text-sm text-slate-800 break-all font-mono">{shareUrl}</p>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={copyShareUrl}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-all"
              >
                <Icons.Copy className="w-5 h-5" />
                Copy Link
              </button>
              <button
                onClick={() => setShowShareModal(false)}
                className="px-4 py-3 bg-slate-200 text-slate-700 rounded-lg font-semibold hover:bg-slate-300 transition-all"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
