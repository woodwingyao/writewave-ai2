import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { ArrowLeft, TrendingUp, FileText, Calendar, Zap, BarChart3 } from 'lucide-react';

interface UsageDashboardPageProps {
  onBack: () => void;
}

interface UsageStats {
  totalCopies: number;
  thisMonth: number;
  limit: number;
  recentActivity: Array<{ date: string; count: number }>;
}

export default function UsageDashboardPage({ onBack }: UsageDashboardPageProps) {
  const [stats, setStats] = useState<UsageStats>({
    totalCopies: 0,
    thisMonth: 0,
    limit: 100,
    recentActivity: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUsageStats();
  }, []);

  const loadUsageStats = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: copies, error } = await supabase
        .from('saved_copies')
        .select('created_at')
        .eq('user_id', user.id);

      if (error) throw error;

      const total = copies?.length || 0;

      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const thisMonth = copies?.filter(c => new Date(c.created_at) >= startOfMonth).length || 0;

      const last7Days = Array.from({ length: 7 }, (_, i) => {
        const date = new Date();
        date.setDate(date.getDate() - i);
        return date.toISOString().split('T')[0];
      }).reverse();

      const activity = last7Days.map(date => {
        const count = copies?.filter(c => c.created_at.startsWith(date)).length || 0;
        return { date, count };
      });

      setStats({
        totalCopies: total,
        thisMonth,
        limit: 100,
        recentActivity: activity
      });
    } catch (err) {
      console.error('Error loading stats:', err);
    } finally {
      setLoading(false);
    }
  };

  const maxActivity = Math.max(...stats.recentActivity.map(a => a.count), 1);
  const usagePercentage = (stats.thisMonth / stats.limit) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="w-10 h-10 text-red-600" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">Usage Dashboard</h1>
          </div>
          <p className="text-gray-600 dark:text-gray-300">
            Track your usage and limits
          </p>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-gray-600 dark:text-gray-300">Loading stats...</p>
          </div>
        ) : (
          <>
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-3">
                  <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-lg">
                    <FileText className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Total Copies</p>
                    <p className="text-3xl font-bold text-gray-900 dark:text-white">{stats.totalCopies}</p>
                  </div>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400">All time</p>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-3">
                  <div className="bg-green-100 dark:bg-green-900 p-3 rounded-lg">
                    <Calendar className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">This Month</p>
                    <p className="text-3xl font-bold text-gray-900 dark:text-white">{stats.thisMonth}</p>
                  </div>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {stats.limit - stats.thisMonth} remaining
                </p>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-3">
                  <div className="bg-purple-100 dark:bg-purple-900 p-3 rounded-lg">
                    <Zap className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Monthly Limit</p>
                    <p className="text-3xl font-bold text-gray-900 dark:text-white">{stats.limit}</p>
                  </div>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400">Resets monthly</p>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm mb-8">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Monthly Usage</h2>
              <div className="mb-4">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-600 dark:text-gray-400">
                    {stats.thisMonth} / {stats.limit} copies used
                  </span>
                  <span className="font-bold text-gray-900 dark:text-white">
                    {usagePercentage.toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-4">
                  <div
                    className={`h-4 rounded-full transition-all ${
                      usagePercentage >= 90 ? 'bg-red-600' :
                      usagePercentage >= 70 ? 'bg-yellow-600' :
                      'bg-green-600'
                    }`}
                    style={{ width: `${Math.min(usagePercentage, 100)}%` }}
                  />
                </div>
              </div>
              {usagePercentage >= 90 && (
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
                  <p className="text-sm text-red-800 dark:text-red-300">
                    You're approaching your monthly limit. Consider upgrading for unlimited copies.
                  </p>
                </div>
              )}
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
              <div className="flex items-center gap-2 mb-6">
                <BarChart3 className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Activity (Last 7 Days)</h2>
              </div>

              <div className="space-y-4">
                {stats.recentActivity.map((day, idx) => (
                  <div key={idx}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {new Date(day.date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                      </span>
                      <span className="text-sm font-bold text-gray-900 dark:text-white">
                        {day.count} {day.count === 1 ? 'copy' : 'copies'}
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all"
                        style={{ width: `${(day.count / maxActivity) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
