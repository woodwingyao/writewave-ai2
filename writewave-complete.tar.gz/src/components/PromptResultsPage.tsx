import { useState } from 'react';
import { promptTemplates, writingStyles } from '../lib/templates';
import { supabase } from '../lib/supabase';
import * as Icons from 'lucide-react';
import type { PromptGenerateData } from './PromptPage';

interface PromptResultsPageProps {
  data: PromptGenerateData;
  generatedContent: string;
  isLoading: boolean;
  onRegenerate: () => void;
  onBack: () => void;
  onBackToHome: () => void;
}

export default function PromptResultsPage({
  data,
  generatedContent,
  isLoading,
  onRegenerate,
  onBack,
  onBackToHome
}: PromptResultsPageProps) {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [copyError, setCopyError] = useState<string | null>(null);

  const template = promptTemplates.find((t) => t.id === data.templateId);
  const style = writingStyles.find((s) => s.id === data.styleId);

  const handleCopy = async (text: string, index: number) => {
    if (!text || text.trim().length === 0) {
      setCopyError('Nothing to copy yet.');
      setTimeout(() => setCopyError(null), 3000);
      return;
    }

    try {
      await navigator.clipboard.writeText(text);
      setCopiedIndex(index);
      setCopyError(null);
      setTimeout(() => setCopiedIndex(null), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
      setCopyError('Unable to copy. Please try manually.');
      setTimeout(() => setCopyError(null), 3000);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveSuccess(false);

    try {
      const { error } = await supabase.from('saved_copies').insert({
        template_type: `prompt-${data.templateId}`,
        content: generatedContent,
        topic: data.prompt.slice(0, 100),
        audience: '',
        tone: data.tone,
        details: data.prompt
      });

      if (error) throw error;

      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (error) {
      console.error('Failed to save:', error);
      alert('Failed to save content. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <button
              onClick={onBack}
              className="inline-flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors group"
            >
              <Icons.ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              Back
            </button>
            <button
              onClick={onBackToHome}
              className="inline-flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
            >
              <Icons.Home className="w-5 h-5" />
              Home
            </button>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-slate-900 mb-2">
                Your Generated Content
              </h1>
              <div className="flex flex-wrap gap-2 text-sm text-slate-600">
                <span className="bg-slate-100 px-3 py-1 rounded-full">
                  {template?.name}
                </span>
                <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full">
                  {data.tone}
                </span>
                <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full">
                  {style?.name}
                </span>
              </div>
            </div>

            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-16">
                <div className="relative">
                  <div className="w-16 h-16 border-4 border-blue-200 rounded-full"></div>
                  <div className="w-16 h-16 border-4 border-blue-600 rounded-full border-t-transparent animate-spin absolute top-0 left-0"></div>
                </div>
                <p className="mt-6 text-slate-600 font-medium">Generating your content...</p>
                <p className="mt-2 text-sm text-slate-500">This may take a few moments</p>
              </div>
            ) : (
              <>
                <div className="bg-slate-50 rounded-xl p-8 border-2 border-slate-200 mb-8">
                  <p className="text-slate-800 whitespace-pre-wrap leading-relaxed text-base">
                    {generatedContent}
                  </p>
                </div>

                {copyError && (
                  <div className="mb-4 bg-red-50 border-l-4 border-red-500 p-4 rounded">
                    <p className="text-sm text-red-700 flex items-center gap-2">
                      <Icons.AlertCircle className="w-4 h-4" />
                      {copyError}
                    </p>
                  </div>
                )}

                <div className="flex flex-wrap gap-4">
                  <button
                    onClick={() => handleCopy(generatedContent, 0)}
                    disabled={!generatedContent || generatedContent.trim().length === 0}
                    className="flex-1 min-w-[200px] flex items-center justify-center gap-2 px-6 py-4 bg-slate-100 text-slate-700 rounded-lg font-semibold hover:bg-slate-200 transition-all disabled:bg-slate-50 disabled:text-slate-400 disabled:cursor-not-allowed"
                    aria-label="Copy generated text to clipboard"
                    title="Copy generated text to clipboard"
                  >
                    {copiedIndex === 0 ? (
                      <>
                        <Icons.Check className="w-5 h-5 text-green-600" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Icons.Copy className="w-5 h-5" />
                        Copy
                      </>
                    )}
                  </button>
                  <button
                    onClick={onRegenerate}
                    disabled={isLoading}
                    className="flex-1 min-w-[200px] flex items-center justify-center gap-2 px-6 py-4 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-all shadow-lg hover:shadow-xl disabled:bg-slate-300 disabled:cursor-not-allowed"
                  >
                    <Icons.RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
                    {isLoading ? 'Regenerating...' : 'Regenerate'}
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={isSaving}
                    className="flex-1 min-w-[200px] flex items-center justify-center gap-2 px-6 py-4 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-700 transition-all disabled:bg-slate-300 shadow-lg hover:shadow-xl"
                  >
                    {saveSuccess ? (
                      <>
                        <Icons.Check className="w-5 h-5" />
                        Saved!
                      </>
                    ) : (
                      <>
                        <Icons.Save className="w-5 h-5" />
                        {isSaving ? 'Saving...' : 'Save'}
                      </>
                    )}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
