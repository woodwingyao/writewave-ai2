import * as Icons from 'lucide-react';

interface SuccessPageProps {
  onGoHome: () => void;
}

export default function SuccessPage({ onGoHome }: SuccessPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 flex items-center justify-center px-4">
      <div className="max-w-2xl w-full">
        <div className="bg-white rounded-2xl shadow-2xl p-8 md:p-12 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-green-400 to-green-600 rounded-full mb-6 animate-bounce">
            <Icons.CheckCircle className="w-12 h-12 text-white" />
          </div>

          <h1 className="text-4xl font-bold text-slate-900 mb-4">
            Welcome to Pro!
          </h1>

          <p className="text-xl text-slate-600 mb-8">
            Your subscription is now active and all Pro features are unlocked.
          </p>

          <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl p-6 mb-8">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              You now have access to:
            </h2>
            <div className="grid md:grid-cols-2 gap-4 text-left">
              <div className="flex items-center gap-3">
                <Icons.Zap className="w-5 h-5 text-blue-600 flex-shrink-0" />
                <span className="text-sm text-slate-700">Unlimited AI generations</span>
              </div>
              <div className="flex items-center gap-3">
                <Icons.FileText className="w-5 h-5 text-blue-600 flex-shrink-0" />
                <span className="text-sm text-slate-700">Long-form content</span>
              </div>
              <div className="flex items-center gap-3">
                <Icons.Palette className="w-5 h-5 text-blue-600 flex-shrink-0" />
                <span className="text-sm text-slate-700">All writing styles</span>
              </div>
              <div className="flex items-center gap-3">
                <Icons.Star className="w-5 h-5 text-blue-600 flex-shrink-0" />
                <span className="text-sm text-slate-700">Priority support</span>
              </div>
              <div className="flex items-center gap-3">
                <Icons.Clock className="w-5 h-5 text-blue-600 flex-shrink-0" />
                <span className="text-sm text-slate-700">Unlimited history</span>
              </div>
              <div className="flex items-center gap-3">
                <Icons.Layout className="w-5 h-5 text-blue-600 flex-shrink-0" />
                <span className="text-sm text-slate-700">Advanced templates</span>
              </div>
            </div>
          </div>

          <button
            onClick={onGoHome}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl"
          >
            <Icons.Home className="w-5 h-5" />
            Start Creating Content
          </button>

          <p className="mt-6 text-sm text-slate-500">
            A confirmation email has been sent to your inbox
          </p>
        </div>
      </div>
    </div>
  );
}
