import { useState } from 'react';
import * as Icons from 'lucide-react';

interface PaywallPageProps {
  userEmail: string | null;
  onBack: () => void;
}

export default function PaywallPage({ userEmail, onBack }: PaywallPageProps) {
  const [isLoadingMonthly, setIsLoadingMonthly] = useState(false);
  const [isLoadingYearly, setIsLoadingYearly] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleUpgrade = async (plan: 'monthly' | 'yearly') => {
    if (!userEmail) {
      setError('Please sign in to upgrade');
      return;
    }

    const priceId = plan === 'monthly'
      ? import.meta.env.VITE_STRIPE_MONTHLY_PRICE_ID
      : import.meta.env.VITE_STRIPE_YEARLY_PRICE_ID;

    if (!priceId) {
      setError('Subscription not configured. Please contact support.');
      return;
    }

    const setLoading = plan === 'monthly' ? setIsLoadingMonthly : setIsLoadingYearly;
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-checkout`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            priceId,
            email: userEmail,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to create checkout session');
      }

      window.location.href = data.url;
    } catch (err) {
      console.error('Checkout error:', err);
      setError(err instanceof Error ? err.message : 'Failed to start checkout');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-8 transition-colors group"
          >
            <Icons.ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            Back to Home
          </button>

          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl mb-6">
              <Icons.Sparkles className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
              Unlock the Full Power of AI Copywriter
            </h1>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto">
              Upgrade to Pro and get unlimited access to advanced features
            </p>
          </div>

          {error && (
            <div className="mb-8 max-w-2xl mx-auto bg-red-50 border-l-4 border-red-500 p-4 rounded">
              <p className="text-sm text-red-700 flex items-center gap-2">
                <Icons.AlertCircle className="w-4 h-4" />
                {error}
              </p>
            </div>
          )}

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="bg-white rounded-2xl shadow-xl p-8 border-2 border-slate-200 hover:border-blue-400 transition-all">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Monthly</h3>
                <div className="flex items-baseline justify-center gap-2">
                  <span className="text-5xl font-bold text-blue-600">$9.99</span>
                  <span className="text-slate-600">/month</span>
                </div>
                <p className="text-sm text-slate-500 mt-2">Billed monthly, cancel anytime</p>
              </div>
              <button
                onClick={() => handleUpgrade('monthly')}
                disabled={isLoadingMonthly || !userEmail}
                className="w-full bg-blue-600 text-white py-4 rounded-lg font-semibold hover:bg-blue-700 transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl disabled:bg-slate-300 disabled:cursor-not-allowed"
              >
                {isLoadingMonthly ? (
                  <>
                    <Icons.Loader2 className="w-5 h-5 animate-spin" />
                    Loading...
                  </>
                ) : (
                  <>
                    <Icons.Zap className="w-5 h-5" />
                    Subscribe Now
                  </>
                )}
              </button>
            </div>

            <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl shadow-2xl p-8 border-2 border-purple-500 relative overflow-hidden">
              <div className="absolute top-4 right-4 bg-yellow-400 text-slate-900 px-3 py-1 rounded-full text-xs font-bold">
                BEST VALUE
              </div>
              <div className="text-center mb-6 text-white">
                <h3 className="text-2xl font-bold mb-2">Yearly</h3>
                <div className="flex items-baseline justify-center gap-2">
                  <span className="text-5xl font-bold">$79</span>
                  <span className="text-blue-100">/year</span>
                </div>
                <p className="text-sm text-blue-100 mt-2">Save $40 compared to monthly</p>
              </div>
              <button
                onClick={() => handleUpgrade('yearly')}
                disabled={isLoadingYearly || !userEmail}
                className="w-full bg-white text-purple-600 py-4 rounded-lg font-semibold hover:bg-blue-50 transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl disabled:bg-slate-300 disabled:cursor-not-allowed disabled:text-slate-500"
              >
                {isLoadingYearly ? (
                  <>
                    <Icons.Loader2 className="w-5 h-5 animate-spin" />
                    Loading...
                  </>
                ) : (
                  <>
                    <Icons.Crown className="w-5 h-5" />
                    Subscribe Now
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-8 text-center">
              What's included in Pro
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Icons.Check className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">Unlimited Generations</h3>
                  <p className="text-sm text-slate-600">Generate as much content as you need with no limits</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Icons.Check className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">Long-form Writing</h3>
                  <p className="text-sm text-slate-600">Create detailed blog posts and articles up to 2000 words</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Icons.Check className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">All Writing Styles</h3>
                  <p className="text-sm text-slate-600">Access to all 10 writing styles and unlimited tones</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Icons.Check className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">Priority Support</h3>
                  <p className="text-sm text-slate-600">Fast response times and dedicated support</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Icons.Check className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">Saved History</h3>
                  <p className="text-sm text-slate-600">Keep unlimited copies in your history</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Icons.Check className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">Advanced Templates</h3>
                  <p className="text-sm text-slate-600">Access premium templates and formats</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 text-center text-sm text-slate-500">
            <p>Secure payment processing by Stripe</p>
            <p className="mt-2">Cancel anytime, no long-term commitment required.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
