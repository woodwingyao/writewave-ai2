import { useState } from 'react';
import { ArrowLeft, Share2, Twitter, Facebook, Linkedin, Instagram, Chrome, Zap, CheckCircle } from 'lucide-react';

interface IntegrationsPageProps {
  onBack: () => void;
}

interface Integration {
  id: string;
  name: string;
  description: string;
  icon: any;
  color: string;
  connected: boolean;
  comingSoon?: boolean;
}

export default function IntegrationsPage({ onBack }: IntegrationsPageProps) {
  const [integrations, setIntegrations] = useState<Integration[]>([
    {
      id: 'twitter',
      name: 'Twitter/X',
      description: 'Share content directly to Twitter',
      icon: Twitter,
      color: 'bg-blue-400',
      connected: false,
      comingSoon: true
    },
    {
      id: 'facebook',
      name: 'Facebook',
      description: 'Post to Facebook pages and groups',
      icon: Facebook,
      color: 'bg-blue-600',
      connected: false,
      comingSoon: true
    },
    {
      id: 'linkedin',
      name: 'LinkedIn',
      description: 'Share professional content to LinkedIn',
      icon: Linkedin,
      color: 'bg-blue-700',
      connected: false,
      comingSoon: true
    },
    {
      id: 'instagram',
      name: 'Instagram',
      description: 'Create Instagram captions and posts',
      icon: Instagram,
      color: 'bg-pink-600',
      connected: false,
      comingSoon: true
    },
    {
      id: 'wordpress',
      name: 'WordPress',
      description: 'Publish content to WordPress sites',
      icon: Chrome,
      color: 'bg-gray-800',
      connected: false,
      comingSoon: true
    },
    {
      id: 'zapier',
      name: 'Zapier',
      description: 'Connect to thousands of apps via Zapier',
      icon: Zap,
      color: 'bg-orange-500',
      connected: false,
      comingSoon: true
    }
  ]);

  const handleConnect = (id: string) => {
    alert('This integration will be available soon! Stay tuned for updates.');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Share2 className="w-10 h-10 text-pink-600" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">Integrations</h1>
          </div>
          <p className="text-gray-600 dark:text-gray-300">
            Connect to social media, WordPress, and more
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {integrations.map(integration => {
            const Icon = integration.icon;
            return (
              <div
                key={integration.id}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm hover:shadow-lg transition-all"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`${integration.color} w-14 h-14 rounded-xl flex items-center justify-center`}>
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  {integration.connected && (
                    <div className="flex items-center gap-1 text-green-600 text-sm">
                      <CheckCircle className="w-4 h-4" />
                      Connected
                    </div>
                  )}
                </div>

                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                  {integration.name}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  {integration.description}
                </p>

                {integration.comingSoon ? (
                  <div className="text-center">
                    <span className="inline-block text-sm bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-4 py-2 rounded-lg">
                      Coming Soon
                    </span>
                  </div>
                ) : (
                  <button
                    onClick={() => handleConnect(integration.id)}
                    disabled={integration.connected}
                    className={`w-full px-6 py-3 rounded-lg transition-all ${
                      integration.connected
                        ? 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 cursor-not-allowed'
                        : 'bg-blue-600 text-white hover:bg-blue-700'
                    }`}
                  >
                    {integration.connected ? 'Connected' : 'Connect'}
                  </button>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-12 bg-gradient-to-r from-pink-600 to-orange-600 rounded-2xl p-8 text-white">
          <h2 className="text-3xl font-bold mb-3">Need a Custom Integration?</h2>
          <p className="text-lg opacity-90 mb-6">
            We're constantly adding new integrations. Let us know which platforms you'd like to see next!
          </p>
          <button className="bg-white text-pink-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-all">
            Request Integration
          </button>
        </div>
      </div>
    </div>
  );
}
