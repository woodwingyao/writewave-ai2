import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { ArrowLeft, Calendar, Clock, CheckCircle, XCircle, Send } from 'lucide-react';

interface ContentCalendarPageProps {
  onBack: () => void;
}

interface ScheduledContent {
  id: string;
  content_id: string;
  scheduled_for: string;
  platform: string;
  status: string;
  published_at: string | null;
  error_message: string | null;
  saved_copies: {
    content: string;
    topic: string;
  };
}

export default function ContentCalendarPage({ onBack }: ContentCalendarPageProps) {
  const [scheduled, setScheduled] = useState<ScheduledContent[]>([]);
  const [savedContent, setSavedContent] = useState<any[]>([]);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [loading, setLoading] = useState(false);

  const [newSchedule, setNewSchedule] = useState({
    content_id: '',
    scheduled_for: '',
    platform: 'twitter'
  });

  useEffect(() => {
    loadScheduledContent();
    loadSavedContent();
  }, []);

  const loadScheduledContent = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('scheduled_content')
        .select(`
          *,
          saved_copies (
            content,
            topic
          )
        `)
        .eq('user_id', user.id)
        .order('scheduled_for', { ascending: true });

      if (error) throw error;
      setScheduled(data || []);
    } catch (err) {
      console.error('Error loading scheduled content:', err);
    }
  };

  const loadSavedContent = async () => {
    try {
      const { data, error } = await supabase
        .from('saved_copies')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      setSavedContent(data || []);
    } catch (err) {
      console.error('Error loading saved content:', err);
    }
  };

  const handleSchedule = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('scheduled_content')
        .insert({
          user_id: user.id,
          content_id: newSchedule.content_id,
          scheduled_for: newSchedule.scheduled_for,
          platform: newSchedule.platform
        });

      if (error) throw error;

      setShowScheduleModal(false);
      setNewSchedule({ content_id: '', scheduled_for: '', platform: 'twitter' });
      loadScheduledContent();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'published': return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'failed': return <XCircle className="w-5 h-5 text-red-500" />;
      case 'cancelled': return <XCircle className="w-5 h-5 text-gray-500" />;
      default: return <Clock className="w-5 h-5 text-blue-500" />;
    }
  };

  const getPlatformColor = (platform: string) => {
    const colors: Record<string, string> = {
      twitter: 'bg-blue-100 text-blue-700',
      linkedin: 'bg-blue-100 text-blue-700',
      facebook: 'bg-blue-100 text-blue-700',
      instagram: 'bg-pink-100 text-pink-700',
      email: 'bg-gray-100 text-gray-700'
    };
    return colors[platform] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">Content Calendar</h1>
            <p className="text-gray-600 dark:text-gray-300">Schedule content for future publication</p>
          </div>
          <button
            onClick={() => setShowScheduleModal(true)}
            className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 transition-all"
          >
            <Calendar className="w-5 h-5" />
            Schedule Content
          </button>
        </div>

        <div className="space-y-4">
          {scheduled.map(item => (
            <div key={item.id} className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm hover:shadow-md transition-all">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4 flex-1">
                  {getStatusIcon(item.status)}
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                      {item.saved_copies?.topic || 'Untitled'}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300 mb-3 line-clamp-2">
                      {item.saved_copies?.content}
                    </p>
                    <div className="flex items-center gap-3">
                      <span className={`text-xs px-3 py-1 rounded-full ${getPlatformColor(item.platform)}`}>
                        {item.platform}
                      </span>
                      <span className="text-sm text-gray-600 dark:text-gray-300">
                        {new Date(item.scheduled_for).toLocaleString()}
                      </span>
                    </div>
                    {item.error_message && (
                      <p className="text-sm text-red-600 mt-2">{item.error_message}</p>
                    )}
                  </div>
                </div>
                <span className={`text-xs font-medium px-3 py-1 rounded-full ${
                  item.status === 'published' ? 'bg-green-100 text-green-700' :
                  item.status === 'failed' ? 'bg-red-100 text-red-700' :
                  item.status === 'cancelled' ? 'bg-gray-100 text-gray-700' :
                  'bg-blue-100 text-blue-700'
                }`}>
                  {item.status}
                </span>
              </div>
            </div>
          ))}

          {scheduled.length === 0 && (
            <div className="text-center py-12">
              <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-300">No scheduled content yet</p>
            </div>
          )}
        </div>
      </div>

      {showScheduleModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowScheduleModal(false)}>
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-md w-full mx-4" onClick={e => e.stopPropagation()}>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Schedule Content</h2>
            <form onSubmit={handleSchedule} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Select Content
                </label>
                <select
                  value={newSchedule.content_id}
                  onChange={e => setNewSchedule({ ...newSchedule, content_id: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                  required
                >
                  <option value="">Select content...</option>
                  {savedContent.map(content => (
                    <option key={content.id} value={content.id}>
                      {content.topic || content.content.substring(0, 50)}...
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Schedule Date & Time
                </label>
                <input
                  type="datetime-local"
                  value={newSchedule.scheduled_for}
                  onChange={e => setNewSchedule({ ...newSchedule, scheduled_for: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Platform
                </label>
                <select
                  value={newSchedule.platform}
                  onChange={e => setNewSchedule({ ...newSchedule, platform: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                >
                  <option value="twitter">Twitter</option>
                  <option value="linkedin">LinkedIn</option>
                  <option value="facebook">Facebook</option>
                  <option value="instagram">Instagram</option>
                  <option value="email">Email</option>
                </select>
              </div>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowScheduleModal(false)}
                  className="flex-1 px-4 py-2 border rounded-lg hover:bg-gray-50 dark:border-gray-600"
                  disabled={loading}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                  disabled={loading}
                >
                  {loading ? 'Scheduling...' : 'Schedule'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
