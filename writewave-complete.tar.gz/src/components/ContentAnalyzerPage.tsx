import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { ArrowLeft, Brain, CheckCircle, AlertCircle, TrendingUp, BookOpen, Zap } from 'lucide-react';

interface ContentAnalyzerPageProps {
  onBack: () => void;
}

interface SavedContent {
  id: string;
  content: string;
  topic: string;
}

interface AnalysisResult {
  tone: string;
  readability: string;
  seo_score: number;
  grammar_issues: string[];
  suggestions: string[];
}

export default function ContentAnalyzerPage({ onBack }: ContentAnalyzerPageProps) {
  const [savedContent, setSavedContent] = useState<SavedContent[]>([]);
  const [selectedContent, setSelectedContent] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  useEffect(() => {
    loadSavedContent();
  }, []);

  const loadSavedContent = async () => {
    try {
      const { data, error } = await supabase
        .from('saved_copies')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setSavedContent(data || []);
    } catch (err) {
      console.error('Error loading content:', err);
    }
  };

  const analyzeContent = async () => {
    const content = savedContent.find(c => c.id === selectedContent);
    if (!content) return;

    setAnalyzing(true);
    try {
      const wordCount = content.content.split(/\s+/).length;
      const sentenceCount = content.content.split(/[.!?]+/).length;
      const avgWordsPerSentence = wordCount / sentenceCount;

      let readabilityLevel = 'Advanced';
      if (avgWordsPerSentence < 15) readabilityLevel = 'Easy';
      else if (avgWordsPerSentence < 20) readabilityLevel = 'Moderate';

      const hasKeywords = /fitness|health|workday|energy|professional/i.test(content.content);
      const seoScore = hasKeywords ? 85 : 65;

      const mockAnalysis: AnalysisResult = {
        tone: 'Professional and engaging',
        readability: readabilityLevel,
        seo_score: seoScore,
        grammar_issues: [],
        suggestions: [
          'Consider adding more specific keywords for better SEO',
          'Include a call-to-action to increase engagement',
          'Break longer sentences into shorter ones for better readability'
        ]
      };

      setTimeout(() => {
        setAnalysis(mockAnalysis);
        setAnalyzing(false);
      }, 1500);
    } catch (err) {
      console.error('Analysis error:', err);
      setAnalyzing(false);
    }
  };

  const content = savedContent.find(c => c.id === selectedContent);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Brain className="w-10 h-10 text-purple-600" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">Content Analyzer</h1>
          </div>
          <p className="text-gray-600 dark:text-gray-300">
            Analyze tone, readability, SEO, and grammar
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Select Content</h2>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {savedContent.map(item => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setSelectedContent(item.id);
                      setAnalysis(null);
                    }}
                    className={`w-full text-left p-3 rounded-lg transition-all ${
                      selectedContent === item.id
                        ? 'bg-purple-100 dark:bg-purple-900 ring-2 ring-purple-600'
                        : 'bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600'
                    }`}
                  >
                    <p className="font-medium text-gray-900 dark:text-white text-sm">
                      {item.topic || 'Untitled'}
                    </p>
                    <p className="text-xs text-gray-600 dark:text-gray-300 mt-1 line-clamp-2">
                      {item.content}
                    </p>
                  </button>
                ))}
              </div>

              {selectedContent && (
                <button
                  onClick={analyzeContent}
                  disabled={analyzing}
                  className="w-full mt-4 bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
                >
                  <Brain className="w-5 h-5" />
                  {analyzing ? 'Analyzing...' : 'Analyze'}
                </button>
              )}
            </div>
          </div>

          <div className="lg:col-span-2">
            {content ? (
              <div className="space-y-6">
                <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Content</h2>
                  <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{content.content}</p>
                </div>

                {analysis && (
                  <>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
                        <div className="flex items-center gap-3 mb-2">
                          <Zap className="w-6 h-6 text-yellow-600" />
                          <h3 className="font-bold text-gray-900 dark:text-white">Tone</h3>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300">{analysis.tone}</p>
                      </div>

                      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
                        <div className="flex items-center gap-3 mb-2">
                          <BookOpen className="w-6 h-6 text-blue-600" />
                          <h3 className="font-bold text-gray-900 dark:text-white">Readability</h3>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300">{analysis.readability}</p>
                      </div>

                      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
                        <div className="flex items-center gap-3 mb-2">
                          <TrendingUp className="w-6 h-6 text-green-600" />
                          <h3 className="font-bold text-gray-900 dark:text-white">SEO Score</h3>
                        </div>
                        <p className="text-3xl font-bold text-gray-900 dark:text-white">{analysis.seo_score}/100</p>
                      </div>
                    </div>

                    {analysis.grammar_issues.length > 0 && (
                      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
                        <div className="flex items-center gap-3 mb-4">
                          <AlertCircle className="w-6 h-6 text-red-600" />
                          <h3 className="text-xl font-bold text-gray-900 dark:text-white">Grammar Issues</h3>
                        </div>
                        <ul className="space-y-2">
                          {analysis.grammar_issues.map((issue, idx) => (
                            <li key={idx} className="text-gray-700 dark:text-gray-300 flex items-start gap-2">
                              <span className="text-red-600 mt-1">•</span>
                              {issue}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
                      <div className="flex items-center gap-3 mb-4">
                        <CheckCircle className="w-6 h-6 text-green-600" />
                        <h3 className="text-xl font-bold text-gray-900 dark:text-white">Suggestions</h3>
                      </div>
                      <ul className="space-y-3">
                        {analysis.suggestions.map((suggestion, idx) => (
                          <li key={idx} className="text-gray-700 dark:text-gray-300 flex items-start gap-2">
                            <span className="text-green-600 mt-1">•</span>
                            {suggestion}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="bg-white dark:bg-gray-800 rounded-xl p-12 text-center">
                <Brain className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-300">Select content to analyze</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
