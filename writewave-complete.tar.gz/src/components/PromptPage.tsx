import { useState } from 'react';
import { tones, promptTemplates, writingStyles } from '../lib/templates';
import * as Icons from 'lucide-react';

interface PromptPageProps {
  onGenerate: (data: PromptGenerateData) => void;
  onBack: () => void;
}

export interface PromptGenerateData {
  prompt: string;
  tone: string;
  templateId: string;
  styleId: string;
}

export default function PromptPage({ onGenerate, onBack }: PromptPageProps) {
  const [userPrompt, setUserPrompt] = useState('');
  const [tone, setTone] = useState(tones[0]);
  const [templateId, setTemplateId] = useState('freeform');
  const [styleId, setStyleId] = useState('short-form');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!userPrompt.trim()) {
      setError('Please enter something for me to write.');
      return;
    }

    onGenerate({
      prompt: userPrompt,
      tone,
      templateId,
      styleId
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-8 transition-colors group"
          >
            <Icons.ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            Back to Home
          </button>

          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-slate-900 mb-2">
                Write Anything, Instantly
              </h1>
              <p className="text-slate-600">
                Enter your idea, pick a tone, and let AI transform it into polished copy.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-3">
                  What do you want written?
                  <span className="text-red-500 ml-1">*</span>
                </label>
                <textarea
                  value={userPrompt}
                  onChange={(e) => {
                    setUserPrompt(e.target.value);
                    setError('');
                  }}
                  placeholder="e.g., Promote my new fitness class for busy office workers.

Anything you want written: product descriptions, social posts, emails, article ideas, headlines..."
                  rows={8}
                  className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 focus:border-blue-500 focus:outline-none transition-colors resize-none text-base"
                />
                {error && (
                  <p className="mt-2 text-sm text-red-600 flex items-center gap-2">
                    <Icons.AlertCircle className="w-4 h-4" />
                    {error}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-3">
                    Choose Tone
                    <span className="text-red-500 ml-1">*</span>
                  </label>
                  <select
                    value={tone}
                    onChange={(e) => setTone(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 focus:border-blue-500 focus:outline-none transition-colors bg-white cursor-pointer"
                  >
                    {tones.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                  <p className="text-xs text-slate-500 mt-1">Emotion & personality</p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-3">
                    Writing Style
                    <span className="text-red-500 ml-1">*</span>
                  </label>
                  <select
                    value={styleId}
                    onChange={(e) => setStyleId(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 focus:border-blue-500 focus:outline-none transition-colors bg-white cursor-pointer"
                  >
                    {writingStyles.map((style) => (
                      <option key={style.id} value={style.id}>
                        {style.name}
                      </option>
                    ))}
                  </select>
                  <p className="text-xs text-slate-500 mt-1">Structure & rhythm</p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-3">
                    Choose Format
                    <span className="text-red-500 ml-1">*</span>
                  </label>
                  <select
                    value={templateId}
                    onChange={(e) => setTemplateId(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 focus:border-blue-500 focus:outline-none transition-colors bg-white cursor-pointer"
                  >
                    {promptTemplates.map((template) => (
                      <option key={template.id} value={template.id}>
                        {template.name}
                      </option>
                    ))}
                  </select>
                  <p className="text-xs text-slate-500 mt-1">Content type</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                  <p className="text-xs text-blue-700 font-semibold mb-1">FORMAT</p>
                  <p className="text-sm text-blue-900">
                    {promptTemplates.find((t) => t.id === templateId)?.description}
                  </p>
                </div>
                <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
                  <p className="text-xs text-purple-700 font-semibold mb-1">STYLE</p>
                  <p className="text-sm text-purple-900">
                    {writingStyles.find((s) => s.id === styleId)?.description}
                  </p>
                </div>
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-4 rounded-lg font-semibold hover:bg-blue-700 transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl"
                >
                  <Icons.Sparkles className="w-5 h-5" />
                  Generate Content
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
