import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { ArrowLeft, Folder, Plus, Tag, Search, FileText, Trash2, Edit } from 'lucide-react';

interface ContentLibraryPageProps {
  onBack: () => void;
}

interface Folder {
  id: string;
  name: string;
  color: string;
  count: number;
}

interface ContentItem {
  id: string;
  topic: string;
  content: string;
  folder: string;
  tags: string[];
  created_at: string;
}

export default function ContentLibraryPage({ onBack }: ContentLibraryPageProps) {
  const [folders, setFolders] = useState<Folder[]>([
    { id: 'all', name: 'All Content', color: 'bg-gray-500', count: 0 },
    { id: 'marketing', name: 'Marketing', color: 'bg-blue-500', count: 0 },
    { id: 'social', name: 'Social Media', color: 'bg-pink-500', count: 0 },
    { id: 'email', name: 'Email', color: 'bg-green-500', count: 0 }
  ]);
  const [selectedFolder, setSelectedFolder] = useState('all');
  const [content, setContent] = useState<ContentItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewFolderForm, setShowNewFolderForm] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');

  useEffect(() => {
    loadContent();
  }, []);

  const loadContent = async () => {
    try {
      const { data, error } = await supabase
        .from('saved_copies')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const items = (data || []).map(item => ({
        id: item.id,
        topic: item.topic || 'Untitled',
        content: item.content,
        folder: 'marketing',
        tags: ['copywriting'],
        created_at: item.created_at
      }));

      setContent(items);

      const updatedFolders = [...folders];
      updatedFolders[0].count = items.length;
      setFolders(updatedFolders);
    } catch (err) {
      console.error('Error loading content:', err);
    }
  };

  const filteredContent = content.filter(item => {
    const matchesFolder = selectedFolder === 'all' || item.folder === selectedFolder;
    const matchesSearch = item.topic.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.content.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFolder && matchesSearch;
  });

  const handleCreateFolder = () => {
    if (!newFolderName.trim()) return;

    const colors = ['bg-purple-500', 'bg-orange-500', 'bg-cyan-500', 'bg-red-500'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];

    setFolders([...folders, {
      id: newFolderName.toLowerCase().replace(/\s+/g, '-'),
      name: newFolderName,
      color: randomColor,
      count: 0
    }]);

    setNewFolderName('');
    setShowNewFolderForm(false);
  };

  const handleDeleteContent = async (id: string) => {
    if (!confirm('Delete this content?')) return;

    try {
      const { error } = await supabase
        .from('saved_copies')
        .delete()
        .eq('id', id);

      if (error) throw error;
      loadContent();
    } catch (err) {
      console.error('Error deleting content:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Folder className="w-10 h-10 text-yellow-600" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">Content Library</h1>
          </div>
          <p className="text-gray-600 dark:text-gray-300">
            Organize content with folders and tags
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Folders</h2>
                <button
                  onClick={() => setShowNewFolderForm(true)}
                  className="text-blue-600 hover:text-blue-700"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>

              {showNewFolderForm && (
                <div className="mb-4">
                  <input
                    type="text"
                    value={newFolderName}
                    onChange={e => setNewFolderName(e.target.value)}
                    placeholder="Folder name"
                    className="w-full px-3 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white text-sm mb-2"
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={handleCreateFolder}
                      className="flex-1 bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700"
                    >
                      Create
                    </button>
                    <button
                      onClick={() => {
                        setShowNewFolderForm(false);
                        setNewFolderName('');
                      }}
                      className="flex-1 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-3 py-1 rounded text-sm"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                {folders.map(folder => (
                  <button
                    key={folder.id}
                    onClick={() => setSelectedFolder(folder.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all ${
                      selectedFolder === folder.id
                        ? 'bg-blue-100 dark:bg-blue-900'
                        : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    <div className={`${folder.color} w-10 h-10 rounded-lg flex items-center justify-center`}>
                      <Folder className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-medium text-gray-900 dark:text-white text-sm">{folder.name}</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">{folder.count} items</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  placeholder="Search content..."
                  className="w-full pl-10 pr-4 py-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                />
              </div>
            </div>

            <div className="space-y-4">
              {filteredContent.map(item => (
                <div key={item.id} className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm hover:shadow-md transition-all">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                        {item.topic}
                      </h3>
                      <div className="flex gap-2 mb-3">
                        {item.tags.map(tag => (
                          <span key={tag} className="flex items-center gap-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-2 py-1 rounded-full">
                            <Tag className="w-3 h-3" />
                            {tag}
                          </span>
                        ))}
                      </div>
                      <p className="text-gray-600 dark:text-gray-300 line-clamp-2">
                        {item.content}
                      </p>
                    </div>
                    <div className="flex gap-2 ml-4">
                      <button className="text-blue-600 hover:text-blue-700 p-2">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteContent(item.id)}
                        className="text-red-600 hover:text-red-700 p-2"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Created {new Date(item.created_at).toLocaleDateString()}
                  </p>
                </div>
              ))}
            </div>

            {filteredContent.length === 0 && (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-300">No content found</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
