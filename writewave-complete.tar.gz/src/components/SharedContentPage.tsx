import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import * as Icons from 'lucide-react';
import { templates } from '../lib/templates';
import { exportToTXT, exportToHTML, exportToMarkdown, exportToPDF, exportToDOCX } from '../lib/exportUtils';

interface SharedContentPageProps {
  shareToken: string;
}

export default function SharedContentPage({ shareToken }: SharedContentPageProps) {
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [showExportMenu, setShowExportMenu] = useState(false);

  useEffect(() => {
    loadSharedContent();
  }, [shareToken]);

  const loadSharedContent = async () => {
    try {
      const { data, error } = await supabase
        .from('shared_content')
        .select('*')
        .eq('share_token', shareToken)
        .maybeSingle();

      if (error) throw error;

      if (!data) {
        setError('Content not found or has been removed');
        setLoading(false);
        return;
      }

      if (data.expires_at && new Date(data.expires_at) < new Date()) {
        setError('This shared content has expired');
        setLoading(false);
        return;
      }

      setContent(data);

      await supabase
        .from('shared_content')
        .update({ view_count: (data.view_count || 0) + 1 })
        .eq('id', data.id);

    } catch (err: any) {
      setError(err.message || 'Failed to load shared content');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async (text: string, index: number) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const handleExport = (format: 'txt' | 'html' | 'md' | 'pdf' | 'docx') => {
    if (!content) return;

    const filename = `${content.topic || 'shared-content'}-${Date.now()}`;
    const metadata = {
      topic: content.topic,
      tone: content.tone,
      audience: content.audience
    };

    switch (format) {
      case 'txt':
        exportToTXT(content.content, filename);
        break;
      case 'html':
        exportToHTML(content.content, filename);
        break;
      case 'md':
        exportToMarkdown(content.content, filename);
        break;
      case 'pdf':
        exportToPDF(content.content, filename, metadata);
        break;
      case 'docx':
        exportToDOCX(content.content, filename, metadata);
        break;
    }

    setShowExportMenu(false);
  };

  const template = content ? templates.find((t) => t.id === content.template_id) : null;
  const IconComponent = template
    ? (Icons as Record<string, React.ComponentType<{ className?: string }>>)[template.icon]
    : null;

  const variations = content
    ? content.content
        .split(/---VARIATION---|(?=\d+\.|Version \d+|# Version \d+)/g)
        .filter((v: string) => v.trim().length > 10)
        .map((v: string) => v.replace(/^---VARIATION---\s*/g, '').trim())
    : [];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100 dark:from-slate-900 dark:to-slate-800 flex items-center justify-center">
        <div className="text-center">
          <Icons.Share2 className="w-16 h-16 text-blue-600 mx-auto mb-4 animate-pulse" />
          <p className="text-slate-600 dark:text-slate-300 text-lg">Loading shared content...</p>
        </div>
      </div>
    );
  }

  if (error || !content) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100 dark:from-slate-900 dark:to-slate-800 flex items-center justify-center p-4">
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg p-8 max-w-md w-full text-center">
          <Icons.AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Content Not Found</h2>
          <p className="text-slate-600 dark:text-slate-300">{error || 'This content is not available'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg p-8 md:p-12">
            <div className="flex items-start gap-4 mb-8">
              <div className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-xl">
                {IconComponent && <IconComponent className="w-8 h-8 text-blue-600 dark:text-blue-400" />}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
                    {template?.name || 'Shared Content'}
                  </h1>
                  <Icons.Share2 className="w-5 h-5 text-slate-400" />
                </div>
                <div className="flex flex-wrap gap-2 text-sm text-slate-600 dark:text-slate-300">
                  {content.topic && (
                    <span className="bg-slate-100 dark:bg-slate-700 px-3 py-1 rounded-full">
                      {content.topic}
                    </span>
                  )}
                  {content.tone && (
                    <span className="bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 px-3 py-1 rounded-full">
                      {content.tone}
                    </span>
                  )}
                  {content.audience && (
                    <span className="bg-slate-100 dark:bg-slate-700 px-3 py-1 rounded-full">
                      {content.audience}
                    </span>
                  )}
                </div>
                {content.view_count > 0 && (
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
                    <Icons.Eye className="w-4 h-4 inline mr-1" />
                    {content.view_count} views
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-6 mb-8">
              {variations.length > 1 ? (
                variations.map((variation: string, index: number) => (
                  <div
                    key={index}
                    className="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-6 border-2 border-slate-200 dark:border-slate-600 hover:border-blue-300 dark:hover:border-blue-500 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-4 mb-4">
                      <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                        Option {index + 1}
                      </h3>
                      <button
                        onClick={() => handleCopy(variation.trim(), index)}
                        className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-500 transition-all text-sm font-medium shadow-sm hover:shadow"
                      >
                        {copiedIndex === index ? (
                          <>
                            <Icons.Check className="w-4 h-4 text-green-600 dark:text-green-400" />
                            Copied!
                          </>
                        ) : (
                          <>
                            <Icons.Copy className="w-4 h-4" />
                            Copy
                          </>
                        )}
                      </button>
                    </div>
                    <p className="text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
                      {variation.trim()}
                    </p>
                  </div>
                ))
              ) : (
                <div className="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-6 border-2 border-slate-200 dark:border-slate-600">
                  <div className="flex items-start justify-between gap-4 mb-4">
                    <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                      Content
                    </h3>
                    <button
                      onClick={() => handleCopy(content.content, 0)}
                      className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-500 transition-all text-sm font-medium shadow-sm hover:shadow"
                    >
                      {copiedIndex === 0 ? (
                        <>
                          <Icons.Check className="w-4 h-4 text-green-600 dark:text-green-400" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Icons.Copy className="w-4 h-4" />
                          Copy
                        </>
                      )}
                    </button>
                  </div>
                  <p className="text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
                    {content.content}
                  </p>
                </div>
              )}
            </div>

            <div className="flex gap-4">
              <div className="relative">
                <button
                  onClick={() => setShowExportMenu(!showExportMenu)}
                  className="flex items-center justify-center gap-2 px-6 py-4 bg-slate-600 dark:bg-slate-700 text-white rounded-lg font-semibold hover:bg-slate-700 dark:hover:bg-slate-600 transition-all shadow-lg hover:shadow-xl"
                >
                  <Icons.Download className="w-5 h-5" />
                  Export
                </button>

                {showExportMenu && (
                  <div className="absolute bottom-full mb-2 left-0 bg-white dark:bg-slate-700 rounded-lg shadow-xl border-2 border-slate-200 dark:border-slate-600 py-2 z-10 min-w-[180px]">
                    <button
                      onClick={() => handleExport('pdf')}
                      className="w-full px-4 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-600 flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium"
                    >
                      <Icons.FileText className="w-4 h-4 text-red-600" />
                      PDF Document
                    </button>
                    <button
                      onClick={() => handleExport('docx')}
                      className="w-full px-4 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-600 flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium"
                    >
                      <Icons.FileText className="w-4 h-4 text-blue-600" />
                      Word Document
                    </button>
                    <div className="border-t border-slate-200 dark:border-slate-600 my-1"></div>
                    <button
                      onClick={() => handleExport('txt')}
                      className="w-full px-4 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-600 flex items-center gap-2 text-slate-600 dark:text-slate-300"
                    >
                      <Icons.FileText className="w-4 h-4" />
                      Text (.txt)
                    </button>
                    <button
                      onClick={() => handleExport('html')}
                      className="w-full px-4 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-600 flex items-center gap-2 text-slate-600 dark:text-slate-300"
                    >
                      <Icons.Code className="w-4 h-4" />
                      HTML (.html)
                    </button>
                    <button
                      onClick={() => handleExport('md')}
                      className="w-full px-4 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-600 flex items-center gap-2 text-slate-600 dark:text-slate-300"
                    >
                      <Icons.FileCode className="w-4 h-4" />
                      Markdown (.md)
                    </button>
                  </div>
                )}
              </div>

              <a
                href="/"
                className="flex items-center justify-center gap-2 px-6 py-4 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-all shadow-lg hover:shadow-xl"
              >
                <Icons.Sparkles className="w-5 h-5" />
                Create Your Own
              </a>
            </div>

            <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-600">
              <p className="text-sm text-slate-500 dark:text-slate-400 text-center">
                Powered by WriteWave AI - Generate amazing content in seconds
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
