import { useState, useEffect } from 'react';
import { templates, tones } from '../lib/templates';
import * as Icons from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useTheme } from '../lib/theme';

interface InputPageProps {
  templateId: string;
  onGenerate: (data: GenerateData) => void;
  onBack: () => void;
}

export interface GenerateData {
  templateId: string;
  topic: string;
  audience: string;
  tone: string;
  details: string;
  brandVoiceId?: string;
  variations?: number;
  length?: 'short' | 'medium' | 'long';
}

interface BrandVoice {
  id: string;
  name: string;
  tone: string;
  writing_style: string | null;
  key_phrases: string[] | null;
  avoid_phrases: string[] | null;
  example_text: string | null;
  is_default: boolean;
}

export default function InputPage({ templateId, onGenerate, onBack }: InputPageProps) {
  const { theme, toggleTheme } = useTheme();
  const template = templates.find((t) => t.id === templateId);
  const [topic, setTopic] = useState('');
  const [audience, setAudience] = useState('');
  const [tone, setTone] = useState(tones[0]);
  const [details, setDetails] = useState('');
  const [brandVoices, setBrandVoices] = useState<BrandVoice[]>([]);
  const [selectedBrandVoice, setSelectedBrandVoice] = useState<string>('');
  const [variations, setVariations] = useState(1);
  const [length, setLength] = useState<'short' | 'medium' | 'long'>('medium');

  useEffect(() => {
    loadBrandVoices();
  }, []);

  const loadBrandVoices = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('brand_voices')
        .select('*')
        .order('is_default', { ascending: false })
        .order('created_at', { ascending: false });

      if (error) throw error;

      if (data && data.length > 0) {
        setBrandVoices(data);
        const defaultVoice = data.find(v => v.is_default);
        if (defaultVoice) {
          setSelectedBrandVoice(defaultVoice.id);
          setTone(defaultVoice.tone);
        }
      }
    } catch (err) {
      console.error('Error loading brand voices:', err);
    }
  };

  if (!template) {
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim() && !isTextRewriter) return;

    onGenerate({
      templateId,
      topic,
      audience,
      tone,
      details,
      brandVoiceId: selectedBrandVoice || undefined,
      variations,
      length
    });
  };

  const IconComponent = (Icons as Record<string, React.ComponentType<{ className?: string }>>)[template.icon];
  const isTextRewriter = templateId === 'text-rewriter';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 transition-colors">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <button
              onClick={onBack}
              className="inline-flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors group"
            >
              <Icons.ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              Back to Templates
            </button>

            <button
              onClick={toggleTheme}
              className="inline-flex items-center justify-center p-3 bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-600 transition-all shadow-sm hover:shadow-md border-2 border-slate-200 dark:border-slate-600"
              title={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
            >
              {theme === 'light' ? (
                <Icons.Moon className="w-5 h-5" />
              ) : (
                <Icons.Sun className="w-5 h-5" />
              )}
            </button>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg p-8 md:p-12">
            <div className="flex items-start gap-4 mb-8">
              <div className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-xl">
                {IconComponent && <IconComponent className="w-8 h-8 text-blue-600" />}
              </div>
              <div>
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">
                  {template.name}
                </h1>
                <p className="text-slate-600 dark:text-slate-300">
                  {template.description}
                </p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {!isTextRewriter && (
                <div>
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">
                    Main Topic / Product Name
                    <span className="text-red-500 ml-1">*</span>
                  </label>
                  <input
                    type="text"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="e.g., Wireless Noise-Cancelling Headphones"
                    className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 dark:border-slate-600 focus:border-blue-500 dark:focus:border-blue-400 focus:outline-none transition-colors bg-white dark:bg-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500"
                    required
                  />
                </div>
              )}

              {!isTextRewriter && (
                <div>
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">
                    Target Audience
                    <span className="text-slate-400 ml-1 font-normal">(optional)</span>
                  </label>
                  <input
                    type="text"
                    value={audience}
                    onChange={(e) => setAudience(e.target.value)}
                    placeholder="e.g., Young professionals, Tech enthusiasts, Students"
                    className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 dark:border-slate-600 focus:border-blue-500 dark:focus:border-blue-400 focus:outline-none transition-colors bg-white dark:bg-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500"
                  />
                </div>
              )}

              {brandVoices.length > 0 && (
                <div>
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">
                    Brand Voice
                    <span className="text-slate-400 ml-1 font-normal">(optional)</span>
                  </label>
                  <select
                    value={selectedBrandVoice}
                    onChange={(e) => {
                      setSelectedBrandVoice(e.target.value);
                      const voice = brandVoices.find(v => v.id === e.target.value);
                      if (voice) setTone(voice.tone);
                    }}
                    className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 dark:border-slate-600 focus:border-blue-500 dark:focus:border-blue-400 focus:outline-none transition-colors bg-white dark:bg-slate-700 text-slate-900 dark:text-white cursor-pointer"
                  >
                    <option value="">None - Use custom settings</option>
                    {brandVoices.map((voice) => (
                      <option key={voice.id} value={voice.id}>
                        {voice.name} {voice.is_default ? '(Default)' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Tone of Voice
                  <span className="text-red-500 ml-1">*</span>
                </label>
                <select
                  value={tone}
                  onChange={(e) => setTone(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 focus:border-blue-500 focus:outline-none transition-colors bg-white cursor-pointer"
                  required
                  disabled={!!selectedBrandVoice}
                >
                  {tones.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
                {selectedBrandVoice && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Tone is set by your selected brand voice</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  {isTextRewriter ? 'Text to Rewrite' : 'Additional Details'}
                  <span className={isTextRewriter ? 'text-red-500 ml-1' : 'text-slate-400 ml-1 font-normal'}>
                    {isTextRewriter ? '*' : '(optional)'}
                  </span>
                </label>
                <textarea
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  placeholder={
                    isTextRewriter
                      ? 'Paste the text you want to rewrite here...'
                      : 'Any specific requirements, keywords, or context...'
                  }
                  rows={6}
                  className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 dark:border-slate-600 focus:border-blue-500 dark:focus:border-blue-400 focus:outline-none transition-colors resize-none bg-white dark:bg-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500"
                  required={isTextRewriter}
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Content Length
                </label>
                <div className="flex gap-2">
                  {[
                    { value: 'short', label: 'Short', desc: '50-100 words' },
                    { value: 'medium', label: 'Medium', desc: '150-300 words' },
                    { value: 'long', label: 'Long', desc: '400+ words' }
                  ].map((option) => (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() => setLength(option.value as 'short' | 'medium' | 'long')}
                      className={`flex-1 py-3 px-2 rounded-lg font-semibold transition-all ${
                        length === option.value
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-600'
                      }`}
                    >
                      <div className="text-sm">{option.label}</div>
                      <div className="text-xs opacity-75">{option.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  A/B Testing
                  <span className="text-slate-400 ml-1 font-normal">(generate multiple variations)</span>
                </label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setVariations(num)}
                      className={`flex-1 py-2 rounded-lg font-semibold transition-all ${
                        variations === num
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-600'
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Generate multiple variations to compare and choose the best one
                </p>
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="submit"
                  disabled={!topic.trim() && !isTextRewriter}
                  className="flex-1 bg-blue-600 text-white py-4 rounded-lg font-semibold hover:bg-blue-700 transition-all disabled:bg-slate-300 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg hover:shadow-xl"
                >
                  <Icons.Sparkles className="w-5 h-5" />
                  Generate {variations > 1 ? `${variations} Variations` : 'Content'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
