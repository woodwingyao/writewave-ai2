import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import * as Icons from 'lucide-react';
import { templates } from '../lib/templates';

interface AnalyticsPageProps {
  onBack: () => void;
}

interface DailyStats {
  date: string;
  total_generations: number;
  total_words: number;
  total_characters: number;
}

interface TemplateUsage {
  template_id: string;
  count: number;
}

interface ToneUsage {
  tone: string;
  count: number;
}

interface HourlyActivity {
  hour: number;
  count: number;
}

export default function AnalyticsPage({ onBack }: AnalyticsPageProps) {
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | 'all'>('7d');
  const [totalGenerations, setTotalGenerations] = useState(0);
  const [totalWords, setTotalWords] = useState(0);
  const [totalCharacters, setTotalCharacters] = useState(0);
  const [dailyStats, setDailyStats] = useState<DailyStats[]>([]);
  const [templateUsage, setTemplateUsage] = useState<TemplateUsage[]>([]);
  const [toneUsage, setToneUsage] = useState<ToneUsage[]>([]);
  const [hourlyActivity, setHourlyActivity] = useState<HourlyActivity[]>([]);
  const [mostProductiveDay, setMostProductiveDay] = useState<string>('');
  const [avgWordsPerGeneration, setAvgWordsPerGeneration] = useState(0);

  useEffect(() => {
    loadAnalytics();
  }, [timeRange]);

  const loadAnalytics = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setLoading(false);
        setTotalGenerations(0);
        return;
      }

      const daysAgo = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 365;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - daysAgo);

      const { data: generations, error } = await supabase
        .from('content_generations')
        .select('*')
        .gte('created_at', startDate.toISOString())
        .order('created_at', { ascending: false });

      if (error) throw error;

      if (generations && generations.length > 0) {
        setTotalGenerations(generations.length);
        setTotalWords(generations.reduce((sum, g) => sum + (g.word_count || 0), 0));
        setTotalCharacters(generations.reduce((sum, g) => sum + (g.character_count || 0), 0));
        setAvgWordsPerGeneration(Math.round(generations.reduce((sum, g) => sum + (g.word_count || 0), 0) / generations.length));

        const dailyMap = new Map<string, DailyStats>();
        generations.forEach(g => {
          const date = new Date(g.created_at).toISOString().split('T')[0];
          if (!dailyMap.has(date)) {
            dailyMap.set(date, {
              date,
              total_generations: 0,
              total_words: 0,
              total_characters: 0
            });
          }
          const stats = dailyMap.get(date)!;
          stats.total_generations++;
          stats.total_words += g.word_count || 0;
          stats.total_characters += g.character_count || 0;
        });
        const daily = Array.from(dailyMap.values()).sort((a, b) => a.date.localeCompare(b.date));
        setDailyStats(daily);

        const mostProductive = Array.from(dailyMap.values()).sort((a, b) => b.total_generations - a.total_generations)[0];
        if (mostProductive) {
          setMostProductiveDay(new Date(mostProductive.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
        }

        const templateMap = new Map<string, number>();
        generations.forEach(g => {
          templateMap.set(g.template_id, (templateMap.get(g.template_id) || 0) + 1);
        });
        const templateStats = Array.from(templateMap.entries())
          .map(([template_id, count]) => ({ template_id, count }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 5);
        setTemplateUsage(templateStats);

        const toneMap = new Map<string, number>();
        generations.forEach(g => {
          toneMap.set(g.tone, (toneMap.get(g.tone) || 0) + 1);
        });
        const toneStats = Array.from(toneMap.entries())
          .map(([tone, count]) => ({ tone, count }))
          .sort((a, b) => b.count - a.count);
        setToneUsage(toneStats);

        const hourMap = new Map<number, number>();
        generations.forEach(g => {
          const hour = new Date(g.created_at).getHours();
          hourMap.set(hour, (hourMap.get(hour) || 0) + 1);
        });
        const hourStats = Array.from(hourMap.entries())
          .map(([hour, count]) => ({ hour, count }))
          .sort((a, b) => a.hour - b.hour);
        setHourlyActivity(hourStats);
      }
    } catch (err) {
      console.error('Error loading analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  const getTemplateName = (templateId: string) => {
    const template = templates.find(t => t.id === templateId);
    return template ? template.name : templateId;
  };

  const maxDailyGenerations = Math.max(...dailyStats.map(d => d.total_generations), 1);
  const maxTemplateCount = Math.max(...templateUsage.map(t => t.count), 1);
  const maxHourlyCount = Math.max(...hourlyActivity.map(h => h.count), 1);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100 flex items-center justify-center">
        <div className="text-center">
          <Icons.BarChart3 className="w-16 h-16 text-blue-600 mx-auto mb-4 animate-pulse" />
          <p className="text-slate-600 text-lg">Loading analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <button
                onClick={onBack}
                className="p-2 hover:bg-white/50 rounded-lg transition-colors"
              >
                <Icons.ArrowLeft className="w-6 h-6 text-slate-700" />
              </button>
              <div>
                <h1 className="text-3xl font-bold text-slate-900">Content Analytics</h1>
                <p className="text-slate-600">Track your writing productivity and patterns</p>
              </div>
            </div>

            <div className="flex gap-2 bg-white rounded-lg p-1 shadow-sm">
              <button
                onClick={() => setTimeRange('7d')}
                className={`px-4 py-2 rounded-md font-medium transition-all ${
                  timeRange === '7d' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                7 Days
              </button>
              <button
                onClick={() => setTimeRange('30d')}
                className={`px-4 py-2 rounded-md font-medium transition-all ${
                  timeRange === '30d' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                30 Days
              </button>
              <button
                onClick={() => setTimeRange('all')}
                className={`px-4 py-2 rounded-md font-medium transition-all ${
                  timeRange === 'all' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                All Time
              </button>
            </div>
          </div>

          {totalGenerations === 0 ? (
            <div className="bg-white rounded-2xl shadow-sm p-12 text-center">
              <Icons.BarChart3 className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-slate-900 mb-2">No data yet</h2>
              <p className="text-slate-600 mb-6">Start generating content to see your analytics</p>
              <button
                onClick={onBack}
                className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Icons.Sparkles className="w-5 h-5" />
                Start Writing
              </button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <div className="flex items-center justify-between mb-2">
                    <Icons.FileText className="w-8 h-8 text-blue-600" />
                  </div>
                  <div className="text-3xl font-bold text-slate-900 mb-1">{totalGenerations.toLocaleString()}</div>
                  <div className="text-sm text-slate-600">Total Generations</div>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <div className="flex items-center justify-between mb-2">
                    <Icons.Type className="w-8 h-8 text-green-600" />
                  </div>
                  <div className="text-3xl font-bold text-slate-900 mb-1">{totalWords.toLocaleString()}</div>
                  <div className="text-sm text-slate-600">Words Written</div>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <div className="flex items-center justify-between mb-2">
                    <Icons.TrendingUp className="w-8 h-8 text-orange-600" />
                  </div>
                  <div className="text-3xl font-bold text-slate-900 mb-1">{avgWordsPerGeneration}</div>
                  <div className="text-sm text-slate-600">Avg Words/Generation</div>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <div className="flex items-center justify-between mb-2">
                    <Icons.Calendar className="w-8 h-8 text-purple-600" />
                  </div>
                  <div className="text-3xl font-bold text-slate-900 mb-1">{mostProductiveDay || 'N/A'}</div>
                  <div className="text-sm text-slate-600">Most Productive Day</div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
                    <Icons.TrendingUp className="w-5 h-5 text-blue-600" />
                    Daily Activity
                  </h2>
                  <div className="space-y-3">
                    {dailyStats.slice(-14).map(day => (
                      <div key={day.date}>
                        <div className="flex items-center justify-between mb-1 text-sm">
                          <span className="text-slate-700">{new Date(day.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                          <span className="font-semibold text-slate-900">{day.total_generations} generations</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full transition-all"
                            style={{ width: `${(day.total_generations / maxDailyGenerations) * 100}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
                    <Icons.Clock className="w-5 h-5 text-green-600" />
                    Time of Day Activity
                  </h2>
                  <div className="space-y-3">
                    {hourlyActivity.slice(0, 10).map(hour => (
                      <div key={hour.hour}>
                        <div className="flex items-center justify-between mb-1 text-sm">
                          <span className="text-slate-700">{hour.hour}:00 - {hour.hour + 1}:00</span>
                          <span className="font-semibold text-slate-900">{hour.count}</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-2">
                          <div
                            className="bg-green-600 h-2 rounded-full transition-all"
                            style={{ width: `${(hour.count / maxHourlyCount) * 100}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
                    <Icons.FileText className="w-5 h-5 text-orange-600" />
                    Most Used Templates
                  </h2>
                  <div className="space-y-3">
                    {templateUsage.map(template => (
                      <div key={template.template_id}>
                        <div className="flex items-center justify-between mb-1 text-sm">
                          <span className="text-slate-700">{getTemplateName(template.template_id)}</span>
                          <span className="font-semibold text-slate-900">{template.count} uses</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-2">
                          <div
                            className="bg-orange-600 h-2 rounded-full transition-all"
                            style={{ width: `${(template.count / maxTemplateCount) * 100}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-sm">
                  <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
                    <Icons.Palette className="w-5 h-5 text-purple-600" />
                    Tone Distribution
                  </h2>
                  <div className="space-y-3">
                    {toneUsage.map((tone, index) => (
                      <div key={tone.tone} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className={`w-3 h-3 rounded-full ${
                            index === 0 ? 'bg-purple-600' :
                            index === 1 ? 'bg-blue-600' :
                            index === 2 ? 'bg-green-600' :
                            index === 3 ? 'bg-orange-600' : 'bg-slate-400'
                          }`} />
                          <span className="text-slate-700 font-medium">{tone.tone}</span>
                        </div>
                        <span className="text-slate-900 font-semibold">{tone.count}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
