import { useState, useEffect } from 'react';
import * as Icons from 'lucide-react';
import { supabase } from '../lib/supabase';
import { tones, writingStyles } from '../lib/templates';

interface BrandVoicePageProps {
  userEmail: string | null;
  onBack: () => void;
}

interface BrandVoice {
  id: string;
  name: string;
  description: string | null;
  tone: string;
  writing_style: string | null;
  key_phrases: string[] | null;
  avoid_phrases: string[] | null;
  example_text: string | null;
  is_default: boolean;
}

export default function BrandVoicePage({ userEmail, onBack }: BrandVoicePageProps) {
  const [brandVoices, setBrandVoices] = useState<BrandVoice[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editingVoice, setEditingVoice] = useState<BrandVoice | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    tone: tones[0],
    writing_style: writingStyles[0].id,
    key_phrases: '',
    avoid_phrases: '',
    example_text: '',
    is_default: false
  });

  useEffect(() => {
    if (userEmail) {
      loadBrandVoices();
    }
  }, [userEmail]);

  const loadBrandVoices = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const { data, error: fetchError } = await supabase
        .from('brand_voices')
        .select('*')
        .order('is_default', { ascending: false })
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setBrandVoices(data || []);
    } catch (err) {
      console.error('Error loading brand voices:', err);
      setError('Failed to load brand voices');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      const voiceData = {
        name: formData.name,
        description: formData.description || null,
        tone: formData.tone,
        writing_style: formData.writing_style || null,
        key_phrases: formData.key_phrases ? formData.key_phrases.split(',').map(p => p.trim()) : null,
        avoid_phrases: formData.avoid_phrases ? formData.avoid_phrases.split(',').map(p => p.trim()) : null,
        example_text: formData.example_text || null,
        is_default: formData.is_default
      };

      if (editingVoice) {
        const { error: updateError } = await supabase
          .from('brand_voices')
          .update(voiceData)
          .eq('id', editingVoice.id);

        if (updateError) throw updateError;
      } else {
        const { error: insertError } = await supabase
          .from('brand_voices')
          .insert([voiceData]);

        if (insertError) throw insertError;
      }

      setShowForm(false);
      setEditingVoice(null);
      resetForm();
      loadBrandVoices();
    } catch (err) {
      console.error('Error saving brand voice:', err);
      setError('Failed to save brand voice');
    }
  };

  const handleEdit = (voice: BrandVoice) => {
    setEditingVoice(voice);
    setFormData({
      name: voice.name,
      description: voice.description || '',
      tone: voice.tone,
      writing_style: voice.writing_style || writingStyles[0].id,
      key_phrases: voice.key_phrases?.join(', ') || '',
      avoid_phrases: voice.avoid_phrases?.join(', ') || '',
      example_text: voice.example_text || '',
      is_default: voice.is_default
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this brand voice?')) return;

    try {
      const { error: deleteError } = await supabase
        .from('brand_voices')
        .delete()
        .eq('id', id);

      if (deleteError) throw deleteError;
      loadBrandVoices();
    } catch (err) {
      console.error('Error deleting brand voice:', err);
      setError('Failed to delete brand voice');
    }
  };

  const handleSetDefault = async (id: string) => {
    try {
      const { error: updateError } = await supabase
        .from('brand_voices')
        .update({ is_default: true })
        .eq('id', id);

      if (updateError) throw updateError;
      loadBrandVoices();
    } catch (err) {
      console.error('Error setting default:', err);
      setError('Failed to set default brand voice');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      tone: tones[0],
      writing_style: writingStyles[0].id,
      key_phrases: '',
      avoid_phrases: '',
      example_text: '',
      is_default: false
    });
  };

  const cancelForm = () => {
    setShowForm(false);
    setEditingVoice(null);
    resetForm();
  };

  if (!userEmail) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-lg p-8 max-w-md w-full text-center">
          <Icons.AlertCircle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Sign In Required</h2>
          <p className="text-slate-600 mb-6">Please sign in to manage your brand voices.</p>
          <button
            onClick={onBack}
            className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-8 transition-colors group"
          >
            <Icons.ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            Back to Home
          </button>

          <div className="bg-white rounded-2xl shadow-lg p-8 mb-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-blue-50 rounded-xl">
                  <Icons.Mic className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-slate-900">Brand Voices</h1>
                  <p className="text-slate-600">Define your unique tone and style</p>
                </div>
              </div>
              <button
                onClick={() => setShowForm(true)}
                className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <Icons.Plus className="w-5 h-5" />
                New Brand Voice
              </button>
            </div>

            {error && (
              <div className="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded">
                <p className="text-sm text-red-700 flex items-center gap-2">
                  <Icons.AlertCircle className="w-4 h-4" />
                  {error}
                </p>
              </div>
            )}

            {showForm && (
              <form onSubmit={handleSubmit} className="mb-8 p-6 bg-slate-50 rounded-xl">
                <h3 className="text-xl font-bold text-slate-900 mb-4">
                  {editingVoice ? 'Edit Brand Voice' : 'Create New Brand Voice'}
                </h3>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g., My Tech Startup, Personal Blog"
                      className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 focus:border-blue-500 focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      Description
                    </label>
                    <input
                      type="text"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Brief description of this brand voice"
                      className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 focus:border-blue-500 focus:outline-none"
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Tone <span className="text-red-500">*</span>
                      </label>
                      <select
                        value={formData.tone}
                        onChange={(e) => setFormData({ ...formData, tone: e.target.value })}
                        className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 focus:border-blue-500 focus:outline-none bg-white"
                        required
                      >
                        {tones.map((tone) => (
                          <option key={tone} value={tone}>{tone}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Writing Style
                      </label>
                      <select
                        value={formData.writing_style}
                        onChange={(e) => setFormData({ ...formData, writing_style: e.target.value })}
                        className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 focus:border-blue-500 focus:outline-none bg-white"
                      >
                        {writingStyles.map((style) => (
                          <option key={style.id} value={style.id}>{style.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      Key Phrases
                      <span className="text-slate-400 ml-1 font-normal text-xs">(comma-separated)</span>
                    </label>
                    <input
                      type="text"
                      value={formData.key_phrases}
                      onChange={(e) => setFormData({ ...formData, key_phrases: e.target.value })}
                      placeholder="innovative, cutting-edge, user-friendly"
                      className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 focus:border-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      Avoid Phrases
                      <span className="text-slate-400 ml-1 font-normal text-xs">(comma-separated)</span>
                    </label>
                    <input
                      type="text"
                      value={formData.avoid_phrases}
                      onChange={(e) => setFormData({ ...formData, avoid_phrases: e.target.value })}
                      placeholder="game-changer, revolutionary, disruptive"
                      className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 focus:border-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      Example Text
                    </label>
                    <textarea
                      value={formData.example_text}
                      onChange={(e) => setFormData({ ...formData, example_text: e.target.value })}
                      placeholder="Paste an example of content that represents your brand voice..."
                      rows={4}
                      className="w-full px-4 py-3 rounded-lg border-2 border-slate-200 focus:border-blue-500 focus:outline-none resize-none"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="is_default"
                      checked={formData.is_default}
                      onChange={(e) => setFormData({ ...formData, is_default: e.target.checked })}
                      className="w-4 h-4 text-blue-600 rounded"
                    />
                    <label htmlFor="is_default" className="text-sm text-slate-700">
                      Set as default brand voice
                    </label>
                  </div>
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                  >
                    {editingVoice ? 'Update' : 'Create'} Brand Voice
                  </button>
                  <button
                    type="button"
                    onClick={cancelForm}
                    className="px-6 py-3 border-2 border-slate-300 text-slate-700 rounded-lg font-semibold hover:bg-slate-50 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}

            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <Icons.Loader2 className="w-8 h-8 animate-spin text-blue-600" />
              </div>
            ) : brandVoices.length === 0 ? (
              <div className="text-center py-12">
                <Icons.Mic className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-slate-900 mb-2">No Brand Voices Yet</h3>
                <p className="text-slate-600 mb-4">Create your first brand voice to maintain consistency</p>
              </div>
            ) : (
              <div className="space-y-4">
                {brandVoices.map((voice) => (
                  <div
                    key={voice.id}
                    className={`p-6 rounded-xl border-2 transition-all ${
                      voice.is_default
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="text-xl font-bold text-slate-900">{voice.name}</h3>
                          {voice.is_default && (
                            <span className="px-2 py-1 bg-blue-600 text-white text-xs font-semibold rounded">
                              DEFAULT
                            </span>
                          )}
                        </div>
                        {voice.description && (
                          <p className="text-slate-600 mb-3">{voice.description}</p>
                        )}
                        <div className="flex flex-wrap gap-2 text-sm">
                          <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full">
                            {voice.tone}
                          </span>
                          {voice.writing_style && (
                            <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full">
                              {writingStyles.find(s => s.id === voice.writing_style)?.name}
                            </span>
                          )}
                          {voice.key_phrases && voice.key_phrases.length > 0 && (
                            <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full">
                              {voice.key_phrases.length} key phrases
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        {!voice.is_default && (
                          <button
                            onClick={() => handleSetDefault(voice.id)}
                            className="p-2 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Set as default"
                          >
                            <Icons.Star className="w-5 h-5" />
                          </button>
                        )}
                        <button
                          onClick={() => handleEdit(voice)}
                          className="p-2 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Edit"
                        >
                          <Icons.Edit className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() => handleDelete(voice.id)}
                          className="p-2 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete"
                        >
                          <Icons.Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
