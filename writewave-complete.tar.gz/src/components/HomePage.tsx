import { useState, useEffect } from 'react';
import { templates } from '../lib/templates';
import * as Icons from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useTheme } from '../lib/theme';

interface HomePageProps {
  onSelectTemplate: (templateId: string) => void;
  onStartPrompt: () => void;
  onViewHistory: () => void;
  onUpgrade: () => void;
  onManageBrandVoices: () => void;
  onViewAnalytics: () => void;
  onAdvancedFeatures?: () => void;
}

export default function HomePage({ onSelectTemplate, onStartPrompt, onViewHistory, onUpgrade, onManageBrandVoices, onViewAnalytics, onAdvancedFeatures }: HomePageProps) {
  const { theme, toggleTheme } = useTheme();
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [showOnlyFavorites, setShowOnlyFavorites] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);

  useEffect(() => {
    checkAuthAndLoadFavorites();
  }, []);

  const checkAuthAndLoadFavorites = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    setIsLoggedIn(!!user);

    if (user) {
      loadFavorites();
    }
  };

  const loadFavorites = async () => {
    try {
      const { data, error } = await supabase
        .from('template_favorites')
        .select('template_id');

      if (error) throw error;

      if (data) {
        setFavorites(new Set(data.map(f => f.template_id)));
      }
    } catch (err) {
      console.error('Error loading favorites:', err);
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthLoading(true);

    try {
      if (authMode === 'signup') {
        const { error } = await supabase.auth.signUp({
          email,
          password,
        });
        if (error) throw error;
        alert('Account created! Please check your email to verify your account.');
        setShowAuthModal(false);
        setEmail('');
        setPassword('');
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        setShowAuthModal(false);
        setEmail('');
        setPassword('');
        checkAuthAndLoadFavorites();
      }
    } catch (err: any) {
      setAuthError(err.message || 'Authentication failed');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setIsLoggedIn(false);
    setFavorites(new Set());
  };

  const toggleFavorite = async (templateId: string, e: React.MouseEvent) => {
    e.stopPropagation();

    if (!isLoggedIn) {
      setShowAuthModal(true);
      setAuthMode('signup');
      return;
    }

    const isFavorite = favorites.has(templateId);

    try {
      if (isFavorite) {
        const { error } = await supabase
          .from('template_favorites')
          .delete()
          .eq('template_id', templateId);

        if (error) throw error;

        setFavorites(prev => {
          const next = new Set(prev);
          next.delete(templateId);
          return next;
        });
      } else {
        const { error } = await supabase
          .from('template_favorites')
          .insert({ template_id: templateId });

        if (error) throw error;

        setFavorites(prev => new Set(prev).add(templateId));
      }
    } catch (err) {
      console.error('Error toggling favorite:', err);
      alert('Failed to update favorite');
    }
  };

  const displayedTemplates = showOnlyFavorites
    ? templates.filter(t => favorites.has(t.id))
    : templates;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100 dark:from-slate-900 dark:to-slate-800 transition-colors">
      <div className="container mx-auto px-4 py-12">
        <div className="flex justify-end items-center gap-3 mb-4">
          <button
            onClick={toggleTheme}
            className="inline-flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition-all shadow-sm hover:shadow-md font-medium"
            title={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
          >
            {theme === 'light' ? (
              <Icons.Moon className="w-4 h-4" />
            ) : (
              <Icons.Sun className="w-4 h-4" />
            )}
          </button>
          {isLoggedIn ? (
            <button
              onClick={handleSignOut}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition-all shadow-sm hover:shadow-md font-medium"
            >
              <Icons.LogOut className="w-4 h-4" />
              Sign Out
            </button>
          ) : (
            <button
              onClick={() => {
                setShowAuthModal(true);
                setAuthMode('signin');
              }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition-all shadow-sm hover:shadow-md font-medium"
            >
              <Icons.User className="w-4 h-4" />
              Sign In
            </button>
          )}
        </div>

        <header className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Icons.Sparkles className="w-10 h-10 text-blue-600" />
            <h1 className="text-5xl font-bold text-slate-900 dark:text-white">WriteWave AI</h1>
          </div>
          <p className="text-xl text-slate-600 dark:text-slate-300 max-w-2xl mx-auto mb-8">
            Generate high-quality copy in seconds. {isLoggedIn ? 'Welcome back!' : 'Try it free - no account required.'}
          </p>

          {!isLoggedIn && (
            <div className="max-w-4xl mx-auto mb-8">
              <div className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl shadow-lg p-6 text-white">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-3">
                    <Icons.Gift className="w-8 h-8" />
                    <div className="text-left">
                      <h3 className="text-lg font-bold">Create a Free Account</h3>
                      <p className="text-green-100 text-sm">Save your history, create brand voices, and track analytics</p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setShowAuthModal(true);
                      setAuthMode('signup');
                    }}
                    className="px-6 py-3 bg-white text-green-600 rounded-lg hover:bg-green-50 transition-all shadow-md hover:shadow-lg font-bold"
                  >
                    Sign Up Free
                  </button>
                </div>
              </div>
            </div>
          )}
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <button
              onClick={onStartPrompt}
              className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all shadow-lg hover:shadow-xl font-semibold"
            >
              <Icons.Zap className="w-5 h-5" />
              Write Anything
            </button>
            <button
              onClick={() => {
                if (!isLoggedIn) {
                  setShowAuthModal(true);
                  setAuthMode('signup');
                } else {
                  onViewAnalytics();
                }
              }}
              className="inline-flex items-center gap-2 px-6 py-3 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition-all shadow-sm hover:shadow-md"
            >
              <Icons.BarChart3 className="w-5 h-5" />
              Analytics
              {!isLoggedIn && <Icons.Lock className="w-4 h-4 text-slate-400" />}
            </button>
            <button
              onClick={() => {
                if (!isLoggedIn) {
                  setShowAuthModal(true);
                  setAuthMode('signup');
                } else {
                  onManageBrandVoices();
                }
              }}
              className="inline-flex items-center gap-2 px-6 py-3 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition-all shadow-sm hover:shadow-md"
            >
              <Icons.Mic className="w-5 h-5" />
              Brand Voices
              {!isLoggedIn && <Icons.Lock className="w-4 h-4 text-slate-400" />}
            </button>
            <button
              onClick={() => {
                if (!isLoggedIn) {
                  setShowAuthModal(true);
                  setAuthMode('signup');
                } else {
                  onViewHistory();
                }
              }}
              className="inline-flex items-center gap-2 px-6 py-3 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition-all shadow-sm hover:shadow-md"
            >
              <Icons.History className="w-5 h-5" />
              View History
              {!isLoggedIn && <Icons.Lock className="w-4 h-4 text-slate-400" />}
            </button>
            {onAdvancedFeatures && (
              <button
                onClick={onAdvancedFeatures}
                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all shadow-md hover:shadow-lg"
              >
                <Icons.Sparkles className="w-5 h-5" />
                Advanced Features
              </button>
            )}
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl shadow-2xl p-8 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-10 rounded-full -mr-32 -mt-32"></div>
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-white opacity-10 rounded-full -ml-24 -mb-24"></div>
              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-4">
                  <Icons.Crown className="w-8 h-8 text-yellow-300" />
                  <h2 className="text-2xl font-bold">Upgrade to Pro</h2>
                </div>
                <p className="text-blue-100 mb-6 text-lg">
                  Get unlimited generations, long-form content, all writing styles, and priority support starting at just $9.99/month
                </p>
                <button
                  onClick={onUpgrade}
                  className="inline-flex items-center gap-2 px-8 py-4 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-all shadow-lg hover:shadow-xl font-bold text-lg"
                >
                  <Icons.Sparkles className="w-5 h-5" />
                  See Pro Plans
                </button>
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto mb-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-slate-900">Or choose a template</h2>
            {isLoggedIn && favorites.size > 0 && (
              <button
                onClick={() => setShowOnlyFavorites(!showOnlyFavorites)}
                className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                  showOnlyFavorites
                    ? 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <Icons.Star className={`w-4 h-4 ${showOnlyFavorites ? 'fill-yellow-600' : ''}`} />
                {showOnlyFavorites ? 'Show All' : `Favorites (${favorites.size})`}
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
          {displayedTemplates.map((template) => {
            const IconComponent = (Icons as Record<string, React.ComponentType<{ className?: string }>>)[template.icon];

            return (
              <div
                key={template.id}
                className="relative group bg-white rounded-xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 border-2 border-transparent hover:border-blue-500 hover:-translate-y-1"
              >
                {isLoggedIn && (
                  <button
                    onClick={(e) => toggleFavorite(template.id, e)}
                    className="absolute top-4 right-4 z-10 p-2 rounded-lg hover:bg-slate-100 transition-colors"
                    title={favorites.has(template.id) ? 'Remove from favorites' : 'Add to favorites'}
                  >
                    <Icons.Star
                      className={`w-5 h-5 transition-colors ${
                        favorites.has(template.id)
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-slate-300 hover:text-yellow-400'
                      }`}
                    />
                  </button>
                )}
                <button
                  onClick={() => onSelectTemplate(template.id)}
                  className="w-full text-left"
                >
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-blue-50 rounded-lg group-hover:bg-blue-100 transition-colors">
                      {IconComponent && <IconComponent className="w-6 h-6 text-blue-600" />}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
                        {template.name}
                      </h3>
                      <p className="text-sm text-slate-600 leading-relaxed">
                        {template.description}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 flex items-center text-blue-600 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                    <span>Get started</span>
                    <Icons.ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </div>
                </button>
              </div>
            );
          })}
        </div>

        <footer className="text-center mt-16 text-slate-500 text-sm">
          <p>Powered by AI • {isLoggedIn ? 'Signed in' : 'No account required'} • Instant results</p>
        </footer>
      </div>

      {showAuthModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 relative">
            <button
              onClick={() => {
                setShowAuthModal(false);
                setAuthError('');
                setEmail('');
                setPassword('');
              }}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors"
            >
              <Icons.X className="w-6 h-6" />
            </button>

            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                <Icons.User className="w-8 h-8 text-blue-600" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-2">
                {authMode === 'signup' ? 'Create Your Free Account' : 'Welcome Back'}
              </h2>
              <p className="text-slate-600">
                {authMode === 'signup'
                  ? 'Get access to history, brand voices, and analytics'
                  : 'Sign in to access your saved content'}
              </p>
            </div>

            <form onSubmit={handleAuth} className="space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-2">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="you@example.com"
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-slate-700 mb-2">
                  Password
                </label>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="••••••••"
                />
              </div>

              {authError && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                  {authError}
                </div>
              )}

              <button
                type="submit"
                disabled={authLoading}
                className="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all shadow-md hover:shadow-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {authLoading ? 'Loading...' : authMode === 'signup' ? 'Create Account' : 'Sign In'}
              </button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => {
                  setAuthMode(authMode === 'signup' ? 'signin' : 'signup');
                  setAuthError('');
                }}
                className="text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                {authMode === 'signup'
                  ? 'Already have an account? Sign in'
                  : "Don't have an account? Sign up"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
