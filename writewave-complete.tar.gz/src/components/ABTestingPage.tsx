import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { ArrowLeft, FlaskConical, Plus, TrendingUp, Users, Eye } from 'lucide-react';

interface ABTestingPageProps {
  onBack: () => void;
}

interface Test {
  id: string;
  name: string;
  variant_a: string;
  variant_b: string;
  views_a: number;
  views_b: number;
  clicks_a: number;
  clicks_b: number;
  status: 'active' | 'completed';
  created_at: string;
}

export default function ABTestingPage({ onBack }: ABTestingPageProps) {
  const [tests, setTests] = useState<Test[]>([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    variant_a: '',
    variant_b: ''
  });

  useEffect(() => {
    loadTests();
  }, []);

  const loadTests = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const mockTests: Test[] = [
        {
          id: '1',
          name: 'Email Subject Line Test',
          variant_a: 'Boost Your Productivity by 40%',
          variant_b: 'Transform Your Workday Today',
          views_a: 1245,
          views_b: 1198,
          clicks_a: 187,
          clicks_b: 203,
          status: 'active',
          created_at: new Date().toISOString()
        }
      ];

      setTests(mockTests);
    } catch (err) {
      console.error('Error loading tests:', err);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    alert('A/B testing creation will be available soon!');
    setShowCreateForm(false);
    setFormData({ name: '', variant_a: '', variant_b: '' });
  };

  const calculateConversion = (clicks: number, views: number) => {
    return views > 0 ? ((clicks / views) * 100).toFixed(2) : '0.00';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="mb-8 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <FlaskConical className="w-10 h-10 text-orange-600" />
              <h1 className="text-4xl font-bold text-gray-900 dark:text-white">A/B Testing</h1>
            </div>
            <p className="text-gray-600 dark:text-gray-300">
              Test content variations and track performance
            </p>
          </div>

          <button
            onClick={() => setShowCreateForm(true)}
            className="bg-orange-600 text-white px-6 py-3 rounded-lg hover:bg-orange-700 transition-all flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            New Test
          </button>
        </div>

        {showCreateForm && (
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg mb-8">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Create A/B Test</h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Test Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                  placeholder="Email Subject Line Test"
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Variant A
                  </label>
                  <textarea
                    value={formData.variant_a}
                    onChange={e => setFormData({ ...formData, variant_a: e.target.value })}
                    className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white h-24"
                    placeholder="First version of your content"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Variant B
                  </label>
                  <textarea
                    value={formData.variant_b}
                    onChange={e => setFormData({ ...formData, variant_b: e.target.value })}
                    className="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white h-24"
                    placeholder="Alternative version of your content"
                    required
                  />
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  type="submit"
                  className="bg-orange-600 text-white px-6 py-2 rounded-lg hover:bg-orange-700 transition-all"
                >
                  Create Test
                </button>
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-6 py-2 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-all"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        <div className="space-y-6">
          {tests.map(test => (
            <div key={test.id} className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                    {test.name}
                  </h3>
                  <span className={`inline-block text-sm px-3 py-1 rounded-full ${
                    test.status === 'active'
                      ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300'
                      : 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
                  }`}>
                    {test.status === 'active' ? 'Active' : 'Completed'}
                  </span>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="border-2 border-blue-200 dark:border-blue-800 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-lg font-bold text-gray-900 dark:text-white">Variant A</h4>
                    <span className="text-sm bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 px-3 py-1 rounded-full">
                      Control
                    </span>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 mb-4">{test.variant_a}</p>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400 mb-1">
                        <Eye className="w-4 h-4" />
                        <span className="text-sm">Views</span>
                      </div>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">{test.views_a}</p>
                    </div>
                    <div>
                      <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400 mb-1">
                        <TrendingUp className="w-4 h-4" />
                        <span className="text-sm">Clicks</span>
                      </div>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">{test.clicks_a}</p>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t dark:border-gray-700">
                    <p className="text-sm text-gray-600 dark:text-gray-400">Conversion Rate</p>
                    <p className="text-3xl font-bold text-blue-600">{calculateConversion(test.clicks_a, test.views_a)}%</p>
                  </div>
                </div>

                <div className="border-2 border-green-200 dark:border-green-800 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-lg font-bold text-gray-900 dark:text-white">Variant B</h4>
                    <span className="text-sm bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 px-3 py-1 rounded-full">
                      Variant
                    </span>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 mb-4">{test.variant_b}</p>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400 mb-1">
                        <Eye className="w-4 h-4" />
                        <span className="text-sm">Views</span>
                      </div>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">{test.views_b}</p>
                    </div>
                    <div>
                      <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400 mb-1">
                        <TrendingUp className="w-4 h-4" />
                        <span className="text-sm">Clicks</span>
                      </div>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">{test.clicks_b}</p>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t dark:border-gray-700">
                    <p className="text-sm text-gray-600 dark:text-gray-400">Conversion Rate</p>
                    <p className="text-3xl font-bold text-green-600">{calculateConversion(test.clicks_b, test.views_b)}%</p>
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  <span className="font-bold text-gray-900 dark:text-white">Winner: Variant B</span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  Variant B is performing {((parseFloat(calculateConversion(test.clicks_b, test.views_b)) / parseFloat(calculateConversion(test.clicks_a, test.views_a)) - 1) * 100).toFixed(1)}% better than Variant A
                </p>
              </div>
            </div>
          ))}
        </div>

        {tests.length === 0 && !showCreateForm && (
          <div className="text-center py-12">
            <FlaskConical className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-300 mb-4">No A/B tests yet</p>
            <button
              onClick={() => setShowCreateForm(true)}
              className="bg-orange-600 text-white px-6 py-3 rounded-lg hover:bg-orange-700 transition-all inline-flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Create Your First Test
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
