import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { ArrowLeft, Globe, Copy, Download, Languages } from 'lucide-react';

interface TranslationPageProps {
  onBack: () => void;
}

interface Translation {
  id: string;
  language: string;
  translated_text: string;
  created_at: string;
}

interface SavedContent {
  id: string;
  content: string;
  topic: string;
}

const SUPPORTED_LANGUAGES = [
  { code: 'zh', name: 'Chinese (Simplified)', native: '简体中文' },
  { code: 'zh-TW', name: 'Chinese (Traditional)', native: '繁體中文' },
  { code: 'ja', name: 'Japanese', native: '日本語' },
  { code: 'ko', name: 'Korean', native: '한국어' },
  { code: 'es', name: 'Spanish', native: 'Español' },
  { code: 'fr', name: 'French', native: 'Français' },
  { code: 'de', name: 'German', native: 'Deutsch' },
  { code: 'it', name: 'Italian', native: 'Italiano' },
  { code: 'pt', name: 'Portuguese', native: 'Português' },
  { code: 'ru', name: 'Russian', native: 'Русский' },
  { code: 'ar', name: 'Arabic', native: 'العربية' },
  { code: 'hi', name: 'Hindi', native: 'हिन्दी' },
  { code: 'bn', name: 'Bengali', native: 'বাংলা' },
  { code: 'vi', name: 'Vietnamese', native: 'Tiếng Việt' },
  { code: 'th', name: 'Thai', native: 'ไทย' },
  { code: 'tr', name: 'Turkish', native: 'Türkçe' },
  { code: 'pl', name: 'Polish', native: 'Polski' },
  { code: 'nl', name: 'Dutch', native: 'Nederlands' },
  { code: 'sv', name: 'Swedish', native: 'Svenska' },
  { code: 'da', name: 'Danish', native: 'Dansk' },
  { code: 'fi', name: 'Finnish', native: 'Suomi' },
  { code: 'no', name: 'Norwegian', native: 'Norsk' },
  { code: 'el', name: 'Greek', native: 'Ελληνικά' },
  { code: 'he', name: 'Hebrew', native: 'עברית' },
  { code: 'id', name: 'Indonesian', native: 'Bahasa Indonesia' },
  { code: 'ms', name: 'Malay', native: 'Bahasa Melayu' },
  { code: 'tl', name: 'Filipino', native: 'Filipino' },
  { code: 'uk', name: 'Ukrainian', native: 'Українська' },
  { code: 'cs', name: 'Czech', native: 'Čeština' },
  { code: 'ro', name: 'Romanian', native: 'Română' },
  { code: 'hu', name: 'Hungarian', native: 'Magyar' },
];

export default function TranslationPage({ onBack }: TranslationPageProps) {
  const [savedContent, setSavedContent] = useState<SavedContent[]>([]);
  const [selectedContent, setSelectedContent] = useState<string | null>(null);
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>(['zh', 'ja', 'ko']);
  const [translations, setTranslations] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [translating, setTranslating] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadSavedContent();
  }, []);

  useEffect(() => {
    if (selectedContent) {
      loadExistingTranslations();
    }
  }, [selectedContent]);

  const loadSavedContent = async () => {
    try {
      const { data, error } = await supabase
        .from('saved_copies')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setSavedContent(data || []);
    } catch (err) {
      console.error('Error loading content:', err);
    }
  };

  const loadExistingTranslations = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('translations')
        .select('*')
        .eq('original_content_id', selectedContent);

      if (error) throw error;

      const translationMap: Record<string, string> = {};
      data?.forEach(t => {
        translationMap[t.language] = t.translated_text;
      });
      setTranslations(translationMap);
    } catch (err) {
      console.error('Error loading translations:', err);
    }
  };

  const handleTranslate = async () => {
    if (!selectedContent) return;

    setTranslating(true);
    const content = savedContent.find(c => c.id === selectedContent);
    if (!content) {
      setTranslating(false);
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        alert('Please sign in to use translation');
        setTranslating(false);
        return;
      }

      const newTranslations: Record<string, string> = { ...translations };
      let successCount = 0;
      let failCount = 0;

      for (const langCode of selectedLanguages) {
        if (translations[langCode]) {
          successCount++;
          continue;
        }

        try {
          const lang = SUPPORTED_LANGUAGES.find(l => l.code === langCode);

          const response = await fetch(
            `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/translate-content`,
            {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
              },
              body: JSON.stringify({
                text: content.content,
                targetLanguage: langCode,
                languageName: lang?.name || langCode
              }),
            }
          );

          if (!response.ok) {
            throw new Error(`Translation failed for ${lang?.name}`);
          }

          const data = await response.json();

          if (!data.success) {
            throw new Error(data.error || 'Translation failed');
          }

          const translatedText = data.translation;

          const { error } = await supabase
            .from('translations')
            .insert({
              user_id: user.id,
              original_content_id: selectedContent,
              language: langCode,
              translated_text: translatedText
            });

          if (error) throw error;

          newTranslations[langCode] = translatedText;
          successCount++;
        } catch (err: any) {
          console.error(`Failed to translate to ${langCode}:`, err);
          failCount++;
        }
      }

      setTranslations(newTranslations);

      if (successCount > 0 && failCount === 0) {
        alert(`Successfully translated to ${successCount} language${successCount > 1 ? 's' : ''}!`);
      } else if (successCount > 0 && failCount > 0) {
        alert(`Translated to ${successCount} language${successCount > 1 ? 's' : ''}, but ${failCount} failed. Please try again.`);
      } else if (failCount > 0) {
        alert('Translation failed. Please try again.');
      }
    } catch (err: any) {
      console.error('Translation error:', err);
      alert('Translation failed: ' + err.message);
    } finally {
      setTranslating(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copied to clipboard!');
  };

  const handleDownload = () => {
    const content = savedContent.find(c => c.id === selectedContent);
    if (!content) return;

    let downloadText = `Original (English):\n${content.content}\n\n`;

    selectedLanguages.forEach(langCode => {
      const lang = SUPPORTED_LANGUAGES.find(l => l.code === langCode);
      const translation = translations[langCode];
      if (translation) {
        downloadText += `${lang?.name} (${lang?.native}):\n${translation}\n\n`;
      }
    });

    const blob = new Blob([downloadText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `translations-${content.topic || 'content'}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const toggleLanguage = (langCode: string) => {
    if (selectedLanguages.includes(langCode)) {
      setSelectedLanguages(selectedLanguages.filter(l => l !== langCode));
    } else {
      setSelectedLanguages([...selectedLanguages, langCode]);
    }
  };

  const filteredLanguages = SUPPORTED_LANGUAGES.filter(lang =>
    lang.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    lang.native.toLowerCase().includes(searchQuery.toLowerCase()) ||
    lang.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const content = savedContent.find(c => c.id === selectedContent);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Globe className="w-10 h-10 text-blue-600" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">Multi-language Translation</h1>
          </div>
          <p className="text-gray-600 dark:text-gray-300">
            Translate your content into Chinese, Japanese, Korean, and 27+ other languages
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Select Content</h2>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {savedContent.map(item => (
                  <button
                    key={item.id}
                    onClick={() => setSelectedContent(item.id)}
                    className={`w-full text-left p-3 rounded-lg transition-all ${
                      selectedContent === item.id
                        ? 'bg-blue-100 dark:bg-blue-900 ring-2 ring-blue-600'
                        : 'bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600'
                    }`}
                  >
                    <p className="font-medium text-gray-900 dark:text-white text-sm">
                      {item.topic || 'Untitled'}
                    </p>
                    <p className="text-xs text-gray-600 dark:text-gray-300 mt-1 line-clamp-2">
                      {item.content}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
                Target Languages ({selectedLanguages.length})
              </h2>

              <input
                type="text"
                placeholder="Search languages..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg mb-4 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              />

              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredLanguages.map(lang => (
                  <button
                    key={lang.code}
                    onClick={() => toggleLanguage(lang.code)}
                    className={`w-full text-left p-3 rounded-lg transition-all ${
                      selectedLanguages.includes(lang.code)
                        ? 'bg-blue-100 dark:bg-blue-900 ring-2 ring-blue-600'
                        : 'bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white text-sm">
                          {lang.name}
                        </p>
                        <p className="text-xs text-gray-600 dark:text-gray-300">
                          {lang.native}
                        </p>
                      </div>
                      {selectedLanguages.includes(lang.code) && (
                        <div className="w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center">
                          <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        </div>
                      )}
                    </div>
                  </button>
                ))}
              </div>

              <button
                onClick={handleTranslate}
                disabled={!selectedContent || selectedLanguages.length === 0 || translating}
                className="w-full mt-4 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
              >
                <Languages className="w-5 h-5" />
                {translating ? 'Translating...' : 'Translate'}
              </button>
            </div>
          </div>

          <div className="lg:col-span-2">
            {selectedContent && content ? (
              <div className="space-y-6">
                <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white">Original Content</h2>
                    <button
                      onClick={() => handleCopy(content.content)}
                      className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
                    >
                      <Copy className="w-4 h-4" />
                      Copy
                    </button>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{content.content}</p>
                </div>

                {selectedLanguages.map(langCode => {
                  const lang = SUPPORTED_LANGUAGES.find(l => l.code === langCode);
                  const translation = translations[langCode];

                  return (
                    <div key={langCode} className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                            {lang?.name}
                          </h3>
                          <p className="text-sm text-gray-600 dark:text-gray-300">{lang?.native}</p>
                        </div>
                        {translation && (
                          <button
                            onClick={() => handleCopy(translation)}
                            className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
                          >
                            <Copy className="w-4 h-4" />
                            Copy
                          </button>
                        )}
                      </div>
                      {translation ? (
                        <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{translation}</p>
                      ) : (
                        <p className="text-gray-400 dark:text-gray-500 italic">
                          Click "Translate" to generate translation
                        </p>
                      )}
                    </div>
                  );
                })}

                {Object.keys(translations).length > 0 && (
                  <button
                    onClick={handleDownload}
                    className="w-full bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-all flex items-center justify-center gap-2"
                  >
                    <Download className="w-5 h-5" />
                    Download All Translations
                  </button>
                )}
              </div>
            ) : (
              <div className="bg-white dark:bg-gray-800 rounded-xl p-12 text-center">
                <Globe className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-300">Select content to start translating</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
