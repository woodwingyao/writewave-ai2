import { useState } from 'react';
import { ArrowLeft, Users, Calendar, Brain, Globe, FlaskConical, Share2, Folder, TrendingUp, FileText, GraduationCap } from 'lucide-react';
import WorkspacesPage from './WorkspacesPage';
import ContentCalendarPage from './ContentCalendarPage';
import TranslationPage from './TranslationPage';
import ContentAnalyzerPage from './ContentAnalyzerPage';
import IntegrationsPage from './IntegrationsPage';
import CustomTemplatesPage from './CustomTemplatesPage';
import ABTestingPage from './ABTestingPage';
import ContentLibraryPage from './ContentLibraryPage';
import UsageDashboardPage from './UsageDashboardPage';
import AITrainingPage from './AITrainingPage';

interface AdvancedFeaturesPageProps {
  onBack: () => void;
  userEmail: string | null;
}

type FeatureView = 'menu' | 'workspaces' | 'calendar' | 'analyzer' | 'translation' | 'ab-test' | 'integrations' | 'library' | 'usage' | 'templates' | 'training';

export default function AdvancedFeaturesPage({ onBack, userEmail }: AdvancedFeaturesPageProps) {
  const [currentView, setCurrentView] = useState<FeatureView>('menu');

  const features = [
    {
      id: 'workspaces' as const,
      name: 'Team Collaboration',
      description: 'Create workspaces and collaborate with team members',
      icon: Users,
      color: 'bg-blue-500',
      available: true
    },
    {
      id: 'calendar' as const,
      name: 'Content Calendar',
      description: 'Schedule content for future publication',
      icon: Calendar,
      color: 'bg-green-500',
      available: true
    },
    {
      id: 'analyzer' as const,
      name: 'Content Analyzer',
      description: 'Analyze tone, readability, SEO, and grammar',
      icon: Brain,
      color: 'bg-purple-500',
      available: true
    },
    {
      id: 'translation' as const,
      name: 'Multi-language',
      description: 'Chinese, Japanese, Korean & 27+ languages',
      icon: Globe,
      color: 'bg-cyan-500',
      available: true
    },
    {
      id: 'ab-test' as const,
      name: 'A/B Testing',
      description: 'Test content variations and track performance',
      icon: FlaskConical,
      color: 'bg-orange-500',
      available: true
    },
    {
      id: 'integrations' as const,
      name: 'Integrations',
      description: 'Connect to social media, WordPress, and more',
      icon: Share2,
      color: 'bg-pink-500',
      available: true
    },
    {
      id: 'library' as const,
      name: 'Content Library',
      description: 'Organize content with folders and tags',
      icon: Folder,
      color: 'bg-yellow-500',
      available: true
    },
    {
      id: 'usage' as const,
      name: 'Usage Dashboard',
      description: 'Track your usage and limits',
      icon: TrendingUp,
      color: 'bg-red-500',
      available: true
    },
    {
      id: 'templates' as const,
      name: 'Custom Templates',
      description: 'Create and share your own templates',
      icon: FileText,
      color: 'bg-indigo-500',
      available: true
    },
    {
      id: 'training' as const,
      name: 'AI Training',
      description: 'Train AI on your writing style',
      icon: GraduationCap,
      color: 'bg-emerald-500',
      available: true
    }
  ];

  if (currentView === 'workspaces') {
    return <WorkspacesPage onBack={() => setCurrentView('menu')} userEmail={userEmail} />;
  }

  if (currentView === 'calendar') {
    return <ContentCalendarPage onBack={() => setCurrentView('menu')} />;
  }

  if (currentView === 'translation') {
    return <TranslationPage onBack={() => setCurrentView('menu')} />;
  }

  if (currentView === 'analyzer') {
    return <ContentAnalyzerPage onBack={() => setCurrentView('menu')} />;
  }

  if (currentView === 'integrations') {
    return <IntegrationsPage onBack={() => setCurrentView('menu')} />;
  }

  if (currentView === 'templates') {
    return <CustomTemplatesPage onBack={() => setCurrentView('menu')} />;
  }

  if (currentView === 'ab-test') {
    return <ABTestingPage onBack={() => setCurrentView('menu')} />;
  }

  if (currentView === 'library') {
    return <ContentLibraryPage onBack={() => setCurrentView('menu')} />;
  }

  if (currentView === 'usage') {
    return <UsageDashboardPage onBack={() => setCurrentView('menu')} />;
  }

  if (currentView === 'training') {
    return <AITrainingPage onBack={() => setCurrentView('menu')} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        <div className="mb-12 text-center">
          <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-4">Advanced Features</h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Unlock the full power of AI copywriting
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map(feature => {
            const Icon = feature.icon;
            return (
              <button
                key={feature.id}
                onClick={() => setCurrentView(feature.id)}
                className={`bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all transform hover:scale-105 text-left ${
                  !feature.available && 'opacity-60 cursor-not-allowed'
                }`}
                disabled={!feature.available}
              >
                <div className={`${feature.color} w-14 h-14 rounded-xl flex items-center justify-center mb-4`}>
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                  {feature.name}
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  {feature.description}
                </p>
                {!feature.available && (
                  <span className="inline-block mt-3 text-xs bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-3 py-1 rounded-full">
                    Coming Soon
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <div className="mt-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white text-center">
          <h2 className="text-3xl font-bold mb-3">Ready to Supercharge Your Content?</h2>
          <p className="text-lg mb-6 opacity-90">
            Explore these powerful features to streamline your workflow
          </p>
        </div>
      </div>
    </div>
  );
}
