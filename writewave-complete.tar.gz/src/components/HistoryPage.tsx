import { useState, useEffect } from 'react';
import { supabase, type SavedCopy } from '../lib/supabase';
import { templates } from '../lib/templates';
import * as Icons from 'lucide-react';

interface HistoryPageProps {
  onBack: () => void;
}

export default function HistoryPage({ onBack }: HistoryPageProps) {
  const [savedCopies, setSavedCopies] = useState<SavedCopy[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      const { data, error } = await supabase
        .from('saved_copies')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSavedCopies(data || []);
    } catch (error) {
      console.error('Failed to load history:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this saved copy?')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('saved_copies')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setSavedCopies((prev) => prev.filter((copy) => copy.id !== id));
    } catch (error) {
      console.error('Failed to delete:', error);
      alert('Failed to delete. Please try again.');
    }
  };

  const getTemplateName = (templateType: string) => {
    const template = templates.find((t) => t.id === templateType);
    return template?.name || templateType;
  };

  const getTemplateIcon = (templateType: string) => {
    const template = templates.find((t) => t.id === templateType);
    return template?.icon || 'FileText';
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-8 transition-colors group"
          >
            <Icons.ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            Back to Home
          </button>

          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <div className="flex items-center gap-4 mb-8">
              <div className="p-4 bg-blue-50 rounded-xl">
                <Icons.History className="w-8 h-8 text-blue-600" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-slate-900">Saved History</h1>
                <p className="text-slate-600">
                  {savedCopies.length} saved {savedCopies.length === 1 ? 'copy' : 'copies'}
                </p>
              </div>
            </div>

            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-16">
                <div className="relative">
                  <div className="w-12 h-12 border-4 border-blue-200 rounded-full"></div>
                  <div className="w-12 h-12 border-4 border-blue-600 rounded-full border-t-transparent animate-spin absolute top-0 left-0"></div>
                </div>
                <p className="mt-4 text-slate-600">Loading history...</p>
              </div>
            ) : savedCopies.length === 0 ? (
              <div className="text-center py-16">
                <div className="inline-flex p-6 bg-slate-100 rounded-full mb-4">
                  <Icons.Inbox className="w-12 h-12 text-slate-400" />
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No saved copies yet</h3>
                <p className="text-slate-600 mb-6">
                  Generate some content and save it to see it here.
                </p>
                <button
                  onClick={onBack}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-all"
                >
                  <Icons.Sparkles className="w-5 h-5" />
                  Create Your First Copy
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {savedCopies.map((copy) => {
                  const IconComponent = (Icons as Record<string, React.ComponentType<{ className?: string }>>)[
                    getTemplateIcon(copy.template_type)
                  ];

                  return (
                    <div
                      key={copy.id}
                      className="bg-slate-50 rounded-xl p-6 border-2 border-slate-200 hover:border-blue-300 transition-all"
                    >
                      <div className="flex items-start gap-4">
                        <div className="p-3 bg-white rounded-lg flex-shrink-0">
                          {IconComponent && <IconComponent className="w-6 h-6 text-blue-600" />}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-4 mb-3">
                            <div>
                              <h3 className="text-lg font-semibold text-slate-900 mb-1">
                                {getTemplateName(copy.template_type)}
                              </h3>
                              <div className="flex flex-wrap gap-2 text-sm">
                                {copy.topic && (
                                  <span className="text-slate-600">
                                    {copy.topic}
                                  </span>
                                )}
                                <span className="text-slate-400">•</span>
                                <span className="text-blue-600">{copy.tone}</span>
                              </div>
                            </div>
                            <div className="flex gap-2 flex-shrink-0">
                              <button
                                onClick={() => handleCopy(copy.content, copy.id)}
                                className="p-2 bg-white text-slate-700 rounded-lg hover:bg-slate-100 transition-all shadow-sm hover:shadow"
                                title="Copy to clipboard"
                              >
                                {copiedId === copy.id ? (
                                  <Icons.Check className="w-5 h-5 text-green-600" />
                                ) : (
                                  <Icons.Copy className="w-5 h-5" />
                                )}
                              </button>
                              <button
                                onClick={() => handleDelete(copy.id)}
                                className="p-2 bg-white text-red-600 rounded-lg hover:bg-red-50 transition-all shadow-sm hover:shadow"
                                title="Delete"
                              >
                                <Icons.Trash2 className="w-5 h-5" />
                              </button>
                            </div>
                          </div>

                          <div className="bg-white rounded-lg p-4 mb-3">
                            <p className="text-slate-800 whitespace-pre-wrap leading-relaxed line-clamp-4">
                              {copy.content}
                            </p>
                          </div>

                          <div className="flex items-center gap-2 text-xs text-slate-500">
                            <Icons.Clock className="w-4 h-4" />
                            {formatDate(copy.created_at)}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
