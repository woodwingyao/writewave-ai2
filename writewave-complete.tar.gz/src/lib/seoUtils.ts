export interface SEOMetrics {
  wordCount: number;
  characterCount: number;
  characterCountNoSpaces: number;
  sentenceCount: number;
  paragraphCount: number;
  readingTime: number;
  readabilityScore: number;
  readabilityLevel: string;
  keywordDensity: { word: string; count: number; percentage: number }[];
}

export function analyzeSEO(content: string): SEOMetrics {
  const words = content.trim().split(/\s+/).filter(w => w.length > 0);
  const wordCount = words.length;
  const characterCount = content.length;
  const characterCountNoSpaces = content.replace(/\s/g, '').length;

  const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const sentenceCount = sentences.length;

  const paragraphs = content.split(/\n\n+/).filter(p => p.trim().length > 0);
  const paragraphCount = paragraphs.length;

  const readingTime = Math.ceil(wordCount / 200);

  const avgSentenceLength = wordCount / Math.max(sentenceCount, 1);
  const avgSyllablesPerWord = estimateAverageSyllables(words);

  const fleschScore = calculateFleschScore(avgSentenceLength, avgSyllablesPerWord);
  const readabilityLevel = getReadabilityLevel(fleschScore);

  const keywordDensity = calculateKeywordDensity(words, wordCount);

  return {
    wordCount,
    characterCount,
    characterCountNoSpaces,
    sentenceCount,
    paragraphCount,
    readingTime,
    readabilityScore: Math.round(fleschScore),
    readabilityLevel,
    keywordDensity
  };
}

function estimateAverageSyllables(words: string[]): number {
  if (words.length === 0) return 0;

  const syllableCounts = words.map(word => {
    word = word.toLowerCase().replace(/[^a-z]/g, '');
    if (word.length <= 3) return 1;

    const vowels = word.match(/[aeiouy]+/g);
    let count = vowels ? vowels.length : 1;

    if (word.endsWith('e')) count--;
    if (word.endsWith('le') && word.length > 2) count++;

    return Math.max(count, 1);
  });

  return syllableCounts.reduce((sum, count) => sum + count, 0) / words.length;
}

function calculateFleschScore(avgSentenceLength: number, avgSyllablesPerWord: number): number {
  return 206.835 - (1.015 * avgSentenceLength) - (84.6 * avgSyllablesPerWord);
}

function getReadabilityLevel(score: number): string {
  if (score >= 90) return 'Very Easy';
  if (score >= 80) return 'Easy';
  if (score >= 70) return 'Fairly Easy';
  if (score >= 60) return 'Standard';
  if (score >= 50) return 'Fairly Difficult';
  if (score >= 30) return 'Difficult';
  return 'Very Difficult';
}

function calculateKeywordDensity(words: string[], totalWords: number): { word: string; count: number; percentage: number }[] {
  const wordFrequency: Record<string, number> = {};
  const stopWords = new Set(['the', 'be', 'to', 'of', 'and', 'a', 'in', 'that', 'have', 'i', 'it', 'for', 'not', 'on', 'with', 'he', 'as', 'you', 'do', 'at', 'this', 'but', 'his', 'by', 'from', 'they', 'we', 'say', 'her', 'she', 'or', 'an', 'will', 'my', 'one', 'all', 'would', 'there', 'their']);

  words.forEach(word => {
    const cleanWord = word.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (cleanWord.length > 2 && !stopWords.has(cleanWord)) {
      wordFrequency[cleanWord] = (wordFrequency[cleanWord] || 0) + 1;
    }
  });

  return Object.entries(wordFrequency)
    .map(([word, count]) => ({
      word,
      count,
      percentage: Math.round((count / totalWords) * 1000) / 10
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);
}
