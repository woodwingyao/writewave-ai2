export function exportToTXT(content: string, filename: string = 'content') {
  const blob = new Blob([content], { type: 'text/plain' });
  downloadBlob(blob, `${filename}.txt`);
}

export function exportToHTML(content: string, filename: string = 'content') {
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${filename}</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      line-height: 1.6;
      max-width: 800px;
      margin: 40px auto;
      padding: 20px;
      color: #333;
    }
    pre {
      white-space: pre-wrap;
      word-wrap: break-word;
    }
  </style>
</head>
<body>
  <pre>${content.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
</body>
</html>`;

  const blob = new Blob([html], { type: 'text/html' });
  downloadBlob(blob, `${filename}.html`);
}

export function exportToMarkdown(content: string, filename: string = 'content') {
  const blob = new Blob([content], { type: 'text/markdown' });
  downloadBlob(blob, `${filename}.md`);
}

export function exportToPDF(content: string, filename: string = 'content', metadata?: { topic?: string; tone?: string; audience?: string }) {
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${filename}</title>
  <style>
    @page {
      margin: 2cm;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      line-height: 1.8;
      color: #1e293b;
      font-size: 12pt;
    }
    .header {
      border-bottom: 2px solid #3b82f6;
      padding-bottom: 16px;
      margin-bottom: 32px;
    }
    .title {
      font-size: 24pt;
      font-weight: bold;
      color: #1e293b;
      margin-bottom: 8px;
    }
    .metadata {
      display: flex;
      gap: 16px;
      font-size: 10pt;
      color: #64748b;
      margin-top: 8px;
    }
    .metadata-item {
      background: #f1f5f9;
      padding: 4px 12px;
      border-radius: 4px;
    }
    .content {
      white-space: pre-wrap;
      word-wrap: break-word;
      font-size: 11pt;
      line-height: 1.8;
    }
    .footer {
      margin-top: 48px;
      padding-top: 16px;
      border-top: 1px solid #e2e8f0;
      font-size: 9pt;
      color: #94a3b8;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="title">${escapeHtml(filename)}</div>
    ${metadata ? `
    <div class="metadata">
      ${metadata.topic ? `<span class="metadata-item">Topic: ${escapeHtml(metadata.topic)}</span>` : ''}
      ${metadata.tone ? `<span class="metadata-item">Tone: ${escapeHtml(metadata.tone)}</span>` : ''}
      ${metadata.audience ? `<span class="metadata-item">Audience: ${escapeHtml(metadata.audience)}</span>` : ''}
    </div>
    ` : ''}
  </div>
  <div class="content">${escapeHtml(content)}</div>
  <div class="footer">
    Generated on ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })} | WriteWave AI
  </div>
</body>
</html>`;

  const blob = new Blob([html], { type: 'text/html' });
  downloadBlob(blob, `${filename}.html`);

  window.open(URL.createObjectURL(blob), '_blank');
}

export function exportToDOCX(content: string, filename: string = 'content', metadata?: { topic?: string; tone?: string; audience?: string }) {
  const htmlContent = `
    <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
    <head>
      <meta charset='utf-8'>
      <title>${escapeHtml(filename)}</title>
      <style>
        body {
          font-family: Calibri, sans-serif;
          font-size: 11pt;
          line-height: 1.6;
        }
        .header {
          border-bottom: 2px solid #3b82f6;
          padding-bottom: 12pt;
          margin-bottom: 24pt;
        }
        .title {
          font-size: 20pt;
          font-weight: bold;
          color: #1e293b;
          margin-bottom: 6pt;
        }
        .metadata {
          font-size: 9pt;
          color: #64748b;
          margin-top: 6pt;
        }
        .content {
          white-space: pre-wrap;
          margin-bottom: 24pt;
        }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="title">${escapeHtml(filename)}</div>
        ${metadata ? `
        <div class="metadata">
          ${metadata.topic ? `Topic: ${escapeHtml(metadata.topic)} | ` : ''}
          ${metadata.tone ? `Tone: ${escapeHtml(metadata.tone)} | ` : ''}
          ${metadata.audience ? `Audience: ${escapeHtml(metadata.audience)}` : ''}
        </div>
        ` : ''}
      </div>
      <div class="content">${escapeHtml(content)}</div>
    </body>
    </html>
  `;

  const blob = new Blob(['\ufeff', htmlContent], {
    type: 'application/msword'
  });

  downloadBlob(blob, `${filename}.doc`);
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
