export interface Template {
  id: string;
  name: string;
  icon: string;
  description: string;
  prompt: string;
}

export const templates: Template[] = [
  {
    id: 'social-caption',
    name: 'Social Media Caption',
    icon: 'MessageCircle',
    description: 'Engaging captions for Instagram, TikTok, YouTube',
    prompt: `You are an expert social media copywriter.

Write 3 short, catchy, engaging captions for social media (Instagram/TikTok/YouTube).
Topic: {{topic}}
Audience: {{audience}}
Tone: {{tone}}
Additional details: {{details}}

Keep each caption within 15–50 words.
Include strong hooks and modern content style.
Return them as a numbered list (1., 2., 3.).`
  },
  {
    id: 'youtube-title',
    name: 'YouTube Title',
    icon: 'Youtube',
    description: 'High CTR, clickable video titles',
    prompt: `You are an expert YouTube SEO strategist.

Generate 5 highly clickable YouTube video titles.
Topic: {{topic}}
Tone: {{tone}}

Titles should be:
- 45–60 characters
- High CTR
- Emotion-driven
- Contain curiosity

Return them as a numbered list (1., 2., 3., 4., 5.).`
  },
  {
    id: 'youtube-script',
    name: 'YouTube Script Outline',
    icon: 'FileText',
    description: 'Complete video script structure',
    prompt: `You are a YouTube content strategist.

Create a short 8-part video script outline for:
{{topic}}

Audience: {{audience}}
Tone: {{tone}}

Include:
- Hook (first 3 seconds)
- Problem identification
- Key points (3-4 main ideas)
- Examples or stories
- Call to action

Format it clearly with section headers.`
  },
  {
    id: 'video-hook',
    name: 'Short Video Hook',
    icon: 'Zap',
    description: 'Attention-grabbing first 3 seconds',
    prompt: `You are an expert at creating viral short-form video hooks.

Generate 5 powerful opening hooks for a video about:
{{topic}}

Audience: {{audience}}
Tone: {{tone}}

Each hook should:
- Be 5-10 words max
- Stop the scroll
- Create curiosity or urgency
- Work for TikTok/Reels/Shorts

Return them as a numbered list (1., 2., 3., 4., 5.).`
  },
  {
    id: 'blog-intro',
    name: 'Blog Post Intro',
    icon: 'PenTool',
    description: 'Compelling article opening paragraphs',
    prompt: `You are an expert blog writer.

Write a compelling blog post introduction about:
{{topic}}

Audience: {{audience}}
Tone: {{tone}}
Additional context: {{details}}

The intro should:
- Be 100-150 words
- Hook the reader immediately
- Present the problem or question
- Hint at the solution
- Make them want to read more

Provide 2 different versions.`
  },
  {
    id: 'ad-copy',
    name: 'Ad Copy',
    icon: 'Megaphone',
    description: 'Facebook, TikTok, Google Ads',
    prompt: `You are an expert advertising copywriter.

Write 3 high-converting ad copies for:
Product/Service: {{topic}}
Target Audience: {{audience}}
Tone: {{tone}}
Details: {{details}}

Each ad should include:
- Attention-grabbing headline
- 2-3 sentences of persuasive body copy
- Strong call-to-action

Keep each ad under 100 words.
Return them as Version 1, Version 2, Version 3.`
  },
  {
    id: 'product-description',
    name: 'Product Description',
    icon: 'ShoppingBag',
    description: 'Compelling e-commerce copy',
    prompt: `You are an expert e-commerce copywriter.

Write a compelling product description.
Product: {{topic}}
Audience: {{audience}}
Tone: {{tone}}
Extra: {{details}}

Include:
- 2 sentence hook that captures attention
- 3-5 bullet points highlighting key benefits (not just features)
- 1 short, compelling call-to-action

Make it persuasive and conversion-focused.`
  },
  {
    id: 'email-subject',
    name: 'Email Subject Line',
    icon: 'Mail',
    description: 'High open-rate subject lines',
    prompt: `You are an expert email marketing copywriter.

Generate 10 highly effective email subject lines for:
Topic: {{topic}}
Audience: {{audience}}
Tone: {{tone}}

Subject lines should:
- Be 30-50 characters
- Create curiosity or urgency
- Be specific and benefit-driven
- Avoid spam trigger words
- Have high open rates

Return them as a numbered list (1-10).`
  },
  {
    id: 'slogan',
    name: 'Slogan / Tagline',
    icon: 'Sparkles',
    description: 'Memorable brand taglines',
    prompt: `You are an expert brand strategist and slogan writer.

Create 8 memorable, catchy slogans/taglines for:
Brand/Product: {{topic}}
Target Audience: {{audience}}
Tone: {{tone}}
Additional context: {{details}}

Each slogan should:
- Be 3-7 words
- Be memorable and easy to say
- Capture the brand essence
- Be unique and ownable

Return them as a numbered list (1-8).`
  },
  {
    id: 'text-rewriter',
    name: 'Text Rewriter / Polisher',
    icon: 'RefreshCw',
    description: 'Improve clarity and engagement',
    prompt: `Rewrite the following text with improved clarity, flow, and engagement.
Tone: {{tone}}
Target Audience: {{audience}}

Original Text:
{{details}}

Provide 2 rewritten versions:
- Version 1: Slightly improved with minor edits
- Version 2: Completely reimagined while keeping the core message

Make it more compelling and professional.`
  },
  {
    id: 'email-newsletter',
    name: 'Email Newsletter',
    icon: 'Newspaper',
    description: 'Full newsletter with subject and content',
    prompt: `You are an expert email newsletter writer.

Create a complete email newsletter about:
{{topic}}

Audience: {{audience}}
Tone: {{tone}}
Additional details: {{details}}

Format as:
Subject: [Compelling subject line]

[Engaging opening paragraph]

[Main content section with 2-3 key points]

[Clear call-to-action]

Best,
[Sign-off]

Keep it 200-300 words, scannable, and action-oriented.`
  },
  {
    id: 'sales-email',
    name: 'Sales Email',
    icon: 'TrendingUp',
    description: 'Persuasive outreach and cold emails',
    prompt: `You are an expert sales copywriter.

Write a persuasive sales email for:
Product/Service: {{topic}}
Target: {{audience}}
Tone: {{tone}}
Context: {{details}}

Include:
- Personalized opening that shows research
- Problem statement they face
- How your solution helps
- Social proof or credibility
- Soft call-to-action

Keep it under 150 words. Make it conversational and valuable, not pushy.
Provide 2 versions: one for cold outreach, one for warm leads.`
  },
  {
    id: 'landing-page',
    name: 'Landing Page Copy',
    icon: 'Layout',
    description: 'Full landing page structure',
    prompt: `You are an expert conversion copywriter.

Create landing page copy for:
{{topic}}

Audience: {{audience}}
Tone: {{tone}}
Details: {{details}}

Structure:
[HERO]
Headline: [Bold, benefit-driven, 5-8 words]
Subheadline: [Clarify value, 15-20 words]

[PROBLEM]
[2-3 sentences describing the pain point]

[SOLUTION]
[3 bullet points of key benefits]

[HOW IT WORKS]
[3 simple steps]

[CTA]
[Compelling call-to-action]

Make it clear, scannable, and conversion-focused.`
  },
  {
    id: 'google-ads',
    name: 'Google Ads',
    icon: 'Search',
    description: 'Search ads with headlines and descriptions',
    prompt: `You are a Google Ads expert.

Create Google Search Ads for:
Product/Service: {{topic}}
Audience: {{audience}}
Tone: {{tone}}
Details: {{details}}

Generate 3 complete ad sets, each with:

Headlines (3 options, 30 characters each):
- [Headline 1]
- [Headline 2]
- [Headline 3]

Descriptions (2 options, 90 characters each):
- [Description 1]
- [Description 2]

Make them keyword-rich, benefit-focused, and action-oriented.
Include urgency and clear value proposition.`
  },
  {
    id: 'instagram-ad',
    name: 'Instagram Ad',
    icon: 'Instagram',
    description: 'Visual-first ad copy for IG',
    prompt: `You are an Instagram advertising expert.

Create Instagram ad copy for:
{{topic}}

Audience: {{audience}}
Tone: {{tone}}
Details: {{details}}

Include:
- Scroll-stopping opening line
- 2-3 benefit-focused sentences
- Emoji usage (if appropriate for tone)
- Strong call-to-action
- 3-5 relevant hashtags

Keep it under 125 characters for primary text.
Make it visual, emotional, and action-oriented.
Provide 3 variations.`
  },
  {
    id: 'linkedin-post',
    name: 'LinkedIn Post',
    icon: 'Linkedin',
    description: 'Professional thought leadership content',
    prompt: `You are a LinkedIn content strategist.

Create a LinkedIn post about:
{{topic}}

Audience: {{audience}}
Tone: {{tone}}
Context: {{details}}

Structure:
- Hook line that stops the scroll
- Personal story or insight (2-3 sentences)
- Key takeaway or lesson
- Call for engagement (question or CTA)

Keep it 100-150 words.
Use line breaks for readability.
Be authentic and provide value.
Provide 2 versions: one story-driven, one data-driven.`
  },
  {
    id: 'video-script',
    name: 'Video Sales Script',
    icon: 'Video',
    description: 'Explainer or promotional video script',
    prompt: `You are a video scriptwriter.

Write a 60-90 second video script for:
{{topic}}

Audience: {{audience}}
Tone: {{tone}}
Details: {{details}}

Format:
[HOOK - 0:00-0:05]
[Attention-grabbing opening]

[PROBLEM - 0:05-0:20]
[Describe the pain point]

[SOLUTION - 0:20-0:50]
[Present your product/service as solution]

[PROOF - 0:50-1:10]
[Social proof or results]

[CTA - 1:10-1:30]
[Clear next step]

Include [VISUAL NOTES] for key scenes.
Keep language simple and conversational.`
  },
  {
    id: 'press-release',
    name: 'Press Release',
    icon: 'FileText',
    description: 'Professional news announcement',
    prompt: `You are a PR professional.

Write a press release for:
{{topic}}

Target: {{audience}}
Tone: {{tone}}
Details: {{details}}

Structure:
[HEADLINE - Bold, newsworthy]

[DATELINE] - [City, Date]

[LEAD PARAGRAPH - Who, what, when, where, why]

[BODY - 2-3 paragraphs with details, quotes, context]

[BOILERPLATE - About the company]

[CONTACT INFORMATION]

Keep it 300-400 words.
Use AP style. Be factual and newsworthy.`
  }
];

export const tones = [
  'Professional',
  'Friendly',
  'Humorous',
  'Persuasive',
  'Luxury',
  'Minimalist',
  'Aggressive',
  'Educational',
  'Energetic',
  'Short & Punchy'
];

export interface WritingStyle {
  id: string;
  name: string;
  description: string;
  rules: string;
}

export const writingStyles: WritingStyle[] = [
  {
    id: 'short-form',
    name: 'Short-form',
    description: 'Fast, punchy writing for social media or headlines',
    rules: '1–3 short sentences. No filler words. Direct and energetic. Optional emojis if tone allows.'
  },
  {
    id: 'long-form',
    name: 'Long-form',
    description: 'Detailed, richer writing for blogs or explanations',
    rules: '2–4 full paragraphs. More context and storytelling. Smooth transitions. More details and nuance.'
  },
  {
    id: 'concise',
    name: 'Concise',
    description: 'Business writing or executives who prefer precision',
    rules: 'Ultra-short sentences. No emotional fluff. Focus on clarity. Ideal for professional tone.'
  },
  {
    id: 'descriptive',
    name: 'Descriptive',
    description: 'Rich sensory language',
    rules: 'Use imagery. Use adjectives. Create emotional or sensory appeal.'
  },
  {
    id: 'storytelling',
    name: 'Storytelling',
    description: 'Perfect for ads, blogs, and personal branding',
    rules: 'Start with a mini-hook. Present a micro-scenario. Build emotion subtly. End with transformation or insight.'
  },
  {
    id: 'sales-oriented',
    name: 'Sales-oriented',
    description: 'Conversion-focused and persuasive',
    rules: 'Focus on benefits, not features. Strong CTA. Power words. Short, high impact sentences.'
  },
  {
    id: 'informative',
    name: 'Informative',
    description: 'Educational, neutral, helpful',
    rules: 'Clear facts. Logical structure. No hype. Neutral tone.'
  },
  {
    id: 'seo-optimized',
    name: 'SEO-optimized',
    description: 'Blog and website writing',
    rules: 'Include keywords naturally. Clear headers. Skimmable paragraphs. Callout facts or bullet lists.'
  },
  {
    id: 'conversational',
    name: 'Conversational',
    description: 'Friendly, human, chatty tone',
    rules: '"You" and "we" language. Short, informal sentences. Everyday conversational sound.'
  },
  {
    id: 'bullet-points',
    name: 'Bullet Points',
    description: 'List-style, clean structure',
    rules: 'Bullet points only. Short phrases. Easy scanning.'
  }
];

export interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  structure: string;
}

export const promptTemplates: PromptTemplate[] = [
  {
    id: 'freeform',
    name: 'Default (Free Style)',
    description: 'General writing with no structure constraints',
    structure: `No specific structure constraints. Output depends entirely on the user's prompt. Use selected tone and make the writing natural, polished, and human-like.`
  },
  {
    id: 'social-media',
    name: 'Social Media Post',
    description: 'Short, engaging captions for Instagram, TikTok, Facebook',
    structure: `Generate 1–2 short, punchy paragraphs for social media. Use a conversational tone. Include optional emojis if they fit naturally. Add 2-4 relevant hashtags at the end. Keep it engaging and scroll-stopping.`
  },
  {
    id: 'marketing-email',
    name: 'Marketing Email',
    description: 'Professional email with subject line, greeting, body, and CTA',
    structure: `Format as a complete email:

Subject: [Compelling subject line]

Hi [Name or "there"],

[Opening paragraph that establishes context]

[Body paragraph explaining benefits/value]

[Closing with clear call-to-action]

Best regards,
[Sender name or brand]

Make it professional, persuasive, and action-oriented.`
  },
  {
    id: 'product-desc',
    name: 'Product Description',
    description: 'E-commerce copy with headline, benefits, features, and CTA',
    structure: `Format as a product description:

[Compelling Headline]

[1-2 benefit-focused sentences]

Key Features:
• [Feature 1]
• [Feature 2]
• [Feature 3]

[Optional CTA]

Make it persuasive, clear, and conversion-focused.`
  },
  {
    id: 'blog-intro',
    name: 'Blog Introduction',
    description: 'Engaging opening paragraph that hooks the reader',
    structure: `Write a compelling blog introduction with:
- Hook sentence that grabs attention
- Context that frames the topic
- Promise of value
- Smooth transition to main content

Keep it 100-150 words. Make readers want to continue reading.`
  },
  {
    id: 'tagline',
    name: 'Tagline / Slogan',
    description: 'Short, memorable brand lines',
    structure: `Generate 3 variations of taglines/slogans:
• [Option 1]
• [Option 2]
• [Option 3]

Each should be:
- 3-8 words maximum
- Punchy and memorable
- Brand-focused
- Easy to remember`
  },
  {
    id: 'ad-copy',
    name: 'Ad Copy (Short-form)',
    description: 'Brief advertising copy for digital ads',
    structure: `Create short-form ad copy:

[Attention-grabbing headline]

[2-3 sentences of benefit-driven body copy]

[Strong call-to-action]

Keep it under 50 words total. Make it compelling and conversion-focused.`
  },
  {
    id: 'tiktok-caption',
    name: 'TikTok Caption',
    description: 'Fun, fast, trending social content',
    structure: `Write a TikTok-style caption:
- Engaging hook sentence
- Fun and energetic tone
- Include relevant emojis naturally
- Add 3-5 trending hashtags
- Keep it short and punchy`
  },
  {
    id: 'landing-hero',
    name: 'Landing Page Hero Text',
    description: 'Website top section with headline and subheadline',
    structure: `Create landing page hero text:

[Main Headline - Bold, benefit-driven, 5-8 words]

[Subheadline - Supporting text that clarifies value, 10-15 words]

[CTA Text Suggestion - Action-oriented, 2-4 words]

Make it clear, compelling, and conversion-focused.`
  }
];
