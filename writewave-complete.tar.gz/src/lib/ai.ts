import { templates, promptTemplates, writingStyles } from './templates';
import { supabase } from './supabase';

interface BrandVoice {
  tone: string;
  writing_style: string | null;
  key_phrases: string[] | null;
  avoid_phrases: string[] | null;
  example_text: string | null;
}

export async function generateContent(
  templateId: string,
  topic: string,
  audience: string,
  tone: string,
  details: string,
  brandVoiceId?: string,
  variations: number = 1,
  length: 'short' | 'medium' | 'long' = 'medium'
): Promise<string> {
  const startTime = Date.now();
  const template = templates.find((t) => t.id === templateId);
  if (!template) {
    throw new Error('Template not found');
  }

  let brandVoice: BrandVoice | null = null;
  if (brandVoiceId) {
    const { data, error } = await supabase
      .from('brand_voices')
      .select('tone, writing_style, key_phrases, avoid_phrases, example_text')
      .eq('id', brandVoiceId)
      .maybeSingle();

    if (!error && data) {
      brandVoice = data;
    }
  }

  let prompt = template.prompt
    .replace('{{topic}}', topic || 'N/A')
    .replace('{{audience}}', audience || 'general audience')
    .replace('{{tone}}', brandVoice?.tone || tone)
    .replace('{{details}}', details || 'N/A');

  if (brandVoice) {
    prompt += `\n\nBRAND VOICE GUIDELINES:`;

    if (brandVoice.writing_style) {
      const style = writingStyles.find(s => s.id === brandVoice.writing_style);
      if (style) {
        prompt += `\n- Writing Style: ${style.name} - ${style.rules}`;
      }
    }

    if (brandVoice.key_phrases && brandVoice.key_phrases.length > 0) {
      prompt += `\n- Key phrases to include naturally: ${brandVoice.key_phrases.join(', ')}`;
    }

    if (brandVoice.avoid_phrases && brandVoice.avoid_phrases.length > 0) {
      prompt += `\n- Phrases to avoid: ${brandVoice.avoid_phrases.join(', ')}`;
    }

    if (brandVoice.example_text) {
      prompt += `\n- Example of brand voice:\n"${brandVoice.example_text}"`;
    }
  }

  const lengthGuidelines = {
    short: '50-100 words. Be concise and punchy.',
    medium: '150-300 words. Provide good detail while staying focused.',
    long: '400-600 words. Be comprehensive and thorough with examples and details.'
  };

  prompt += `\n\nLENGTH REQUIREMENT: ${lengthGuidelines[length]}`;

  if (variations > 1) {
    prompt += `\n\nIMPORTANT: Generate ${variations} DISTINCT VARIATIONS. Each variation should:
- Be unique in wording and approach
- Maintain the same core message and tone
- Be separated by "---VARIATION---" marker
- Feel fresh and different from other variations

Output all ${variations} variations now.`;
  }

  const content = await callAI(prompt);
  const endTime = Date.now();

  trackGeneration(
    templateId,
    'template',
    content,
    brandVoice?.tone || tone,
    brandVoiceId,
    endTime - startTime
  );

  return content;
}

export async function generateFromPrompt(
  userPrompt: string,
  tone: string,
  templateId: string,
  styleId: string
): Promise<string> {
  const startTime = Date.now();
  const template = promptTemplates.find((t) => t.id === templateId);
  if (!template) {
    throw new Error('Template not found');
  }

  const style = writingStyles.find((s) => s.id === styleId);
  if (!style) {
    throw new Error('Style not found');
  }

  const systemPrompt = `You are the writing engine for "WriteWave AI".

Your job is to produce polished, structured writing based on:
1. User prompt
2. Selected template (structure)
3. Selected tone (emotion)
4. Selected style (writing rhythm + length + formatting)

CRITICAL RULES:
- Apply template structure FIRST
- Apply tone SECOND (emotion and attitude)
- Apply style THIRD (writing rhythm, length, and formatting)
- Output ONLY the final copy - no explanations, no preambles, no meta-text
- Be concise, human-like, and cleanly formatted
- Never explain what you are doing
- If user's prompt is unclear, make reasonable assumptions

VARIATION RULES (for regeneration):
- Keep the core meaning and message consistent with the prompt
- Introduce creative variation in every generation:
  * Change sentence structure and phrasing
  * Use different transitions and rhythm
  * Swap synonyms and word choices
  * Try different opening lines or hooks
  * Adjust examples or angles while maintaining intent
- NEVER repeat identical content from previous outputs
- Each generation should feel fresh but stay true to the template, tone, and style

SELECTED TONE: ${tone}

Tone Guidelines (EMOTION & ATTITUDE):
- Professional: Clear, confident, formal language
- Friendly: Warm, casual, positive, approachable
- Humorous: Light, funny, conversational, witty
- Persuasive: Benefit-driven, emotional, action-oriented, compelling
- Short & Punchy: Minimal words, maximum impact, direct
- Energetic: Enthusiastic, dynamic, uplifting, exciting
- Luxury: Elegant, sophisticated, premium, refined
- Minimalist: Simple, clean, essential, uncluttered
- Aggressive: Bold, assertive, direct, powerful
- Educational: Informative, clear, instructional, helpful

SELECTED WRITING STYLE: ${style.name}

Style Guidelines (STRUCTURE & RHYTHM):
${style.rules}

TEMPLATE FORMAT INSTRUCTIONS:
${template.structure}

USER'S REQUEST:
${userPrompt}

Generate the content now following:
1. Template structure exactly
2. Tone throughout
3. Style for rhythm and formatting`;

  const content = await callAI(systemPrompt);
  const endTime = Date.now();

  trackGeneration(
    'custom-prompt',
    'custom',
    content,
    tone,
    undefined,
    endTime - startTime
  );

  return content;
}

async function callAI(prompt: string): Promise<string> {
  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-copy`;

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
    },
    body: JSON.stringify({
      prompt,
      apiKey: import.meta.env.VITE_GEMINI_API_KEY
    }),
  });

  if (!response.ok) {
    throw new Error('Failed to generate content');
  }

  const data = await response.json();
  return data.content;
}

async function trackGeneration(
  templateId: string,
  promptType: 'template' | 'custom',
  content: string,
  tone: string,
  brandVoiceId?: string,
  generationTimeMs?: number
) {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const wordCount = content.trim().split(/\s+/).length;
    const characterCount = content.length;

    await supabase.from('content_generations').insert({
      user_id: user.id,
      template_id: templateId,
      prompt_type: promptType,
      word_count: wordCount,
      character_count: characterCount,
      tone: tone,
      brand_voice_id: brandVoiceId || null,
      generation_time_ms: generationTimeMs || 0
    });
  } catch (err) {
    console.error('Failed to track generation:', err);
  }
}
