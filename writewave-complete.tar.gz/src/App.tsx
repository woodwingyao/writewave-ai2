import { useState } from 'react';
import HomePage from './components/HomePage';
import InputPage, { type GenerateData } from './components/InputPage';
import ResultsPage from './components/ResultsPage';
import HistoryPage from './components/HistoryPage';
import PromptPage, { type PromptGenerateData } from './components/PromptPage';
import PromptResultsPage from './components/PromptResultsPage';
import PaywallPage from './components/PaywallPage';
import SuccessPage from './components/SuccessPage';
import CancelPage from './components/CancelPage';
import BrandVoicePage from './components/BrandVoicePage';
import AnalyticsPage from './components/AnalyticsPage';
import PrivacyPolicyPage from './components/PrivacyPolicyPage';
import AdvancedFeaturesPage from './components/AdvancedFeaturesPage';
import { generateContent, generateFromPrompt } from './lib/ai';

type View = 'home' | 'input' | 'results' | 'history' | 'prompt' | 'prompt-results' | 'paywall' | 'success' | 'cancel' | 'brand-voice' | 'analytics' | 'privacy' | 'advanced-features';

function App() {
  const [view, setView] = useState<View>('home');
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [generateData, setGenerateData] = useState<GenerateData | null>(null);
  const [promptData, setPromptData] = useState<PromptGenerateData | null>(null);
  const [generatedContent, setGeneratedContent] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleSelectTemplate = (templateId: string) => {
    setSelectedTemplate(templateId);
    setView('input');
  };

  const handleGenerate = async (data: GenerateData) => {
    setGenerateData(data);
    setView('results');
    setIsGenerating(true);
    setGeneratedContent('');

    try {
      const content = await generateContent(
        data.templateId,
        data.topic,
        data.audience,
        data.tone,
        data.details,
        data.brandVoiceId,
        data.variations || 1,
        data.length || 'medium'
      );
      setGeneratedContent(content);
    } catch (error) {
      console.error('Generation failed:', error);
      setGeneratedContent('Failed to generate content. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRegenerate = async () => {
    if (!generateData) return;

    setIsGenerating(true);
    setGeneratedContent('');

    try {
      const content = await generateContent(
        generateData.templateId,
        generateData.topic,
        generateData.audience,
        generateData.tone,
        generateData.details,
        generateData.brandVoiceId,
        generateData.variations || 1,
        generateData.length || 'medium'
      );
      setGeneratedContent(content);
    } catch (error) {
      console.error('Generation failed:', error);
      setGeneratedContent('Failed to generate content. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePromptGenerate = async (data: PromptGenerateData) => {
    setPromptData(data);
    setView('prompt-results');
    setIsGenerating(true);
    setGeneratedContent('');

    try {
      const content = await generateFromPrompt(
        data.prompt,
        data.tone,
        data.templateId,
        data.styleId
      );
      setGeneratedContent(content);
    } catch (error) {
      console.error('Generation failed:', error);
      setGeneratedContent('Failed to generate content. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePromptRegenerate = async () => {
    if (!promptData) return;

    setIsGenerating(true);
    setGeneratedContent('');

    try {
      const content = await generateFromPrompt(
        promptData.prompt,
        promptData.tone,
        promptData.templateId,
        promptData.styleId
      );
      setGeneratedContent(content);
    } catch (error) {
      console.error('Generation failed:', error);
      setGeneratedContent('Failed to generate content. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <>
      {view === 'home' && (
        <HomePage
          onSelectTemplate={handleSelectTemplate}
          onStartPrompt={() => setView('prompt')}
          onViewHistory={() => setView('history')}
          onUpgrade={() => setView('paywall')}
          onManageBrandVoices={() => setView('brand-voice')}
          onViewAnalytics={() => setView('analytics')}
          onAdvancedFeatures={() => setView('advanced-features')}
        />
      )}

      {view === 'input' && (
        <InputPage
          templateId={selectedTemplate}
          onGenerate={handleGenerate}
          onBack={() => setView('home')}
        />
      )}

      {view === 'results' && generateData && (
        <ResultsPage
          data={generateData}
          generatedContent={generatedContent}
          isLoading={isGenerating}
          onRegenerate={handleRegenerate}
          onBack={() => setView('input')}
          onBackToHome={() => setView('home')}
        />
      )}

      {view === 'prompt' && (
        <PromptPage
          onGenerate={handlePromptGenerate}
          onBack={() => setView('home')}
        />
      )}

      {view === 'prompt-results' && promptData && (
        <PromptResultsPage
          data={promptData}
          generatedContent={generatedContent}
          isLoading={isGenerating}
          onRegenerate={handlePromptRegenerate}
          onBack={() => setView('prompt')}
          onBackToHome={() => setView('home')}
        />
      )}

      {view === 'history' && (
        <HistoryPage onBack={() => setView('home')} />
      )}

      {view === 'paywall' && (
        <PaywallPage
          userEmail={null}
          onBack={() => setView('home')}
        />
      )}

      {view === 'success' && (
        <SuccessPage onGoHome={() => setView('home')} />
      )}

      {view === 'cancel' && (
        <CancelPage
          onGoBack={() => setView('paywall')}
          onGoHome={() => setView('home')}
        />
      )}

      {view === 'brand-voice' && (
        <BrandVoicePage
          userEmail={null}
          onBack={() => setView('home')}
        />
      )}

      {view === 'analytics' && (
        <AnalyticsPage
          onBack={() => setView('home')}
        />
      )}

      {view === 'privacy' && (
        <PrivacyPolicyPage
          onBack={() => setView('home')}
        />
      )}

      {view === 'advanced-features' && (
        <AdvancedFeaturesPage
          onBack={() => setView('home')}
          userEmail={null}
        />
      )}
    </>
  );
}

export default App;
