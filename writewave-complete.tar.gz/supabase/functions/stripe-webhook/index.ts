import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";
import Stripe from "npm:stripe@17.3.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey, stripe-signature",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2024-11-20.acacia",
    });

    const signature = req.headers.get("stripe-signature");
    if (!signature) {
      return new Response(
        JSON.stringify({ error: "No signature provided" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body = await req.text();
    const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");

    let event: Stripe.Event;
    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret || "");
    } catch (err) {
      console.error("Webhook signature verification failed:", err);
      return new Response(
        JSON.stringify({ error: `Webhook Error: ${err.message}` }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") || "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || ""
    );

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const email = session.customer_details?.email;
        const customerId = session.customer as string;
        const subscriptionId = session.subscription as string;

        if (!email) {
          console.error("No email in checkout session");
          break;
        }

        const subscription = await stripe.subscriptions.retrieve(subscriptionId);
        const isTrialing = subscription.status === "trialing";
        const trialEnd = subscription.trial_end ? new Date(subscription.trial_end * 1000).toISOString() : null;

        const { error } = await supabase
          .from("users")
          .update({
            role: "pro",
            stripe_customer_id: customerId,
            stripe_subscription_id: subscriptionId,
            subscription_status: subscription.status,
            current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
            trial_end: trialEnd,
            trial_used: true,
            updated_at: new Date().toISOString(),
          })
          .eq("email", email);

        if (error) {
          console.error("Failed to update user:", error);
        } else {
          console.log(`User ${email} upgraded to Pro${isTrialing ? " (in trial)" : ""}`);

          const emailHtml = `
            <!DOCTYPE html>
            <html>
            <head>
              <meta charset="utf-8">
              <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                .button { display: inline-block; background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
              </style>
            </head>
            <body>
              <div class="container">
                <div class="header">
                  <h1>🎉 Welcome to AI Copywriter Studio Pro!</h1>
                </div>
                <div class="content">
                  <p>Hi there,</p>
                  <p><strong>Thank you for subscribing to AI Copywriter Studio Pro!</strong></p>
                  ${isTrialing ? `
                    <p>Your <strong>7-day free trial</strong> has started! You now have full access to all Pro features:</p>
                  ` : `
                    <p>Your subscription is now active! You have full access to all Pro features:</p>
                  `}
                  <ul>
                    <li>✨ Unlimited AI-powered copy generation</li>
                    <li>📝 Access to all premium templates</li>
                    <li>💼 Professional copywriting tools</li>
                    <li>🚀 Priority support</li>
                  </ul>
                  ${isTrialing ? `
                    <p><strong>Important:</strong> Your trial ends on ${new Date(subscription.trial_end! * 1000).toLocaleDateString()}. After that, you'll be charged and your subscription will continue automatically.</p>
                  ` : ''}
                  <p>Start creating amazing copy right now!</p>
                  <div style="text-align: center;">
                    <a href="https://aicopywriter.studio" class="button">Get Started</a>
                  </div>
                  <p>If you have any questions, feel free to reach out to us anytime.</p>
                  <p>Best regards,<br>The AI Copywriter Studio Team</p>
                </div>
                <div class="footer">
                  <p>© ${new Date().getFullYear()} AI Copywriter Studio. All rights reserved.</p>
                </div>
              </div>
            </body>
            </html>
          `;

          try {
            const emailResponse = await fetch(
              `${Deno.env.get("SUPABASE_URL")}/functions/v1/send-email`,
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "Authorization": `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}`,
                },
                body: JSON.stringify({
                  to: email,
                  subject: isTrialing
                    ? "🎉 Your 7-Day Free Trial Has Started!"
                    : "🎉 Welcome to AI Copywriter Studio Pro!",
                  html: emailHtml,
                }),
              }
            );

            if (!emailResponse.ok) {
              console.error("Failed to send welcome email:", await emailResponse.text());
            } else {
              console.log(`Welcome email sent to ${email}`);
            }
          } catch (emailError) {
            console.error("Error sending welcome email:", emailError);
          }
        }
        break;
      }

      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription;
        const customerId = subscription.customer as string;
        const trialEnd = subscription.trial_end ? new Date(subscription.trial_end * 1000).toISOString() : null;

        const updateData: any = {
          subscription_status: subscription.status,
          current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
          updated_at: new Date().toISOString(),
        };

        if (trialEnd) {
          updateData.trial_end = trialEnd;
        }

        if (subscription.status === "active" && subscription.trial_end === null) {
          updateData.trial_end = null;
        }

        const { error } = await supabase
          .from("users")
          .update(updateData)
          .eq("stripe_customer_id", customerId);

        if (error) {
          console.error("Failed to update subscription:", error);
        }
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        const customerId = subscription.customer as string;

        const { error } = await supabase
          .from("users")
          .update({
            role: "free",
            subscription_status: "canceled",
            updated_at: new Date().toISOString(),
          })
          .eq("stripe_customer_id", customerId);

        if (error) {
          console.error("Failed to downgrade user:", error);
        } else {
          console.log(`User downgraded to free`);
        }
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return new Response(
      JSON.stringify({ received: true }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Webhook handler error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});