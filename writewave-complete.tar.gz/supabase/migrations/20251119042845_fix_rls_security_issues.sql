/*
  # Fix RLS and Security Issues

  1. Performance Improvements
    - Update RLS policies to use (select auth.uid()) for better performance
    - This prevents re-evaluation of auth functions for each row
  
  2. Security Improvements
    - Add SET search_path to functions for security
    - Fixes function search path mutability issues
  
  3. Index Management
    - Keep email and stripe_customer_id indexes as they will be used for lookups
  
  4. Changes Made
    - Drop and recreate all RLS policies with optimized auth function calls
    - Update handle_new_user function with proper search_path
    - Update handle_updated_at function with proper search_path
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can read own data" ON users;
DROP POLICY IF EXISTS "Users can insert own data" ON users;
DROP POLICY IF EXISTS "Users can update own data" ON users;

-- Recreate policies with optimized auth function calls
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = id);

CREATE POLICY "Users can insert own data"
  ON users
  FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = id)
  WITH CHECK ((select auth.uid()) = id);

-- Fix function search path security issues
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.users (id, email, role)
  VALUES (new.id, new.email, 'free')
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$;

CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;