/*
  # Create Saved Copy History Table

  1. New Tables
    - `saved_copies`
      - `id` (uuid, primary key) - Unique identifier for each saved copy
      - `template_type` (text) - Type of template used
      - `content` (text) - Generated copy content
      - `topic` (text) - Main topic/product name used
      - `audience` (text, nullable) - Target audience
      - `tone` (text) - Tone of voice used
      - `details` (text, nullable) - Additional details provided
      - `created_at` (timestamptz) - Timestamp when saved
  
  2. Security
    - Enable RLS on `saved_copies` table
    - Add policy for anyone to insert (no auth required)
    - Add policy for anyone to read their own data (no auth required, using session)
    - Add policy for anyone to delete their own data

  3. Notes
    - This app doesn't require authentication
    - Users can save, view, and delete their generated copy
    - Data is accessible without login for simplicity
*/

CREATE TABLE IF NOT EXISTS saved_copies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_type text NOT NULL,
  content text NOT NULL,
  topic text NOT NULL,
  audience text DEFAULT '',
  tone text NOT NULL,
  details text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE saved_copies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert saved copies"
  ON saved_copies
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anyone can view all saved copies"
  ON saved_copies
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anyone can delete saved copies"
  ON saved_copies
  FOR DELETE
  TO anon
  USING (true);

CREATE INDEX IF NOT EXISTS idx_saved_copies_created_at ON saved_copies(created_at DESC);