/*
  # Add Trial Support to Subscription System

  1. Changes to Tables
    - Add `trial_end` column to `users` table
    - Add `trial_used` column to `users` table to prevent multiple trials
  
  2. Purpose
    - Track when a user's trial period ends
    - Prevent users from starting multiple trials
    - Allow free access to Pro features during trial
  
  3. Security
    - No RLS changes needed (existing policies cover these columns)
  
  4. Notes
    - Trial period is 7 days from subscription start
    - Users with active trial will have subscription_status = 'trialing'
    - After trial, if payment successful, status becomes 'active'
*/

-- Add trial tracking columns
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'trial_end'
  ) THEN
    ALTER TABLE users ADD COLUMN trial_end timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'trial_used'
  ) THEN
    ALTER TABLE users ADD COLUMN trial_used boolean DEFAULT false;
  END IF;
END $$;

-- Create index for trial queries
CREATE INDEX IF NOT EXISTS users_trial_end_idx ON users(trial_end);

-- Add comments for documentation
COMMENT ON COLUMN users.trial_end IS 'End date of 7-day free trial period';
COMMENT ON COLUMN users.trial_used IS 'Whether user has already used their free trial';