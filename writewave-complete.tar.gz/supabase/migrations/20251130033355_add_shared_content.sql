/*
  # Add Content Sharing Feature

  1. New Tables
    - `shared_content`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `content` (text, the generated content)
      - `template_id` (text, template type)
      - `topic` (text, optional)
      - `tone` (text, optional)
      - `audience` (text, optional)
      - `details` (text, optional)
      - `share_token` (text, unique, for public access)
      - `view_count` (integer, default 0)
      - `is_public` (boolean, default true)
      - `expires_at` (timestamptz, optional expiration)
      - `created_at` (timestamptz, default now())

  2. Security
    - Enable RLS on `shared_content` table
    - Add policy for users to create their own shared content
    - Add policy for users to view their own shared content
    - Add policy for anyone to view public shared content via share_token
    - Add policy for users to update/delete their own shared content

  3. Indexes
    - Add index on share_token for fast lookups
    - Add index on user_id for user's shared content
*/

CREATE TABLE IF NOT EXISTS shared_content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  content text NOT NULL,
  template_id text NOT NULL,
  topic text,
  tone text,
  audience text,
  details text,
  share_token text UNIQUE NOT NULL DEFAULT encode(gen_random_bytes(16), 'base64'),
  view_count integer DEFAULT 0,
  is_public boolean DEFAULT true,
  expires_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE shared_content ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can create their own shared content"
  ON shared_content
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own shared content"
  ON shared_content
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Anyone can view public shared content"
  ON shared_content
  FOR SELECT
  TO public
  USING (is_public = true AND (expires_at IS NULL OR expires_at > now()));

CREATE POLICY "Users can update their own shared content"
  ON shared_content
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own shared content"
  ON shared_content
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_shared_content_share_token ON shared_content(share_token);
CREATE INDEX IF NOT EXISTS idx_shared_content_user_id ON shared_content(user_id);
CREATE INDEX IF NOT EXISTS idx_shared_content_created_at ON shared_content(created_at DESC);