/*
  # Add Comprehensive Feature Set

  ## 1. Team Collaboration
  - `workspaces` - Team workspaces with multiple members
  - `workspace_members` - Members and their roles in workspaces
  - `workspace_invites` - Pending invitations to join workspaces

  ## 2. Content Calendar & Scheduling
  - `scheduled_content` - Content scheduled for future publication
  - Links to saved_copies for the actual content

  ## 3. AI Content Improvement Tools
  - `content_analysis` - Store analysis results (tone, readability, SEO, grammar)
  - Linked to saved content for tracking improvements

  ## 4. Multi-language Support
  - Add `language` column to saved_copies
  - `translations` - Store translated versions of content

  ## 5. A/B Testing & Variations
  - `ab_tests` - A/B test configurations
  - `ab_test_variants` - Different variations being tested
  - `ab_test_results` - Performance metrics for each variant

  ## 6. Integration Features
  - `integrations` - Connected platforms (social media, WordPress, etc.)
  - `integration_posts` - Track posts published through integrations

  ## 7. Content Library Organization
  - `folders` - Organize content into folders
  - `content_tags` - Tag system for content
  - Add folder_id to saved_copies

  ## 8. Usage Dashboard
  - `usage_tracking` - Track words generated, API calls, etc.
  - `usage_limits` - Define limits per subscription tier

  ## 9. Custom Templates
  - `custom_templates` - User-created templates
  - `template_marketplace` - Share/sell templates

  ## 10. AI Style Training
  - `training_content` - User-uploaded content for AI training
  - `feedback_history` - Thumbs up/down feedback on generated content

  ## Security
  - Enable RLS on all tables
  - Add appropriate policies for each feature
*/

-- 1. TEAM COLLABORATION

CREATE TABLE IF NOT EXISTS workspaces (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text DEFAULT '',
  owner_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS workspace_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role text NOT NULL CHECK (role IN ('admin', 'editor', 'viewer')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(workspace_id, user_id)
);

ALTER TABLE workspaces ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view workspaces they own or are members of"
  ON workspaces FOR SELECT
  TO authenticated
  USING (
    auth.uid() = owner_id OR
    EXISTS (
      SELECT 1 FROM workspace_members
      WHERE workspace_members.workspace_id = workspaces.id
      AND workspace_members.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create their own workspaces"
  ON workspaces FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Workspace owners can update their workspaces"
  ON workspaces FOR UPDATE
  TO authenticated
  USING (auth.uid() = owner_id)
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Workspace owners can delete their workspaces"
  ON workspaces FOR DELETE
  TO authenticated
  USING (auth.uid() = owner_id);

ALTER TABLE workspace_members ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view workspace members in their workspaces"
  ON workspace_members FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM workspaces
      WHERE workspaces.id = workspace_members.workspace_id
      AND workspaces.owner_id = auth.uid()
    )
  );

CREATE POLICY "Workspace owners and admins can add members"
  ON workspace_members FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM workspaces
      WHERE workspaces.id = workspace_id
      AND (
        workspaces.owner_id = auth.uid() OR
        EXISTS (
          SELECT 1 FROM workspace_members wm
          WHERE wm.workspace_id = workspace_id
          AND wm.user_id = auth.uid()
          AND wm.role = 'admin'
        )
      )
    )
  );

CREATE POLICY "Workspace owners and admins can update members"
  ON workspace_members FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM workspaces
      WHERE workspaces.id = workspace_id
      AND (
        workspaces.owner_id = auth.uid() OR
        EXISTS (
          SELECT 1 FROM workspace_members wm
          WHERE wm.workspace_id = workspace_id
          AND wm.user_id = auth.uid()
          AND wm.role = 'admin'
        )
      )
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM workspaces
      WHERE workspaces.id = workspace_id
      AND (
        workspaces.owner_id = auth.uid() OR
        EXISTS (
          SELECT 1 FROM workspace_members wm
          WHERE wm.workspace_id = workspace_id
          AND wm.user_id = auth.uid()
          AND wm.role = 'admin'
        )
      )
    )
  );

CREATE POLICY "Workspace owners and admins can remove members"
  ON workspace_members FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM workspaces
      WHERE workspaces.id = workspace_id
      AND (
        workspaces.owner_id = auth.uid() OR
        EXISTS (
          SELECT 1 FROM workspace_members wm
          WHERE wm.workspace_id = workspace_id
          AND wm.user_id = auth.uid()
          AND wm.role = 'admin'
        )
      )
    )
  );

CREATE TABLE IF NOT EXISTS workspace_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE NOT NULL,
  email text NOT NULL,
  role text NOT NULL CHECK (role IN ('admin', 'editor', 'viewer')),
  invited_by uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'declined')),
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz DEFAULT now() + interval '7 days'
);

ALTER TABLE workspace_invites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view invites for their email"
  ON workspace_invites FOR SELECT
  TO authenticated
  USING (
    email = (SELECT email FROM auth.users WHERE id = auth.uid()) OR
    EXISTS (
      SELECT 1 FROM workspaces
      WHERE workspaces.id = workspace_invites.workspace_id
      AND workspaces.owner_id = auth.uid()
    )
  );

CREATE POLICY "Workspace owners and admins can create invites"
  ON workspace_invites FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = invited_by AND
    EXISTS (
      SELECT 1 FROM workspaces
      WHERE workspaces.id = workspace_id
      AND (
        workspaces.owner_id = auth.uid() OR
        EXISTS (
          SELECT 1 FROM workspace_members wm
          WHERE wm.workspace_id = workspace_id
          AND wm.user_id = auth.uid()
          AND wm.role = 'admin'
        )
      )
    )
  );

CREATE POLICY "Users can update invites sent to them"
  ON workspace_invites FOR UPDATE
  TO authenticated
  USING (email = (SELECT email FROM auth.users WHERE id = auth.uid()))
  WITH CHECK (email = (SELECT email FROM auth.users WHERE id = auth.uid()));

-- 2. CONTENT CALENDAR & SCHEDULING

CREATE TABLE IF NOT EXISTS scheduled_content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE,
  content_id uuid REFERENCES saved_copies(id) ON DELETE CASCADE NOT NULL,
  scheduled_for timestamptz NOT NULL,
  platform text NOT NULL,
  status text DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'published', 'failed', 'cancelled')),
  published_at timestamptz,
  error_message text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE scheduled_content ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own scheduled content"
  ON scheduled_content FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM workspace_members
      WHERE workspace_members.workspace_id = scheduled_content.workspace_id
      AND workspace_members.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create scheduled content"
  ON scheduled_content FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own scheduled content"
  ON scheduled_content FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own scheduled content"
  ON scheduled_content FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- 3. AI CONTENT IMPROVEMENT TOOLS

CREATE TABLE IF NOT EXISTS content_analysis (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  content_id uuid REFERENCES saved_copies(id) ON DELETE CASCADE,
  content_text text NOT NULL,
  tone_score jsonb DEFAULT '{}',
  readability_score numeric,
  seo_score numeric,
  grammar_issues jsonb DEFAULT '[]',
  keyword_density jsonb DEFAULT '{}',
  suggestions jsonb DEFAULT '[]',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE content_analysis ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own content analysis"
  ON content_analysis FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create content analysis"
  ON content_analysis FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own content analysis"
  ON content_analysis FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- 4. MULTI-LANGUAGE SUPPORT

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'saved_copies' AND column_name = 'language'
  ) THEN
    ALTER TABLE saved_copies ADD COLUMN language text DEFAULT 'en';
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS translations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  original_content_id uuid REFERENCES saved_copies(id) ON DELETE CASCADE NOT NULL,
  language text NOT NULL,
  translated_text text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE translations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own translations"
  ON translations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create translations"
  ON translations FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own translations"
  ON translations FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- 5. A/B TESTING & VARIATIONS

CREATE TABLE IF NOT EXISTS ab_tests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text DEFAULT '',
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'running', 'completed', 'archived')),
  started_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE ab_tests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own A/B tests"
  ON ab_tests FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM workspace_members
      WHERE workspace_members.workspace_id = ab_tests.workspace_id
      AND workspace_members.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create A/B tests"
  ON ab_tests FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own A/B tests"
  ON ab_tests FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own A/B tests"
  ON ab_tests FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS ab_test_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  test_id uuid REFERENCES ab_tests(id) ON DELETE CASCADE NOT NULL,
  content_id uuid REFERENCES saved_copies(id) ON DELETE CASCADE NOT NULL,
  variant_name text NOT NULL,
  traffic_percentage numeric DEFAULT 50 CHECK (traffic_percentage >= 0 AND traffic_percentage <= 100),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE ab_test_variants ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view variants of their A/B tests"
  ON ab_test_variants FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM ab_tests
      WHERE ab_tests.id = ab_test_variants.test_id
      AND ab_tests.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create variants for their A/B tests"
  ON ab_test_variants FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM ab_tests
      WHERE ab_tests.id = test_id
      AND ab_tests.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update variants of their A/B tests"
  ON ab_test_variants FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM ab_tests
      WHERE ab_tests.id = test_id
      AND ab_tests.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM ab_tests
      WHERE ab_tests.id = test_id
      AND ab_tests.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete variants of their A/B tests"
  ON ab_test_variants FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM ab_tests
      WHERE ab_tests.id = test_id
      AND ab_tests.user_id = auth.uid()
    )
  );

CREATE TABLE IF NOT EXISTS ab_test_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  variant_id uuid REFERENCES ab_test_variants(id) ON DELETE CASCADE NOT NULL,
  impressions integer DEFAULT 0,
  clicks integer DEFAULT 0,
  conversions integer DEFAULT 0,
  engagement_rate numeric DEFAULT 0,
  recorded_at timestamptz DEFAULT now()
);

ALTER TABLE ab_test_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view results of their A/B tests"
  ON ab_test_results FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM ab_test_variants
      JOIN ab_tests ON ab_tests.id = ab_test_variants.test_id
      WHERE ab_test_variants.id = ab_test_results.variant_id
      AND ab_tests.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create results for their A/B tests"
  ON ab_test_results FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM ab_test_variants
      JOIN ab_tests ON ab_tests.id = ab_test_variants.test_id
      WHERE ab_test_variants.id = variant_id
      AND ab_tests.user_id = auth.uid()
    )
  );

-- 6. INTEGRATION FEATURES

CREATE TABLE IF NOT EXISTS integrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE,
  platform text NOT NULL,
  access_token text NOT NULL,
  refresh_token text,
  expires_at timestamptz,
  status text DEFAULT 'active' CHECK (status IN ('active', 'expired', 'revoked')),
  settings jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE integrations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own integrations"
  ON integrations FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM workspace_members
      WHERE workspace_members.workspace_id = integrations.workspace_id
      AND workspace_members.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create integrations"
  ON integrations FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own integrations"
  ON integrations FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own integrations"
  ON integrations FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS integration_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  integration_id uuid REFERENCES integrations(id) ON DELETE CASCADE NOT NULL,
  content_id uuid REFERENCES saved_copies(id) ON DELETE CASCADE NOT NULL,
  external_id text,
  platform_url text,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'published', 'failed')),
  error_message text,
  published_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE integration_posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their integration posts"
  ON integration_posts FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM integrations
      WHERE integrations.id = integration_posts.integration_id
      AND integrations.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create integration posts"
  ON integration_posts FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM integrations
      WHERE integrations.id = integration_id
      AND integrations.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update their integration posts"
  ON integration_posts FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM integrations
      WHERE integrations.id = integration_id
      AND integrations.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM integrations
      WHERE integrations.id = integration_id
      AND integrations.user_id = auth.uid()
    )
  );

-- 7. CONTENT LIBRARY ORGANIZATION

CREATE TABLE IF NOT EXISTS folders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  parent_folder_id uuid REFERENCES folders(id) ON DELETE CASCADE,
  color text DEFAULT '#6366f1',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE folders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own folders"
  ON folders FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM workspace_members
      WHERE workspace_members.workspace_id = folders.workspace_id
      AND workspace_members.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create folders"
  ON folders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own folders"
  ON folders FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own folders"
  ON folders FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'saved_copies' AND column_name = 'folder_id'
  ) THEN
    ALTER TABLE saved_copies ADD COLUMN folder_id uuid REFERENCES folders(id) ON DELETE SET NULL;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS content_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  content_id uuid REFERENCES saved_copies(id) ON DELETE CASCADE NOT NULL,
  tag text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(content_id, tag)
);

ALTER TABLE content_tags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view tags for their content"
  ON content_tags FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create tags for their content"
  ON content_tags FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete tags from their content"
  ON content_tags FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- 8. USAGE DASHBOARD

CREATE TABLE IF NOT EXISTS usage_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  words_generated integer DEFAULT 0,
  api_calls integer DEFAULT 0,
  content_items integer DEFAULT 0,
  period_start timestamptz NOT NULL,
  period_end timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE usage_tracking ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own usage tracking"
  ON usage_tracking FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "System can insert usage tracking"
  ON usage_tracking FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS usage_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscription_tier text NOT NULL,
  words_per_month integer NOT NULL,
  api_calls_per_month integer NOT NULL,
  content_items_per_month integer NOT NULL,
  team_members integer DEFAULT 1,
  custom_templates integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE usage_limits ENABLE ROW LEVEL SECURITY;

CREATE POLICY "All authenticated users can view usage limits"
  ON usage_limits FOR SELECT
  TO authenticated
  USING (true);

INSERT INTO usage_limits (subscription_tier, words_per_month, api_calls_per_month, content_items_per_month, team_members, custom_templates)
VALUES 
  ('free', 5000, 50, 10, 1, 0),
  ('pro', 50000, 500, 100, 5, 20),
  ('enterprise', -1, -1, -1, -1, -1)
ON CONFLICT DO NOTHING;

-- 9. CUSTOM TEMPLATES

CREATE TABLE IF NOT EXISTS custom_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text DEFAULT '',
  category text NOT NULL,
  icon text DEFAULT 'FileText',
  prompt_template text NOT NULL,
  input_fields jsonb DEFAULT '[]',
  is_public boolean DEFAULT false,
  usage_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE custom_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own templates and public templates"
  ON custom_templates FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id OR 
    is_public = true OR
    EXISTS (
      SELECT 1 FROM workspace_members
      WHERE workspace_members.workspace_id = custom_templates.workspace_id
      AND workspace_members.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create custom templates"
  ON custom_templates FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own custom templates"
  ON custom_templates FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own custom templates"
  ON custom_templates FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS template_marketplace (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id uuid REFERENCES custom_templates(id) ON DELETE CASCADE NOT NULL,
  price numeric DEFAULT 0,
  downloads integer DEFAULT 0,
  rating numeric DEFAULT 0,
  reviews integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE template_marketplace ENABLE ROW LEVEL SECURITY;

CREATE POLICY "All authenticated users can view marketplace templates"
  ON template_marketplace FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Template owners can list templates in marketplace"
  ON template_marketplace FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM custom_templates
      WHERE custom_templates.id = template_id
      AND custom_templates.user_id = auth.uid()
    )
  );

CREATE POLICY "Template owners can update their marketplace listings"
  ON template_marketplace FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM custom_templates
      WHERE custom_templates.id = template_id
      AND custom_templates.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM custom_templates
      WHERE custom_templates.id = template_id
      AND custom_templates.user_id = auth.uid()
    )
  );

-- 10. AI STYLE TRAINING

CREATE TABLE IF NOT EXISTS training_content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL,
  content_type text DEFAULT 'sample',
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE training_content ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own training content"
  ON training_content FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM workspace_members
      WHERE workspace_members.workspace_id = training_content.workspace_id
      AND workspace_members.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create training content"
  ON training_content FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own training content"
  ON training_content FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own training content"
  ON training_content FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS feedback_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  content_id uuid REFERENCES saved_copies(id) ON DELETE CASCADE NOT NULL,
  feedback_type text NOT NULL CHECK (feedback_type IN ('positive', 'negative')),
  feedback_notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE feedback_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own feedback"
  ON feedback_history FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create feedback"
  ON feedback_history FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own feedback"
  ON feedback_history FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better performance

CREATE INDEX IF NOT EXISTS idx_workspace_members_workspace ON workspace_members(workspace_id);
CREATE INDEX IF NOT EXISTS idx_workspace_members_user ON workspace_members(user_id);
CREATE INDEX IF NOT EXISTS idx_scheduled_content_user ON scheduled_content(user_id);
CREATE INDEX IF NOT EXISTS idx_scheduled_content_scheduled_for ON scheduled_content(scheduled_for);
CREATE INDEX IF NOT EXISTS idx_content_analysis_user ON content_analysis(user_id);
CREATE INDEX IF NOT EXISTS idx_translations_original ON translations(original_content_id);
CREATE INDEX IF NOT EXISTS idx_ab_tests_user ON ab_tests(user_id);
CREATE INDEX IF NOT EXISTS idx_folders_user ON folders(user_id);
CREATE INDEX IF NOT EXISTS idx_content_tags_content ON content_tags(content_id);
CREATE INDEX IF NOT EXISTS idx_usage_tracking_user ON usage_tracking(user_id);
CREATE INDEX IF NOT EXISTS idx_custom_templates_user ON custom_templates(user_id);
CREATE INDEX IF NOT EXISTS idx_training_content_user ON training_content(user_id);
CREATE INDEX IF NOT EXISTS idx_feedback_history_content ON feedback_history(content_id);