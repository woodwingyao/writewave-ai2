/*
  # Template Favorites System

  1. New Tables
    - `template_favorites`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users) - User who favorited the template
      - `template_id` (text) - ID of the favorited template
      - `created_at` (timestamptz) - When the favorite was added

  2. Security
    - Enable RLS on `template_favorites` table
    - Users can only read their own favorites
    - Users can only insert their own favorites
    - Users can only delete their own favorites

  3. Constraints
    - Unique constraint on (user_id, template_id) to prevent duplicate favorites
    - Index on user_id for fast lookups
*/

CREATE TABLE IF NOT EXISTS template_favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  template_id text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, template_id)
);

ALTER TABLE template_favorites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own template favorites"
  ON template_favorites FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can add own template favorites"
  ON template_favorites FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove own template favorites"
  ON template_favorites FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_template_favorites_user_id ON template_favorites(user_id);
CREATE INDEX IF NOT EXISTS idx_template_favorites_template_id ON template_favorites(user_id, template_id);