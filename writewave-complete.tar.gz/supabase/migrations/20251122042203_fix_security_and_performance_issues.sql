/*
  # Fix Security and Performance Issues

  ## Changes Made

  ### 1. Add Missing Index
  - Add index on `content_generations.brand_voice_id` to cover the foreign key

  ### 2. Optimize RLS Policies
  Replace `auth.uid()` with `(select auth.uid())` for better performance:
  - All policies on `brand_voices` table (4 policies)
  - All policies on `template_favorites` table (3 policies)
  - All policies on `content_generations` table (2 policies)
  - All policies on `user_analytics_summary` table (3 policies)

  ### 3. Remove Unused Indexes
  Remove indexes that are not being used:
  - `users_email_idx`
  - `users_stripe_customer_id_idx`
  - `idx_content_generations_user_id`
  - `idx_content_generations_created_at`
  - `idx_content_generations_user_date`
  - `idx_content_generations_template`
  - `users_trial_end_idx`
  - `idx_user_analytics_user_id`
  - `idx_user_analytics_date`
  - `idx_user_analytics_user_date`
  - `idx_brand_voices_user_id`
  - `idx_brand_voices_is_default`
  - `idx_template_favorites_user_id`
  - `idx_template_favorites_template_id`

  ### 4. Fix Function Search Paths
  Add immutable search_path to functions:
  - `update_brand_voice_updated_at()`
  - `ensure_single_default_brand_voice()`
  - `update_user_analytics_summary()`
*/

-- 1. Add missing index for foreign key
CREATE INDEX IF NOT EXISTS idx_content_generations_brand_voice_id 
ON content_generations(brand_voice_id);

-- 2. Drop and recreate RLS policies with optimized auth calls

-- brand_voices policies
DROP POLICY IF EXISTS "Users can view own brand voices" ON brand_voices;
DROP POLICY IF EXISTS "Users can insert own brand voices" ON brand_voices;
DROP POLICY IF EXISTS "Users can update own brand voices" ON brand_voices;
DROP POLICY IF EXISTS "Users can delete own brand voices" ON brand_voices;

CREATE POLICY "Users can view own brand voices"
  ON brand_voices FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own brand voices"
  ON brand_voices FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own brand voices"
  ON brand_voices FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own brand voices"
  ON brand_voices FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- template_favorites policies
DROP POLICY IF EXISTS "Users can view own template favorites" ON template_favorites;
DROP POLICY IF EXISTS "Users can add own template favorites" ON template_favorites;
DROP POLICY IF EXISTS "Users can remove own template favorites" ON template_favorites;

CREATE POLICY "Users can view own template favorites"
  ON template_favorites FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can add own template favorites"
  ON template_favorites FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can remove own template favorites"
  ON template_favorites FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- content_generations policies
DROP POLICY IF EXISTS "Users can view own generation data" ON content_generations;
DROP POLICY IF EXISTS "Users can insert own generation data" ON content_generations;

CREATE POLICY "Users can view own generation data"
  ON content_generations
  FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own generation data"
  ON content_generations
  FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

-- user_analytics_summary policies
DROP POLICY IF EXISTS "Users can view own analytics summary" ON user_analytics_summary;
DROP POLICY IF EXISTS "Users can insert own analytics summary" ON user_analytics_summary;
DROP POLICY IF EXISTS "Users can update own analytics summary" ON user_analytics_summary;

CREATE POLICY "Users can view own analytics summary"
  ON user_analytics_summary
  FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can insert own analytics summary"
  ON user_analytics_summary
  FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own analytics summary"
  ON user_analytics_summary
  FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

-- 3. Drop unused indexes
DROP INDEX IF EXISTS users_email_idx;
DROP INDEX IF EXISTS users_stripe_customer_id_idx;
DROP INDEX IF EXISTS idx_content_generations_user_id;
DROP INDEX IF EXISTS idx_content_generations_created_at;
DROP INDEX IF EXISTS idx_content_generations_user_date;
DROP INDEX IF EXISTS idx_content_generations_template;
DROP INDEX IF EXISTS users_trial_end_idx;
DROP INDEX IF EXISTS idx_user_analytics_user_id;
DROP INDEX IF EXISTS idx_user_analytics_date;
DROP INDEX IF EXISTS idx_user_analytics_user_date;
DROP INDEX IF EXISTS idx_brand_voices_user_id;
DROP INDEX IF EXISTS idx_brand_voices_is_default;
DROP INDEX IF EXISTS idx_template_favorites_user_id;
DROP INDEX IF EXISTS idx_template_favorites_template_id;

-- 4. Fix function search paths by recreating functions with SECURITY DEFINER and set search_path

CREATE OR REPLACE FUNCTION update_brand_voice_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION ensure_single_default_brand_voice()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  IF NEW.is_default = true THEN
    UPDATE brand_voices
    SET is_default = false
    WHERE user_id = NEW.user_id
      AND id != NEW.id
      AND is_default = true;
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION update_user_analytics_summary()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  INSERT INTO user_analytics_summary (
    user_id,
    date,
    total_generations,
    total_words,
    total_characters,
    most_used_template,
    most_used_tone
  )
  SELECT
    NEW.user_id,
    NEW.created_at::date,
    COUNT(*),
    SUM(word_count),
    SUM(character_count),
    MODE() WITHIN GROUP (ORDER BY template_id),
    MODE() WITHIN GROUP (ORDER BY tone)
  FROM content_generations
  WHERE user_id = NEW.user_id AND created_at::date = NEW.created_at::date
  GROUP BY user_id, created_at::date
  ON CONFLICT (user_id, date)
  DO UPDATE SET
    total_generations = EXCLUDED.total_generations,
    total_words = EXCLUDED.total_words,
    total_characters = EXCLUDED.total_characters,
    most_used_template = EXCLUDED.most_used_template,
    most_used_tone = EXCLUDED.most_used_tone,
    updated_at = now();
  
  RETURN NEW;
END;
$$;
