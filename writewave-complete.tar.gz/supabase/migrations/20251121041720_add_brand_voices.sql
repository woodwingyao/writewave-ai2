/*
  # Brand Voice Storage

  1. New Tables
    - `brand_voices`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `name` (text) - Name of the brand voice (e.g., "My Tech Startup", "Personal Brand")
      - `description` (text, nullable) - Optional description of the brand voice
      - `tone` (text) - Preferred tone (e.g., "Professional", "Friendly")
      - `writing_style` (text, nullable) - Preferred writing style
      - `key_phrases` (text[], nullable) - Array of phrases/words to include
      - `avoid_phrases` (text[], nullable) - Array of phrases/words to avoid
      - `example_text` (text, nullable) - Example text that represents the brand voice
      - `is_default` (boolean) - Whether this is the user's default brand voice
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `brand_voices` table
    - Users can only read their own brand voices
    - Users can only insert their own brand voices
    - Users can only update their own brand voices
    - Users can only delete their own brand voices

  3. Constraints
    - Each user can only have one default brand voice at a time
*/

CREATE TABLE IF NOT EXISTS brand_voices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  tone text NOT NULL DEFAULT 'Professional',
  writing_style text,
  key_phrases text[],
  avoid_phrases text[],
  example_text text,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE brand_voices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own brand voices"
  ON brand_voices FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own brand voices"
  ON brand_voices FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own brand voices"
  ON brand_voices FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own brand voices"
  ON brand_voices FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_brand_voices_user_id ON brand_voices(user_id);
CREATE INDEX IF NOT EXISTS idx_brand_voices_is_default ON brand_voices(user_id, is_default) WHERE is_default = true;

CREATE OR REPLACE FUNCTION update_brand_voice_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER brand_voices_updated_at
  BEFORE UPDATE ON brand_voices
  FOR EACH ROW
  EXECUTE FUNCTION update_brand_voice_updated_at();

CREATE OR REPLACE FUNCTION ensure_single_default_brand_voice()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.is_default = true THEN
    UPDATE brand_voices
    SET is_default = false
    WHERE user_id = NEW.user_id
      AND id != NEW.id
      AND is_default = true;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER enforce_single_default_brand_voice
  BEFORE INSERT OR UPDATE ON brand_voices
  FOR EACH ROW
  EXECUTE FUNCTION ensure_single_default_brand_voice();